<?php
session_start();
$con = mysqli_connect("localhost","root","","fknmenhely");



if(isset($_POST['orokbefogadas']))
{
   
    print_r("asd");

    ////////////////////////////////////
 








    
//////////////////////////////////////////////
$query_run = mysqli_query($con, $query);

if($query_run)
{
    $_SESSION['status'] = "Sikeresen feltöltöted az állatot.";
    header("Location: index.html");
}
else
{
    $_SESSION['status'] = "Nem sikerült feltöltened az állatot.";
    header("Location: index.html");
}
}
?>