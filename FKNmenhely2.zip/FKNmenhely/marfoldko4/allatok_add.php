<?php session_start();?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Állatok örökbeadása</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="header">
          <!------------------------fej-eleje------------------------------------------>
  <header class="bg-light" id="fej1">
    <div class="container">
      
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <a class="navbar-brand" href="#">
            <img src="kepek/logo2.png" width="30" height="30" alt="">
          </a>
            <a class="navbar-brand" href="#">Menü</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                  <a class="nav-link" href="index.html">Főoldal </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="allatok.php">Állatok</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php">Saját oldalam</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="allatok_add.php">Állatok örökbeadása</a>
                </li>
                     
              </ul>
            </div>
          </nav>
    </div>
</header> 

<!---------------------fej-vége----------------->   
        </div>

<!----------------->

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">

                <?php 
                    if(isset($_SESSION['status']))
                    {
                        ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <strong>Hey!</strong> <?php echo $_SESSION['status']; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php
                        unset($_SESSION['status']);
                    }
                ?>

                <div class="card mt-5">
                    <div class="card-header">
                        <h1>Állat örökbeadása</h1>
                        
                    </div>
                    <div class="card-body">
                        
                        <form action="allatok_code.php" method="POST" enctype="multipart/form-data">
                            <div class="form-group mb-3">
                                <label for="name">Állat neve: </label>
                                <input type="text" name="name" id="name" class="form-control" />
                            </div>
                            <div class="form-group mb-3">
                                <label for="dateofbirth">Születési éve: </label>
                                <input type="date" name="dateofbirth"  id="dateofbirth" class="form-control" />
                            </div>

                            <div class="form-group mb-3">
                                <label for="becsultkor">(Becsült) kora: </label>
                                <input type="number" name="becsultkor" min="1" max="30" id="becsultkor" class="form-control" />
                            </div>
                                        <!--NINCS becsültkor-->
                            <div class="form-group mb-3">
                            <fieldset>
                                <legend><label for="neme">Neme: </label></legend>

                                <label for="neme">
                                                            
                                <input type="radio" name="neme"  id="neme" value="kan">
                                Kan
                                </label>
                                <br>

                                <label for="neme">
                                                            
                                <input type="radio" name="neme" id="neme" value="szuka" checked>
                                Szuka
                                </label>
                            </fieldset>               
                            </div>
                            <div class="form-group mb-3">
                                <label for="faja">Faja: </label>
                                <input type="text" name="faja" id="faja" class="form-control" />
                            </div>
                            

                            <div class="form-group mb-3">
                                <label for="eu_allapot">Egészségi Állapot: </label>
                                <br>
                                <select name="eu_allapot" id="eu_allapot">
                                    <option value="egészséges">egészséges</option>
                                    <option value="közepes" selected>közepes</option>
                                    <option value="rossz">rossz</option>
                                </select>
                            </div>

                            
                            <div class="form-group mb-3">
                                <fieldset>
                                    <legend><label for="ivar_ivartalanitot">Ivartalanitott-e? : </label></legend>

                                        <label for="">
                                         
                                        <input type="radio" name="ivar" id="ivar" value="1">
                                        Igen
                                        </label>
                                        <br>

                                        <label for="">
                                         
                                        <input type="radio" name="ivar" id="ivar "value="0" checked>
                                        Nem
                                        </label>
                                </fieldset>
                            </div>
                            <!---->

                            <div class="form-group mb-3">
                                <label for="suly">Súlya: </label>
                                <input type="number" name="suly" id="suly" max="150" min="1" class="form-control" />
                            </div>


                            <div class="form-group mb-3">
                                <label for="fogazatt_allapot">Fogazatt állapota: </label>
                                <br>
                                <select name="fogazatt_allapot" id="fogazatt_allapot">
                                    <option value="egészséges" selected>egészséges</option>
                                    <option value="fogszuvas" >fogszuvas</option>
                                    <option value="foghiányos">foghiányos</option>
                                </select>
                            </div>


                            <div class="form-group mb-3">
                                <label for="testi_allapot">Testi állapot: </label>
                                <br>
                                <select name="testi_allapot" id="testi_allapot">
                                    <option value="egészséges" selected>egészséges</option>
                                    <option value="közepes" >közepes</option>
                                    <option value="rossz">rossz</option>
                                </select>
                            </div>

                            <div class="form-group mb-3">
                                <label for="ismertetojegyek">Ismertető jegyek: "Maximum 200 karakter." </label>
                                <br>
                              <textarea name="ismertetojegyek" id="ismertetojegyek" cols="54" rows="5" maxlength="200"></textarea>
                            </div>

                            <div class="form-group mb-3">
                                <label for="megjegyzes">Megjegyzés: "Maximum 200 karakter." </label>
                                <br>
                              <textarea name="megjegyzes" id="megjegyzes" cols="54" rows="5" maxlength="200"></textarea>
                            </div>

                                
                            <div class="form-group mb-3">
                                <fieldset>
                                    <legend><label for="chip">Chippelt-e? : </label></legend>

                                        <label for="chip">
                                         
                                        <input type="radio" name="chip" value="1">
                                        Igen
                                        </label>
                                        <br>

                                        <label for="">
                                         
                                        <input type="radio" name="chip" value="0" checked>
                                        Nem
                                        </label>
                                </fieldset>
                            </div>

                         
                            <div class="form-group mb-3">
                                <input type="file" name="image" class="form-control">
                            </div>

                            <div class="form-group mb-3">
                                <button type="submit" name="save_date" value="UPLOAD" class="btn btn-primary">Örökbeadás</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<!--
    becsult_kor kell
    img
php
-->