<?php
$host = "localhost";
$dbname = "fknmenhely";
$username = "root";
$password = "";


// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// firstly select the data you want to copy

$sql_1 = "SELECT allat_id,allat_nev,befogadas_datuma FROM allatok";

$result = $conn->query($sql_1);

if (!empty($result) && $result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $allatok_id = $row["allatok_id"]; //st_id
        $allatok_name = $row["allatok_name"]; //name
        $befogadas_datuma = $row["befogadas_datuma"];  //reg
    }

} else {
    echo "Not Found";
}


// secondly insert the data you select in the past

$stmt_1 = $conn->prepare("INSERT INTO table2 (allatok_id, allatok_name,befogadas_datuma) VALUES (?, ?, ?)");
$stmt_1->bind_param("iss", $allatok_id, $allatok_name, $befogadas_datuma);

$stmt_2 = $conn->prepare("INSERT INTO table3 (allatok_id, allatok_name,befogadas_datuma) VALUES (?, ?, ?)");
$stmt_2->bind_param("iss", $allatok_id, $allatok_name, $befogadas_datuma);

$stmt_1->execute();
$stmt_1->close();

$stmt_2->execute(); 
$stmt_2->close();

$conn->close();