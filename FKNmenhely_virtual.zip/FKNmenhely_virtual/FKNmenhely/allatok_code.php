<?php
session_start();
$con = mysqli_connect("localhost","root","","fknmenhely");
$con2 = mysqli_connect("localhost","root","","fknmenhely");



if(isset($_POST['save_date']))
{
    $name = $_POST['name'];
    $dob = date('Y-m-d', strtotime($_POST['dateofbirth']));
//becsultkor helye

$becsultkor = $_POST['becsultkor'];
//neme
$neme = $_POST['neme'];  
if ($neme == "kan") {          
    $neme_van= $_POST['neme'];     
}
if ($neme == "szuka") {          
    $neme_van= $_POST['neme'];     
}
//
$faja_van = $_POST['faja'];

//eu
$eu_allapot_van =$_POST["eu_allapot"];
//ivar

$ivar = $_POST['ivar'];  
if ($ivar == "1") {          
    $ivar_van= $_POST['ivar'];     
}
if ($ivar == "0") {          
    $ivar_van= $_POST['ivar'];     
}
//
//suly
$suly_van = $_POST['suly'];
//
//fog
$fogazatt_allapot_van =$_POST["fogazatt_allapot"];
//
//testi
$testi_allapot_van =$_POST["testi_allapot"];

//ismerteto
$ismertetojegyek_van =$_POST["ismertetojegyek"];
//
//megjegyzes
$megjegyzes_van =$_POST["megjegyzes"];
//
//chippelt-e

$chip = $_POST['chip'];  
if ($chip == "1") {          
    $chip_van= $_POST['chip'];     
}
if ($chip == "0") {          
    $chip_van= $_POST['chip'];     
}

if(!empty($_FILES['image'])){
    $file = $_FILES['image']['name'];
    $file_tmp_name=$_FILES['image']['tmp_name'];
    $allowed_ext=array("jpg","png","jpeg","gif");
    $splitFileName=explode('.',$file);
    $image_ext=strtolower(end($splitFileName));
   
    if(in_array($image_ext,$allowed_ext)){
        move_uploaded_file($file_tmp_name,"C:/FKNmenhely/allat_kepek/".$file);
    }
}


$kutyakep= "http://localhost/allat_kepek/".$file;

   $query = "INSERT INTO allatok (allat_nev,szul_ev,becsult_kor,neme,fajta,eu_allapot,ivar_ivartalanitot,suly,fogazatt,testi_allapott,ismertetojegyek,megjegyzes,chip,img) VALUES ('$name','$dob','$becsultkor','$neme_van','$faja_van','$eu_allapot_van','$ivar_van','$suly_van','$fogazatt_allapot_van','$testi_allapot_van','$ismertetojegyek_van','$megjegyzes_van','$chip_van','$kutyakep')";
  

    ////////////////////////////////////
 








$con2->close();
    
//////////////////////////////////////////////
$query_run = mysqli_query($con, $query);

if($query_run)
{
    $_SESSION['status'] = "Sikeresen feltöltöted az állatot.";
    header("Location: index.html");
}
else
{
    $_SESSION['status'] = "Nem sikerült feltöltened az állatot.";
   header("Location: index.html");
}
}
?>