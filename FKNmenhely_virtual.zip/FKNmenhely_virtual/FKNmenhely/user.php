<?php 
session_start();
if (isset($_SESSION["user_id"])) {
    $mysqli = require __DIR__ . "/database.php";
    $sql = "SELECT * FROM felhasznalok
            WHERE id = {$_SESSION["user_id"]}";
    $result = $mysqli->query($sql);
    $user = $result->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Saját oldalam</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/just-validate@latest/dist/just-validate.production.min.js" defer></script>
    <script src="/js/validation.js" defer></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="/stilus/user_oldala1.css?v=<?php echo time(); ?>">

  
</head>
<body>
  <!------------------------fej-eleje------------------------------------------>
  <header class="bg-light" id="fej1">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <a class="navbar-brand" href="#">
            <img src="/kepek/logo2.png" width="50" height="50" alt="">
          </a>
            <a class="navbar-brand" href="#">Menü</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                  <a class="nav-link" href="index.html">Főoldal</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="allatok.php">Állatok</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="user.php">Saját oldalam</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="loginadmin.php">Állatok örökbeadása</a>
                </li>
              </ul>
            </div>
          </nav>
    </div>
</header> 
<!---------------------fej-vége----------------->    
<!---------------------tartalom-eleje----------------->
<!---------------------user_adatai-eleje----------------->
<div class="container"><?php 
                    if(isset($_SESSION['status']))
                    {
                        ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <strong>Hey!</strong> <?php echo $_SESSION['status']; ?>
                           
                            </div>
                        <?php
                        unset($_SESSION['status']);
                    }
                ?></div>
<div class="wrapper1">
<h1><u>Fiók adatai:</u></h1>
<?php if (isset($user)): ?>
  <table>
<tr>
  <td> <p>Felhasználó azonosítója: <?= htmlspecialchars($user["id"]) ?></p></td>
  <td> <p>Felhasználó neve: <?= htmlspecialchars($user["name"]) ?></p></td>
</tr>
<tr>
  <td> <p>Email cím: <?= htmlspecialchars($user["email"]) ?></p></td>
  
  <td><p>Felhasználó élet körülménye: <?= htmlspecialchars($user["kert_van"]) ?></p></td>
</tr>
<tr>
<td id="rovid"><p>Felhasználó bizalmi állapota:</p> </td>
<td><?php if ($user["bizalom_v"]=='1'): ?>
    <p><?= htmlspecialchars('Rendben van a FKN menhellyel a bizalmi kapcsolat a felhasználonak.') ?></p>
    <?php else: ?>
      <p> <?= htmlspecialchars('Nincs rendben a FKN menhellyel a bizalmi kapcsolat a felhasználonak.') ?></p>
      <?php endif; ?></td>
</tr>
</table>
    <p id="lent"><a href="logout.php">Kijelentkezés</a></p>
<?php else: ?>
    <p id="mozgatas1"><a href="login.php">Bejelentkezés</a> vagy <a href="signup.php">regisztráció</a></p>
    <?php endif; ?>
  </div>
  <h2 id="felhasznalo_allat"><u>Felhasználó által örökbefogadott állatok: </u></h2>
<!---------------------user_adatai-vége----------------->
<!---------------------orokbefogadot_allat_adatai-eleje----------------->
<div class="allatokwrapper">
<?php if (isset($user)): ?>
                        <?php
              $query = "SELECT allatok.allat_id, allatok.allat_nev, allatok.szul_ev, allatok.becsult_kor, allatok.neme, allatok.fajta, allatok.suly, allatok.img, felhasznalok.name, felhasznalok.id 
              FROM allatok 
              INNER JOIN orokbeadott_allatok ON allatok.allat_id = orokbeadott_allatok.allat_id 
              INNER JOIN felhasznalok ON orokbeadott_allatok.user_id = felhasznalok.id 
              WHERE orokbeadott_allatok.user_id = " .$user['id'] ;
    $db = new mysqli("localhost", "root", "", "fknmenhely");
    $db_amount = $db->query("SELECT COUNT(*) FROM ($query) as tmp");
    $result = $db->query($query);
    $html = '';
    $totalItemPerLine = 3;
    $totalItem = $db_amount->fetch_row()[0];
    if($totalItem > 0) {
        for($i = 0; $i < $totalItem; $i++) {
            $row = $result -> fetch_row();
            $allat_id = $row[0];
            $allat_nev = $row[1];
            $szuletett = substr($row[2], 0, 10);
            $becsult_kor = $row[3];
            $neme = $row[4];
            $fajta = $row[5];
            $suly = $row[6];
            $img_src = $row[7];
            $gazda = $row[8];
            if($i % $totalItemPerLine == 0) {
                $html .= '<div class="row">'; 
            }
            $html .= '<div class="card">'
            .'<form action="vissza.php?id=' . $allat_id.'&'.'userid='.$user["id"] . '" method="POST">'
                .'<div class="img-wrapper">'
                .'<a href="/allatok_sajatoldala.php?id='.$allat_id.'"></a>'
                .'<img class="thumbnail" src="'.$img_src.'"></div><br>'
                .'<h2 class="allat-nev">'.$allat_nev.'</h2>'
                ."<p> Állat azonositója adatbázisunkban : ".$allat_id."</p>"
                ."<p> Született : ".$szuletett."</p>"
                ."<p> Becsült kor: ".$becsult_kor."</p>"
                ."<p> Ivar: ".$neme."</p>"
                ."<p> Fajta: ".$fajta."</p>"
                ."<p> Súly: ".$suly." kg</p>"
                ."<p> Állat gazdája: ".$gazda."</p>"
                ."<u id='piros'>Biztos hogy vissza akarod vinni kis állatodat, ha igen akkor a bizalmi kapcsolatod meg fogg szűnni a menhellyel!</u>"

                .'<a class="btn1" href="allatok_sajatoldala.php?id='.$allat_id.'">'
                .'További részletek</a>'
                .'<button type="submit" name="vissza" value="UPLOAD" class="btn2">Állat visszavitele.</button>'
               .' </form>'
               .'<form action="allatok_frissites.php?id=' . $allat_id.'" method="POST">'
               .'<button type="submit" name="save_date" value="UPLOAD" class="btn2">Állat frissitése</button>'
               .' </form>'
                                .'</div>';



                                if($i % $totalItemPerLine == ($totalItemPerLine-1) || $i == ($totalItem-1))
                                {
                                    $html .= '</div>'; 
                                }
                            }   
                        } else {
                            $html .= "<p id='nincstalalat'>A felhasználó még nem fogadott örökbe állatot a menhely felületén.</p>";
                        }
                        $db->close();
                        echo $html;
                           ?>
                     <?php else: ?>
                      <div class="allatokwrapperlogout"> <p id="mozgatas"><a href="login.php">Bejelentkezés</a> vagy <a href="signup.php">regisztráció</a></p></div> 
    <?php endif; ?>
                    </div> 
<!---------------------orokbefogadot_allat_adatai-vége----------------->
<!---------------------tartalom-vége----------------->   
</body>
</html>
