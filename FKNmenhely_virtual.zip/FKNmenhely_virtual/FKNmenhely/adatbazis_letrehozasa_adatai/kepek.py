import os
os.getcwd()
collection = "C:/Users/Gergő/Desktop/FKNmenhely/www_tappancs_hu"
for i, filename in enumerate(os.listdir(collection)):
    os.rename(
        f"C:/Users/Gergő/Desktop/FKNmenhely/www_tappancs_hu/{filename}",
        f"C:/Users/Gergő/Desktop/FKNmenhely/www_tappancs_hu/{i}.jpg",
    )