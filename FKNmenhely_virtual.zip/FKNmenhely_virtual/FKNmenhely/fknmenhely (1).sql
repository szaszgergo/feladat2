-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2023. Máj 03. 16:09
-- Kiszolgáló verziója: 10.4.27-MariaDB
-- PHP verzió: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `fknmenhely`
--

DELIMITER $$
--
-- Eljárások
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_allatok` ()   SELECT * FROM allatok$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `allatok`
--

CREATE TABLE `allatok` (
  `allat_id` int(11) NOT NULL,
  `allat_nev` varchar(50) NOT NULL,
  `szul_ev` date NOT NULL,
  `becsult_kor` int(11) NOT NULL,
  `neme` varchar(255) NOT NULL DEFAULT 'kan',
  `fajta` varchar(255) NOT NULL,
  `eu_allapot` varchar(255) NOT NULL,
  `ivar_ivartalanitot` tinyint(1) NOT NULL,
  `suly` float NOT NULL,
  `fogazatt` varchar(255) NOT NULL,
  `testi_allapott` varchar(255) NOT NULL,
  `ismertetojegyek` varchar(255) NOT NULL,
  `megjegyzes` varchar(255) NOT NULL,
  `chip` tinyint(1) NOT NULL,
  `orokbeadas` tinyint(1) NOT NULL DEFAULT 0,
  `befogadas_datuma` datetime NOT NULL DEFAULT current_timestamp(),
  `img` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `allatok`
--

INSERT INTO `allatok` (`allat_id`, `allat_nev`, `szul_ev`, `becsult_kor`, `neme`, `fajta`, `eu_allapot`, `ivar_ivartalanitot`, `suly`, `fogazatt`, `testi_allapott`, `ismertetojegyek`, `megjegyzes`, `chip`, `orokbeadas`, `befogadas_datuma`, `img`) VALUES
(1, 'Frida', '2020-10-23', 3, 'kan', 'Rövidszőrű isztriai kopó', 'rossz', 1, 12, 'fogszuvas', 'egészséges', 'kicsi arany fekete kék', 'szeret játszani', 1, 0, '2021-08-10 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/163.jpg'),
(2, 'Leila', '2016-01-14', 7, 'kan', 'Kis jurai kopó', 'közepes', 0, 16, 'fogszuvas', 'rossz', 'közepes tigriscsíkos rózsaszín zöld', 'szeret kutyakölykökkel játszani', 1, 0, '2022-12-27 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/204.jpg'),
(3, 'Nudli', '2016-09-21', 7, 'szuka', 'Husky', 'rossz', 1, 3, 'egészséges', 'rossz', 'közepes vörös vörös kék', 'szeret sétálni a parkban', 1, 1, '2022-07-27 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/154.jpg'),
(4, 'Rézi', '2019-10-28', 4, 'kan', 'Sussexi spániel', 'rossz', 0, 11, 'foghiányos', 'rossz', 'nagy barna vörös barna', 'szeret úszni', 1, 0, '2022-08-17 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/103.jpg'),
(5, 'Kloé', '2019-01-01', 4, 'szuka', 'Ardenneki pásztorkutya', 'rossz', 1, 30, 'fogszuvas', 'rossz', 'közepes fekete fekete barna', 'be van gyulladva a füle', 1, 1, '2021-04-05 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/91.jpg'),
(6, 'Ofélia', '2015-05-16', 8, 'kan', 'Norvég buhund', 'közepes', 1, 12, 'egészséges', 'közepes', 'nagy barna fekete kék', 'imád aludni', 1, 0, '2022-10-21 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/63.jpg'),
(7, 'Nyikita', '2019-01-14', 4, 'kan', 'Dán-svéd őrkutya', 'közepes', 1, 1, 'fogszuvas', 'egészséges', 'közepes fehér barna zöld', 'szeret nyugodtan pihenni', 1, 0, '2021-08-22 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/180.jpg'),
(8, 'Lucy', '2018-10-07', 5, 'kan', 'Fehér-fekete francia kopó', 'közepes', 0, 11, 'foghiányos', 'rossz', 'kicsi fehér vörös zöld', 'szeret futkosni a kertben', 1, 0, '2022-11-10 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/95.jpg'),
(9, 'Zsömike', '2015-11-08', 8, 'szuka', 'Hannoveri véreb', 'közepes', 1, 17, 'foghiányos', 'rossz', 'nagy sárga vörös barna', 'imád aludni', 1, 0, '2021-01-14 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/50.jpg'),
(10, 'Maggie', '2016-11-17', 7, 'kan', 'Orosz toy terrier', 'egészséges', 0, 8, 'fogszuvas', 'rossz', 'kicsi vörös rózsaszín kék', 'imád aludni', 1, 0, '2021-03-10 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/127.jpg'),
(11, 'Orchidea', '2016-03-16', 7, 'szuka', 'Nyugat-szibériai lajka', 'közepes', 0, 13, 'fogszuvas', 'közepes', 'nagy szürke rózsaszín barna', 'szeret játszani', 1, 0, '2021-08-26 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/56.jpg'),
(12, 'Killer', '2015-09-01', 8, 'szuka', 'Kanári-szigeteki kutya', 'közepes', 0, 12, 'egészséges', 'közepes', 'nagy fekete barna barna', 'szeret futkosni a kertben', 1, 0, '2021-06-21 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/162.jpg'),
(13, 'Askim', '2019-04-03', 4, 'szuka', 'Sarplaninai juhászkutya', 'rossz', 0, 1, 'fogszuvas', 'egészséges', 'nagy arany vörös zöld', 'kedveli a sétákat', 1, 0, '2021-04-11 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/136.jpg'),
(14, 'Azték', '2019-03-26', 4, 'kan', 'Tosza inu', 'közepes', 1, 30, 'egészséges', 'közepes', 'közepes szürke vörös zöld', 'több mozgást igényel', 1, 1, '2022-02-21 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/184.jpg'),
(15, 'Ládikó', '2020-10-03', 3, 'kan', 'Cairn terrier', 'egészséges', 1, 26, 'egészséges', 'rossz', 'nagy fekete vörös kék', 'szeret kutyakölykökkel játszani', 1, 0, '2022-06-16 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/108.jpg'),
(16, 'Zafira', '2020-02-13', 3, 'szuka', 'Pudelpointer', 'közepes', 0, 2, 'fogszuvas', 'rossz', 'nagy fekete fekete kék', 'szeret játszani', 1, 0, '2022-04-04 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/152.jpg'),
(17, 'Nessy', '2016-09-19', 7, 'kan', 'Laekenois', 'közepes', 0, 22, 'fogszuvas', 'közepes', 'közepes arany vörös kék', 'bélférges', 1, 0, '2022-12-20 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/63.jpg'),
(18, 'Orlando', '2020-03-03', 3, 'szuka', 'Bichon frisé', 'rossz', 0, 20, 'foghiányos', 'egészséges', 'közepes fehér vörös kék', 'kedveli a sétákat', 1, 0, '2022-11-03 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/196.jpg'),
(19, 'Nina', '2020-03-26', 3, 'kan', 'Ariége-i kopó', 'egészséges', 0, 24, 'egészséges', 'közepes', 'nagy barna fekete kék', 'köröm vágást igényel', 1, 0, '2021-03-15 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/38.jpg'),
(20, 'Rea', '2019-11-04', 4, 'szuka', 'Hosszúszőrű német vizsla', 'közepes', 0, 2, 'egészséges', 'közepes', 'nagy arany rózsaszín barna', 'szeret játszani a labdával', 1, 0, '2022-08-02 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/147.jpg'),
(21, 'Narancs', '2018-06-23', 5, 'kan', 'Drótszőrű isztriai kopó', 'egészséges', 0, 7, 'egészséges', 'közepes', 'kicsi sárga rózsaszín zöld', 'szeret nyugodtan pihenni', 1, 0, '2021-04-22 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/101.jpg'),
(22, 'Fifi', '2019-05-26', 4, 'kan', 'Cirneco dell’Etna', 'egészséges', 0, 3, 'egészséges', 'egészséges', 'kicsi szürke vörös zöld', 'bélférges', 1, 0, '2022-03-28 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/103.jpg'),
(23, 'Nudli', '2017-10-08', 6, 'kan', 'Orosz toy terrier', 'közepes', 1, 7, 'egészséges', 'közepes', 'kicsi arany rózsaszín kék', 'szeret ölelni', 1, 0, '2022-08-07 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/54.jpg'),
(24, 'Lady', '2015-02-15', 8, 'kan', 'Shiloh juhászkutya', 'rossz', 1, 11, 'foghiányos', 'közepes', 'nagy tigriscsíkos vörös barna', 'kedveli a sétákat', 1, 0, '2021-04-21 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/32.jpg'),
(25, 'Zafír', '2016-09-06', 7, 'kan', 'Kras-medencei juhászkutya', 'egészséges', 0, 3, 'egészséges', 'egészséges', 'nagy fekete barna barna', 'kedveli a sétákat', 1, 0, '2021-12-13 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/156.jpg'),
(26, 'Scott', '2015-09-26', 8, 'szuka', 'Welsh springer spániel', 'egészséges', 0, 30, 'egészséges', 'rossz', 'közepes tigriscsíkos fekete kék', 'szeret játszani a labdával', 1, 0, '2021-05-19 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/197.jpg'),
(27, 'Hobbit', '2016-08-26', 7, 'szuka', 'Kooikerhondje', 'közepes', 0, 19, 'foghiányos', 'egészséges', 'kicsi barna vörös zöld', 'szeret sétálni a parkban', 1, 0, '2021-05-14 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/97.jpg'),
(28, 'Edith', '2016-07-02', 7, 'szuka', 'Boszniai kopó', 'egészséges', 1, 29, 'fogszuvas', 'közepes', 'közepes vörös barna zöld', 'imád aludni', 1, 0, '2022-08-19 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/77.jpg'),
(29, 'Jupiter', '2018-01-11', 5, 'kan', 'Trikolor francia kopó', 'egészséges', 1, 5, 'egészséges', 'egészséges', 'közepes tigriscsíkos barna kék', 'köröm vágást igényel', 1, 0, '2021-07-04 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/136.jpg'),
(30, 'Zafír', '2017-03-11', 6, 'szuka', 'Brazil terrier', 'egészséges', 0, 15, 'egészséges', 'rossz', 'nagy sárga fekete barna', 'imád aludni', 1, 0, '2022-05-27 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/2.jpg'),
(31, 'Adolf', '2019-04-16', 4, 'szuka', 'Belga griffon', 'rossz', 0, 19, 'egészséges', 'rossz', 'nagy szürke fekete barna', 'szeret az ablakban ülni', 1, 0, '2021-06-17 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/190.jpg'),
(32, 'Szerecsendió', '2017-02-05', 6, 'szuka', 'Rottweiler', 'egészséges', 0, 14, 'fogszuvas', 'egészséges', 'nagy tigriscsíkos rózsaszín barna', 'imád aludni', 1, 0, '2022-04-21 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/103.jpg'),
(33, 'Szetti', '2016-01-26', 7, 'szuka', 'Simaszőrű foxterrier', 'rossz', 0, 10, 'egészséges', 'egészséges', 'nagy fekete barna zöld', 'be van gyulladva a füle', 1, 0, '2021-02-19 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/18.jpg'),
(34, 'Zafír', '2015-12-03', 8, 'kan', 'Szlovák csuvacs', 'rossz', 0, 3, 'fogszuvas', 'közepes', 'kicsi szürke vörös barna', 'szeret játszani a labdával', 1, 0, '2022-12-06 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/99.jpg'),
(35, 'Frakk', '2016-09-21', 7, 'kan', 'Vendée-i griffon basset', 'közepes', 0, 17, 'fogszuvas', 'rossz', 'közepes fehér sötétbarna barna', 'kedves és barátságos', 1, 0, '2022-01-19 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/30.jpg'),
(36, 'Bogáncs', '2019-11-21', 4, 'szuka', 'Német juhászkutya', 'rossz', 0, 3, 'foghiányos', 'egészséges', 'közepes fehér rózsaszín barna', 'kedveli a sétákat', 1, 0, '2021-08-06 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/153.jpg'),
(37, 'Nyikita', '2019-07-05', 4, 'kan', 'Bretagne-i cserszínű basset', 'közepes', 1, 28, 'fogszuvas', 'egészséges', 'közepes foltos barna zöld', 'bélférges', 1, 0, '2021-04-28 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/85.jpg'),
(38, 'Keiko', '2020-04-16', 3, 'kan', 'Welsh corgi', 'rossz', 1, 18, 'fogszuvas', 'rossz', 'kicsi szürke vörös kék', 'szeret játszani', 1, 0, '2022-08-26 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/58.jpg'),
(39, 'Igloo', '2017-03-15', 6, 'szuka', 'Óriás schnauzer', 'rossz', 0, 24, 'egészséges', 'rossz', 'nagy sárga barna zöld', 'imád aludni', 1, 0, '2022-05-20 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/117.jpg'),
(40, 'Bözsi', '2016-12-14', 7, 'szuka', 'Sinka', 'egészséges', 0, 10, 'egészséges', 'egészséges', 'közepes szürke vörös zöld', 'szeret nyugodtan pihenni', 1, 0, '2022-12-14 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/153.jpg'),
(41, 'Bessz', '2016-02-27', 7, 'kan', 'Drótszőrű német vizsla', 'közepes', 0, 12, 'fogszuvas', 'rossz', 'közepes arany barna barna', 'szeret az ablakban ülni', 1, 0, '2021-12-09 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/99.jpg'),
(42, 'Lasszó', '2016-01-09', 7, 'szuka', 'Jack Russell terrier', 'rossz', 0, 10, 'egészséges', 'egészséges', 'kicsi vörös vörös zöld', 'szeret ölelni', 1, 0, '2021-03-18 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/194.jpg'),
(43, 'Amanda', '2019-06-04', 4, 'kan', 'Bőrtokos kalippó', 'közepes', 0, 16, 'fogszuvas', 'egészséges', 'nagy fehér fekete zöld', 'szeret az ablakban ülni', 1, 0, '2022-05-12 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/149.jpg'),
(44, 'Shiva', '2015-12-09', 8, 'kan', 'Ír terrier', 'egészséges', 1, 15, 'foghiányos', 'rossz', 'közepes szürke vörös kék', 'szeret játszani', 1, 0, '2021-10-12 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/168.jpg'),
(45, 'Killer', '2017-05-15', 6, 'kan', 'Tosza inu', 'rossz', 1, 29, 'foghiányos', 'rossz', 'közepes tigriscsíkos vörös barna', 'szeret futkosni a kertben', 1, 0, '2021-09-22 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/195.jpg'),
(46, 'Pisze', '2016-07-02', 7, 'szuka', 'Nagy gascogne-i kék kopó', 'közepes', 1, 11, 'fogszuvas', 'közepes', 'kicsi tigriscsíkos vörös zöld', 'szeret játszani', 1, 0, '2021-03-07 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/181.jpg'),
(47, 'Orlando', '2016-07-10', 7, 'kan', 'Holland smoushond', 'közepes', 1, 5, 'egészséges', 'rossz', 'közepes szürke vörös zöld', 'kedves és barátságos', 1, 0, '2021-10-16 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/124.jpg'),
(48, 'Jimmy', '2015-04-19', 8, 'kan', 'Angol juhászkutya', 'egészséges', 1, 6, 'foghiányos', 'közepes', 'nagy tigriscsíkos rózsaszín zöld', 'szeret fürdeni a tóban', 1, 0, '2021-02-06 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/76.jpg'),
(49, 'Jenny', '2020-03-13', 3, 'kan', 'Shiloh juhászkutya', 'közepes', 0, 24, 'fogszuvas', 'egészséges', 'nagy szürke sötétbarna kék', 'szeret ölelni', 1, 0, '2022-09-17 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/93.jpg'),
(50, 'Milli', '2019-11-28', 4, 'kan', 'Gascogne-i kék griffon', 'rossz', 1, 8, 'fogszuvas', 'rossz', 'kicsi arany barna kék', 'imád aludni', 1, 0, '2022-11-06 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/139.jpg'),
(51, 'Bonnie', '2020-05-23', 3, 'kan', 'Boykin spániel', 'közepes', 1, 25, 'foghiányos', 'közepes', 'nagy vörös barna zöld', 'szeret játszani a labdával', 1, 0, '2021-06-26 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/209.jpg'),
(52, 'Zsuzsu', '2016-01-19', 7, 'kan', 'Osztrák kopó', 'egészséges', 1, 20, 'foghiányos', 'rossz', 'közepes sárga rózsaszín kék', 'kedves és barátságos', 1, 0, '2022-11-23 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/5.jpg'),
(53, 'Aramis', '2020-01-16', 3, 'szuka', 'Cseh terrier', 'egészséges', 1, 5, 'egészséges', 'közepes', 'nagy vörös vörös zöld', 'szeret nyugodtan pihenni', 1, 0, '2021-08-15 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/139.jpg'),
(54, 'Mogyoró', '2015-05-27', 8, 'kan', 'Keverék', 'közepes', 1, 7, 'egészséges', 'rossz', 'közepes fekete vörös zöld', 'szeret úszni', 1, 0, '2021-06-10 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/2.jpg'),
(55, 'Pongó', '2020-02-23', 3, 'szuka', 'Chesapeake Bay retriever', 'közepes', 1, 7, 'egészséges', 'közepes', 'nagy foltos barna barna', 'szeret úszni', 1, 0, '2021-08-01 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/61.jpg'),
(56, 'Kefir', '2019-06-17', 4, 'szuka', 'Saage kochee', 'rossz', 1, 30, 'fogszuvas', 'közepes', 'közepes barna vörös barna', 'szeret labdázni', 1, 0, '2021-08-28 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/98.jpg'),
(57, 'Grész', '2020-07-24', 3, 'kan', 'Abruzzói juhászkutya', 'közepes', 1, 2, 'foghiányos', 'közepes', 'közepes vörös barna zöld', 'szeret ölelni', 1, 0, '2022-08-19 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/86.jpg'),
(58, 'Magnipuss', '2017-11-08', 6, 'szuka', 'Fekete sery', 'rossz', 0, 23, 'fogszuvas', 'egészséges', 'közepes szürke vörös zöld', 'be van gyulladva a füle', 1, 0, '2022-09-15 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/165.jpg'),
(59, 'Vanília', '2019-12-20', 4, 'kan', 'Simaszőrű foxterrier', 'rossz', 1, 26, 'fogszuvas', 'rossz', 'közepes fehér vörös barna', 'szeret játszani', 1, 0, '2021-06-06 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/187.jpg'),
(60, 'Maya', '2017-09-08', 6, 'szuka', 'Fehérorosz juhászkutya vagy kelet-európai juhászkutya', 'közepes', 0, 8, 'egészséges', 'egészséges', 'közepes szürke vörös kék', 'szeret játszani', 1, 0, '2022-09-24 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/172.jpg'),
(61, 'Inez', '2018-04-18', 5, 'kan', 'Cirneco dell’Etna', 'egészséges', 1, 21, 'egészséges', 'egészséges', 'közepes tigriscsíkos barna zöld', 'szeret ölelni', 1, 0, '2021-04-20 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/151.jpg'),
(62, 'Sakál', '2020-05-28', 3, 'szuka', 'Vadkacsavadász retriever', 'közepes', 0, 13, 'foghiányos', 'rossz', 'kicsi fekete barna barna', 'szeret futkosni a kertben', 1, 0, '2021-12-03 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/33.jpg'),
(63, 'Don', '2019-01-23', 4, 'kan', 'Bulldog', 'közepes', 0, 8, 'foghiányos', 'közepes', 'kicsi arany fekete barna', 'szeret sétálni a parkban', 1, 0, '2022-11-09 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/161.jpg'),
(64, 'Ajax', '2019-04-17', 4, 'kan', 'Saage kochee', 'rossz', 0, 28, 'fogszuvas', 'egészséges', 'nagy fekete sötétbarna kék', 'szeret játszani', 1, 0, '2022-10-06 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/118.jpg'),
(65, 'Igloo', '2018-09-05', 5, 'szuka', 'Kis luzerni kopó', 'közepes', 0, 1, 'foghiányos', 'rossz', 'kicsi sárga vörös kék', 'szeret fürdeni a tóban', 1, 0, '2021-07-14 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/108.jpg'),
(66, 'Pedró', '2020-12-03', 3, 'szuka', 'Saint-germaini vizsla', 'közepes', 1, 5, 'egészséges', 'rossz', 'kicsi fekete rózsaszín zöld', 'kedves és barátságos', 1, 0, '2022-12-10 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/3.jpg'),
(67, 'Okonor', '2019-06-16', 4, 'szuka', 'Lancashire heeler', 'egészséges', 1, 3, 'fogszuvas', 'rossz', 'közepes fekete vörös zöld', 'szeret sétálni a parkban', 1, 0, '2021-03-13 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/31.jpg'),
(68, 'Gerry', '2015-06-03', 8, 'kan', 'Clumber spániel', 'egészséges', 0, 23, 'foghiányos', 'egészséges', 'nagy szürke rózsaszín zöld', 'szeret az ablakban ülni', 1, 0, '2022-12-05 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/106.jpg'),
(69, 'Jázmin', '2019-01-11', 4, 'kan', 'Kínai kopasz kutya', 'közepes', 1, 2, 'foghiányos', 'rossz', 'nagy vörös barna barna', 'szeret játszani a labdával', 1, 0, '2021-01-28 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/142.jpg'),
(70, 'Jupiter', '2020-04-22', 3, 'szuka', 'Patterdale terrier', 'közepes', 0, 20, 'foghiányos', 'rossz', 'nagy tigriscsíkos barna kék', 'kedveli a sétákat', 1, 0, '2022-03-14 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/92.jpg'),
(71, 'Axel', '2018-04-26', 5, 'szuka', 'Lakeland terrier', 'egészséges', 0, 24, 'egészséges', 'rossz', 'kicsi fekete fekete zöld', 'köröm vágást igényel', 1, 0, '2021-10-09 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/142.jpg'),
(72, 'Grész', '2015-05-24', 8, 'kan', 'Olasz vizsla', 'rossz', 1, 21, 'foghiányos', 'közepes', 'nagy arany barna kék', 'köröm vágást igényel', 1, 0, '2021-07-03 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/154.jpg'),
(73, 'Vitéz', '2020-07-09', 3, 'kan', 'Sealyham terrier', 'rossz', 1, 2, 'foghiányos', 'közepes', 'közepes sárga barna kék', 'szeret fürdeni a tóban', 1, 0, '2021-07-25 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/93.jpg'),
(74, 'Boomer', '2018-03-02', 5, 'szuka', 'Spániel', 'rossz', 1, 3, 'foghiányos', 'közepes', 'közepes sárga sötétbarna kék', 'imád aludni', 1, 0, '2021-02-24 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/31.jpg'),
(75, 'Lili', '2015-11-15', 8, 'kan', 'Kerry blue terrier', 'egészséges', 0, 21, 'fogszuvas', 'egészséges', 'kicsi sárga vörös barna', 'szeret labdázni', 1, 0, '2021-06-01 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/95.jpg'),
(76, 'Oszkár', '2018-06-12', 5, 'szuka', 'Border terrier', 'közepes', 0, 11, 'foghiányos', 'egészséges', 'közepes vörös barna barna', 'szeret sétálni a parkban', 1, 0, '2021-01-10 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/138.jpg'),
(77, 'Félix', '2020-12-10', 3, 'szuka', 'Óriás schnauzer', 'egészséges', 1, 27, 'fogszuvas', 'egészséges', 'közepes arany fekete barna', 'szeret ölelni', 1, 0, '2021-01-06 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/126.jpg'),
(78, 'Kelly', '2020-01-18', 3, 'kan', 'Belga vizsla', 'egészséges', 0, 21, 'foghiányos', 'egészséges', 'közepes fekete barna barna', 'kedveli a sétákat', 1, 0, '2022-05-06 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/114.jpg'),
(79, 'Lili', '2019-04-26', 4, 'kan', 'Schipperke', 'rossz', 1, 10, 'fogszuvas', 'rossz', 'nagy tigriscsíkos rózsaszín kék', 'szeret játszani', 1, 0, '2021-06-01 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/20.jpg'),
(80, 'Nimród', '2015-04-25', 8, 'szuka', 'Bőrtokos kalippó', 'közepes', 0, 5, 'foghiányos', 'egészséges', 'közepes szürke rózsaszín kék', 'szeret futkosni a kertben', 1, 0, '2022-02-22 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/209.jpg'),
(81, 'Milli', '2016-09-21', 7, 'szuka', 'Orosz toy terrier', 'egészséges', 1, 7, 'foghiányos', 'rossz', 'kicsi szürke vörös barna', 'kedves és barátságos', 1, 0, '2022-09-23 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/188.jpg'),
(82, 'Ofélia', '2016-01-07', 7, 'szuka', 'Rhodesian ridgeback (Afrikai oroszlánkutya)', 'egészséges', 1, 13, 'foghiányos', 'rossz', 'nagy sárga rózsaszín kék', 'szeret játszani', 1, 0, '2021-09-07 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/140.jpg'),
(83, 'Ládikó', '2015-12-05', 8, 'kan', 'Keverék', 'rossz', 0, 5, 'fogszuvas', 'rossz', 'kicsi fehér vörös kék', 'szeret játszani a labdával', 1, 0, '2021-02-18 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/68.jpg'),
(84, 'Panka', '2017-04-21', 6, 'szuka', 'Isztriai kopó', 'közepes', 0, 2, 'foghiányos', 'egészséges', 'közepes fekete fekete kék', 'kedveli a sétákat', 1, 0, '2022-03-03 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/101.jpg'),
(85, 'Zsömi', '2018-10-20', 5, 'kan', 'Óangol juhászkutya', 'közepes', 1, 3, 'foghiányos', 'közepes', 'nagy szürke barna barna', 'szeret labdázni', 1, 0, '2021-04-17 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/196.jpg'),
(86, 'Glédis', '2016-07-23', 7, 'kan', 'Nagy angol-francia kopó', 'rossz', 0, 16, 'fogszuvas', 'rossz', 'kicsi arany sötétbarna kék', 'több mozgást igényel', 1, 0, '2021-07-15 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/164.jpg'),
(87, 'Goldy', '2016-02-19', 7, 'kan', 'Lundehund', 'egészséges', 1, 9, 'fogszuvas', 'rossz', 'nagy sárga barna kék', 'szeret futkosni a kertben', 1, 0, '2022-05-25 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/62.jpg'),
(88, 'Apolló', '2020-06-01', 3, 'szuka', 'Poitevin', 'rossz', 0, 10, 'foghiányos', 'rossz', 'közepes tigriscsíkos fekete zöld', 'szeret játszani a labdával', 1, 0, '2022-05-14 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/91.jpg'),
(89, 'Igric', '2016-03-15', 7, 'szuka', 'Szávavölgyi kopó', 'rossz', 1, 30, 'egészséges', 'rossz', 'közepes sárga sötétbarna kék', 'szeret játszani', 1, 0, '2022-03-10 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/62.jpg'),
(90, 'Jonathan', '2020-12-24', 3, 'kan', 'Orosz toy terrier', 'egészséges', 0, 27, 'egészséges', 'rossz', 'kicsi foltos barna barna', 'szeret labdázni', 1, 0, '2021-08-04 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/118.jpg'),
(91, 'FuFu', '2020-12-25', 3, 'kan', 'Beauce-i juhászkutya', 'egészséges', 0, 28, 'fogszuvas', 'egészséges', 'kicsi szürke sötétbarna barna', 'szeret kutyakölykökkel játszani', 1, 0, '2022-02-19 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/57.jpg'),
(92, 'Karesz', '2015-10-12', 8, 'szuka', 'Soft coated wheaten terrier', 'rossz', 0, 19, 'egészséges', 'egészséges', 'kicsi barna vörös zöld', 'szeret játszani a labdával', 1, 0, '2021-12-27 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/120.jpg'),
(93, 'Jasper', '2018-11-06', 5, 'kan', 'Nagy svájci havasi kutya', 'közepes', 0, 6, 'egészséges', 'közepes', 'nagy fehér barna kék', 'be van gyulladva a füle', 1, 0, '2021-11-17 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/53.jpg'),
(94, 'Jumbó', '2016-04-11', 7, 'szuka', 'Norrbotteni spicc', 'közepes', 0, 17, 'egészséges', 'egészséges', 'nagy szürke barna barna', 'szeret nyugodtan pihenni', 1, 0, '2021-01-11 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/97.jpg'),
(95, 'Gandhi', '2016-07-21', 7, 'szuka', 'Bourbonnais-i vizsla', 'közepes', 0, 22, 'foghiányos', 'közepes', 'közepes arany vörös kék', 'szeret labdázni', 1, 0, '2021-08-11 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/176.jpg'),
(96, 'Vénusz', '2015-06-15', 8, 'kan', 'Billy', 'közepes', 1, 18, 'foghiányos', 'egészséges', 'közepes foltos rózsaszín barna', 'szeret ölelni', 1, 0, '2022-05-12 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/62.jpg'),
(97, 'Illés', '2019-08-18', 4, 'szuka', 'Keverék', 'rossz', 0, 24, 'fogszuvas', 'egészséges', 'közepes sárga vörös zöld', 'köröm vágást igényel', 1, 0, '2022-01-24 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/25.jpg'),
(98, 'Nimród', '2019-06-11', 4, 'szuka', 'Gordon szetter', 'egészséges', 0, 21, 'fogszuvas', 'egészséges', 'kicsi barna barna kék', 'szeret nyugodtan pihenni', 1, 0, '2022-10-19 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/180.jpg'),
(99, 'Limbó', '2016-09-04', 7, 'kan', 'Perzsa agár', 'közepes', 0, 20, 'foghiányos', 'egészséges', 'közepes foltos vörös zöld', 'több mozgást igényel', 1, 0, '2021-06-22 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/133.jpg'),
(100, 'Parádé', '2015-02-18', 8, 'szuka', 'Welsh terrier', 'közepes', 1, 5, 'fogszuvas', 'rossz', 'közepes arany sötétbarna barna', 'szeret sétálni a parkban', 1, 0, '2022-07-09 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/64.jpg'),
(101, 'Bella', '2017-04-03', 6, 'kan', 'Eurázsiai', 'egészséges', 1, 26, 'fogszuvas', 'egészséges', 'kicsi fehér rózsaszín zöld', 'be van gyulladva a füle', 1, 0, '2022-10-28 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/168.jpg'),
(102, 'Jázmina', '2019-08-07', 4, 'kan', 'Ír terrier', 'közepes', 0, 8, 'egészséges', 'egészséges', 'nagy tigriscsíkos vörös zöld', 'kedves és barátságos', 1, 0, '2021-05-19 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/149.jpg'),
(103, 'Félix', '2016-04-07', 7, 'kan', 'Anatóliai juhászkutya', 'rossz', 0, 8, 'foghiányos', 'egészséges', 'közepes szürke fekete kék', 'szeret játszani a labdával', 1, 0, '2021-12-15 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/203.jpg'),
(104, 'Zorró', '2019-06-16', 4, 'szuka', 'Grönlandi kutya', 'rossz', 1, 29, 'egészséges', 'egészséges', 'kicsi sárga vörös zöld', 'szeret úszni', 1, 0, '2021-03-03 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/136.jpg'),
(105, 'Sátán', '2017-04-04', 6, 'kan', 'Skót szarvasagár', 'rossz', 0, 12, 'fogszuvas', 'egészséges', 'kicsi vörös sötétbarna zöld', 'szeret játszani', 1, 0, '2022-06-02 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/89.jpg'),
(106, 'Zsozsó', '2020-04-19', 3, 'kan', 'Bullterrier', 'rossz', 1, 3, 'egészséges', 'közepes', 'közepes fehér rózsaszín zöld', 'szeret úszni', 1, 0, '2022-04-21 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/163.jpg'),
(107, 'Ibis', '2018-01-21', 5, 'kan', 'Vendée-i griffonkopó', 'egészséges', 0, 16, 'foghiányos', 'egészséges', 'nagy fehér vörös barna', 'szeret ölelni', 1, 0, '2021-08-22 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/114.jpg'),
(108, 'Stuki', '2019-03-04', 4, 'szuka', 'Manchester terrier', 'közepes', 0, 27, 'fogszuvas', 'rossz', 'nagy fekete barna zöld', 'szeret futkosni a kertben', 1, 0, '2021-08-15 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/168.jpg'),
(109, 'Pedró', '2016-12-12', 7, 'kan', 'Amerikai Bulldog', 'egészséges', 0, 6, 'foghiányos', 'közepes', 'kicsi fehér rózsaszín barna', 'szeret futkosni a kertben', 1, 0, '2021-06-10 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/26.jpg'),
(110, 'Jumbó', '2020-07-02', 3, 'kan', 'Középspitz', 'rossz', 0, 19, 'egészséges', 'közepes', 'nagy vörös rózsaszín barna', 'szeret fürdeni a tóban', 1, 0, '2021-03-22 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/185.jpg'),
(111, 'Szeti', '2016-07-24', 7, 'kan', 'Gordon szetter', 'rossz', 1, 21, 'foghiányos', 'közepes', 'nagy sárga vörös barna', 'köröm vágást igényel', 1, 0, '2021-04-28 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/75.jpg'),
(112, 'Héra', '2017-01-04', 6, 'szuka', 'Olasz vizsla', 'egészséges', 1, 26, 'foghiányos', 'egészséges', 'közepes vörös barna kék', 'több mozgást igényel', 1, 0, '2022-11-07 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/153.jpg'),
(113, 'Gerry', '2016-03-14', 7, 'szuka', 'Coton de tuléar', 'egészséges', 1, 21, 'foghiányos', 'rossz', 'kicsi sárga vörös barna', 'kedves és barátságos', 1, 0, '2022-03-14 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/40.jpg'),
(114, 'Bütyök', '2017-05-04', 6, 'szuka', 'Újfundlandi', 'rossz', 1, 11, 'egészséges', 'egészséges', 'kicsi sárga barna barna', 'szeret nyugodtan pihenni', 1, 0, '2021-09-25 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/139.jpg'),
(115, 'Ajax', '2018-01-20', 5, 'szuka', 'Husky', 'egészséges', 0, 28, 'egészséges', 'rossz', 'közepes arany rózsaszín kék', 'bélférges', 1, 0, '2022-11-04 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/114.jpg'),
(116, 'Pongó', '2019-03-05', 4, 'kan', 'Belga masztiff', 'közepes', 1, 24, 'foghiányos', 'közepes', 'nagy foltos vörös barna', 'kedves és barátságos', 1, 0, '2021-12-17 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/122.jpg'),
(117, 'Inez', '2018-08-01', 5, 'kan', 'Keverék', 'rossz', 0, 12, 'fogszuvas', 'egészséges', 'nagy tigriscsíkos vörös kék', 'kedveli a sétákat', 1, 0, '2022-07-20 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/145.jpg'),
(118, 'Ballu', '2017-05-06', 6, 'kan', 'Bukovinai pásztorkutya', 'közepes', 0, 22, 'foghiányos', 'rossz', 'közepes fekete sötétbarna barna', 'köröm vágást igényel', 1, 0, '2021-10-24 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/28.jpg'),
(119, 'Maggie', '2019-02-10', 4, 'kan', 'Fríz vízikutya', 'közepes', 1, 13, 'fogszuvas', 'közepes', 'közepes fehér barna zöld', 'szeret úszni', 1, 0, '2021-11-10 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/92.jpg'),
(120, 'Orlando', '2018-11-24', 5, 'szuka', 'Savoye-i pásztorkutya', 'közepes', 0, 10, 'foghiányos', 'rossz', 'nagy vörös rózsaszín barna', 'szeret kutyakölykökkel játszani', 1, 0, '2021-08-07 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/142.jpg'),
(121, 'Nyikita', '2020-03-13', 3, 'kan', 'Portugál juhászkutya', 'egészséges', 1, 11, 'egészséges', 'közepes', 'közepes sárga vörös barna', 'szeret sétálni a parkban', 1, 0, '2022-04-18 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/206.jpg'),
(122, 'Nimród', '2015-12-15', 8, 'szuka', 'Thai ridgeback', 'rossz', 1, 7, 'fogszuvas', 'rossz', 'közepes vörös barna barna', 'szeret fürdeni a tóban', 1, 0, '2022-06-27 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/169.jpg'),
(123, 'Rézi', '2015-08-24', 8, 'kan', 'Keverék', 'rossz', 1, 14, 'egészséges', 'egészséges', 'nagy fekete rózsaszín zöld', 'szeret ölelni', 1, 0, '2021-02-19 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/142.jpg'),
(124, 'Szetti', '2015-11-22', 8, 'kan', 'Berni pásztorkutya', 'rossz', 0, 23, 'fogszuvas', 'rossz', 'kicsi barna barna kék', 'imád aludni', 1, 0, '2021-05-26 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/96.jpg'),
(125, 'Ádáz', '2018-11-18', 5, 'szuka', 'Belga masztiff', 'rossz', 0, 12, 'fogszuvas', 'rossz', 'nagy tigriscsíkos barna kék', 'imád aludni', 1, 0, '2022-05-08 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/104.jpg'),
(126, 'Zola', '2018-07-01', 5, 'kan', 'Mallorcai masztiff', 'rossz', 0, 22, 'egészséges', 'egészséges', 'közepes barna barna kék', 'köröm vágást igényel', 1, 0, '2021-05-05 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/14.jpg'),
(127, 'Shiva', '2017-08-01', 6, 'kan', 'Shikoku inu', 'közepes', 0, 4, 'fogszuvas', 'egészséges', 'kicsi sárga barna kék', 'szeret játszani a labdával', 1, 0, '2021-08-13 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/122.jpg'),
(128, 'Milli', '2019-08-06', 4, 'kan', 'Kerry blue terrier', 'egészséges', 0, 21, 'egészséges', 'rossz', 'kicsi foltos rózsaszín barna', 'szeret fürdeni a tóban', 1, 0, '2021-07-19 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/31.jpg'),
(129, 'Csöpi', '2017-09-16', 6, 'kan', 'Angol cocker spániel', 'rossz', 1, 2, 'egészséges', 'közepes', 'kicsi tigriscsíkos vörös barna', 'szeret fürdeni a tóban', 1, 0, '2022-07-15 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/154.jpg'),
(130, 'Ládikó', '2016-10-28', 7, 'kan', 'Brazil kopó', 'rossz', 1, 18, 'foghiányos', 'rossz', 'nagy foltos vörös kék', 'szeret játszani a labdával', 1, 0, '2021-02-24 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/150.jpg'),
(131, 'Lassie', '2015-02-15', 8, 'szuka', 'Vörös ír szetter', 'egészséges', 1, 12, 'egészséges', 'rossz', 'nagy szürke barna kék', 'be van gyulladva a füle', 1, 0, '2021-05-02 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/32.jpg'),
(132, 'Viti', '2018-09-07', 5, 'szuka', 'Német kopó', 'rossz', 0, 18, 'fogszuvas', 'rossz', 'nagy vörös sötétbarna barna', 'szeret futkosni a kertben', 1, 0, '2021-01-25 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/6.jpg'),
(133, 'Oblix', '2020-02-08', 3, 'kan', 'Brabanti kis griffon', 'egészséges', 1, 21, 'egészséges', 'közepes', 'kicsi fehér rózsaszín kék', 'több mozgást igényel', 1, 0, '2021-04-23 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/134.jpg'),
(134, 'Éva', '2019-04-17', 4, 'kan', 'Berni kopó', 'közepes', 0, 9, 'foghiányos', 'rossz', 'közepes fekete vörös barna', 'szeret ölelni', 1, 0, '2021-05-18 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/156.jpg'),
(135, 'Jumbó', '2016-07-15', 7, 'kan', 'Barbet', 'közepes', 0, 30, 'fogszuvas', 'közepes', 'közepes tigriscsíkos rózsaszín barna', 'szeret úszni', 1, 0, '2022-08-12 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/145.jpg'),
(136, 'Jonathan', '2015-12-27', 8, 'kan', 'Lajka', 'közepes', 0, 22, 'egészséges', 'egészséges', 'közepes fehér rózsaszín zöld', 'szeret ölelni', 1, 0, '2022-10-08 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/108.jpg'),
(137, 'Maggie', '2016-04-23', 7, 'kan', 'Lurcher', 'egészséges', 0, 7, 'egészséges', 'közepes', 'kicsi tigriscsíkos fekete zöld', 'köröm vágást igényel', 1, 0, '2022-06-28 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/9.jpg'),
(138, 'Vacak', '2018-07-06', 5, 'szuka', 'Olasz volpino', 'egészséges', 1, 6, 'foghiányos', 'rossz', 'kicsi barna sötétbarna zöld', 'szeret játszani a labdával', 1, 0, '2022-05-18 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/127.jpg'),
(139, 'Keiko', '2016-08-17', 7, 'szuka', 'Simaszőrű portugál kopó', 'rossz', 1, 9, 'foghiányos', 'rossz', 'kicsi barna rózsaszín kék', 'szeret futkosni a kertben', 1, 0, '2021-03-04 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/61.jpg'),
(140, 'Pedró', '2015-10-13', 8, 'kan', 'Komondor  Magyarország', 'közepes', 1, 7, 'fogszuvas', 'egészséges', 'kicsi fehér vörös kék', 'kedveli a sétákat', 1, 0, '2022-03-16 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/72.jpg'),
(141, 'Gandhi', '2016-12-13', 7, 'szuka', 'Angol cocker spániel', 'közepes', 0, 15, 'fogszuvas', 'rossz', 'nagy vörös rózsaszín zöld', 'szeret úszni', 1, 0, '2022-03-26 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/150.jpg'),
(142, 'Shiva', '2019-10-17', 4, 'kan', 'Afrikai oroszlánkutya', 'rossz', 1, 24, 'egészséges', 'rossz', 'közepes szürke rózsaszín kék', 'köröm vágást igényel', 1, 0, '2022-08-26 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/95.jpg'),
(143, 'Melák', '2020-11-17', 3, 'kan', 'Erdélyi kopó  Magyarország', 'rossz', 1, 30, 'foghiányos', 'közepes', 'kicsi fekete vörös zöld', 'szeret sétálni a parkban', 1, 0, '2021-05-17 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/133.jpg'),
(144, 'Bodri', '2016-03-22', 7, 'kan', 'Basset hound', 'közepes', 1, 13, 'foghiányos', 'egészséges', 'nagy vörös fekete barna', 'szeret játszani', 1, 0, '2021-03-25 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/80.jpg'),
(145, 'Wolf', '2018-05-17', 5, 'kan', 'Máltai selyemkutya', 'közepes', 1, 8, 'fogszuvas', 'egészséges', 'közepes arany fekete barna', 'szeret ölelni', 1, 0, '2021-06-18 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/15.jpg'),
(146, 'Bella', '2015-08-05', 8, 'szuka', 'Észt kopó', 'rossz', 1, 22, 'egészséges', 'rossz', 'nagy vörös vörös kék', 'szeret futkosni a kertben', 1, 0, '2022-09-27 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/55.jpg'),
(147, 'Bözsi', '2018-07-23', 5, 'kan', 'Drótszőrű foxterrier', 'rossz', 0, 1, 'fogszuvas', 'rossz', 'közepes tigriscsíkos vörös barna', 'szeret az ablakban ülni', 1, 0, '2022-07-18 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/27.jpg'),
(148, 'Bugatti', '2019-07-26', 4, 'kan', 'Hokkaido inu', 'rossz', 1, 17, 'foghiányos', 'közepes', 'kicsi barna sötétbarna zöld', 'több mozgást igényel', 1, 0, '2022-01-20 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/56.jpg'),
(149, 'Melák', '2019-11-02', 4, 'szuka', 'Orosz-európai lajka', 'közepes', 1, 1, 'egészséges', 'egészséges', 'nagy fehér vörös zöld', 'be van gyulladva a füle', 1, 0, '2022-11-09 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/145.jpg'),
(150, 'Nina', '2020-01-03', 3, 'szuka', 'Billy', 'egészséges', 1, 19, 'fogszuvas', 'közepes', 'kicsi arany barna kék', 'be van gyulladva a füle', 1, 0, '2021-11-05 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/135.jpg'),
(151, 'Gombi', '2016-08-12', 7, 'kan', 'Cardigan welsh corgi', 'egészséges', 1, 7, 'fogszuvas', 'közepes', 'kicsi sárga fekete kék', 'szeret úszni', 1, 0, '2022-05-07 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/25.jpg'),
(152, 'Jimmy', '2020-10-03', 3, 'kan', 'Simaszőrű foxterrier', 'rossz', 0, 16, 'foghiányos', 'közepes', 'nagy fekete rózsaszín barna', 'szeret fürdeni a tóban', 1, 0, '2021-01-23 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/137.jpg'),
(153, 'Jázmin', '2017-08-13', 6, 'szuka', 'Ónémet juhászkutya', 'egészséges', 1, 16, 'egészséges', 'rossz', 'közepes arany fekete zöld', 'több mozgást igényel', 1, 0, '2021-01-09 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/165.jpg'),
(154, 'Vanília', '2019-06-08', 4, 'kan', 'Kalag Tazi', 'közepes', 0, 30, 'egészséges', 'egészséges', 'közepes barna vörös kék', 'szeret fürdeni a tóban', 1, 0, '2022-03-16 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/32.jpg'),
(155, 'Úrfi', '2020-07-13', 3, 'szuka', 'Kis jurai kopó', 'egészséges', 0, 7, 'fogszuvas', 'közepes', 'kicsi fehér vörös barna', 'köröm vágást igényel', 1, 0, '2022-06-18 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/102.jpg'),
(156, 'Jorgosz', '2017-06-19', 6, 'kan', 'Sealyham terrier', 'rossz', 0, 17, 'fogszuvas', 'rossz', 'közepes arany rózsaszín barna', 'szeret kutyakölykökkel játszani', 1, 0, '2021-03-05 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/30.jpg'),
(157, 'Keisha', '2017-01-06', 6, 'szuka', 'Közép uszkár', 'rossz', 0, 18, 'egészséges', 'közepes', 'közepes tigriscsíkos fekete kék', 'szeret játszani', 1, 0, '2021-03-12 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/65.jpg'),
(158, 'Jenny', '2018-03-25', 5, 'szuka', 'Ausztrál juhászkutya', 'rossz', 1, 8, 'egészséges', 'közepes', 'közepes fekete sötétbarna barna', 'szeret labdázni', 1, 0, '2021-11-07 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/7.jpg'),
(159, 'Nessy', '2018-03-11', 5, 'szuka', 'Magyar vizsla', 'rossz', 1, 25, 'foghiányos', 'rossz', 'kicsi foltos vörös barna', 'szeret kutyakölykökkel játszani', 1, 0, '2021-09-24 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/142.jpg'),
(160, 'Szofi', '2016-09-01', 7, 'szuka', 'Spanyol masztiff', 'közepes', 1, 24, 'foghiányos', 'közepes', 'közepes sárga vörös kék', 'szeret ölelni', 1, 0, '2022-03-20 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/179.jpg'),
(161, 'Kleó', '2018-08-27', 5, 'szuka', 'Kánaán kutya', 'rossz', 0, 27, 'fogszuvas', 'közepes', 'kicsi tigriscsíkos sötétbarna zöld', 'kedves és barátságos', 1, 0, '2021-07-20 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/63.jpg'),
(162, 'Hasszán', '2016-10-18', 7, 'szuka', 'Jurai kopó', 'közepes', 0, 13, 'egészséges', 'egészséges', 'kicsi tigriscsíkos barna kék', 'szeret nyugodtan pihenni', 1, 0, '2022-10-16 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/31.jpg'),
(163, 'Csöpi', '2018-02-21', 5, 'szuka', 'Orosz toy terrier', 'közepes', 1, 5, 'egészséges', 'egészséges', 'kicsi barna fekete barna', 'szeret nyugodtan pihenni', 1, 0, '2021-12-04 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/115.jpg'),
(164, 'Inez', '2016-01-16', 7, 'kan', 'Appenzelli havasi kutya', 'rossz', 1, 21, 'foghiányos', 'rossz', 'kicsi szürke fekete zöld', 'bélférges', 1, 0, '2021-10-11 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/188.jpg'),
(165, 'Shiva', '2020-01-10', 3, 'szuka', 'Dunker', 'közepes', 0, 10, 'fogszuvas', 'közepes', 'nagy arany vörös zöld', 'be van gyulladva a füle', 1, 0, '2021-02-22 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/78.jpg'),
(166, 'Lehár', '2019-02-10', 4, 'szuka', 'Border terrier', 'egészséges', 0, 6, 'egészséges', 'közepes', 'kicsi foltos fekete barna', 'kedves és barátságos', 1, 0, '2021-12-16 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/145.jpg'),
(167, 'Ádáz', '2019-04-07', 4, 'kan', 'Lakeland terrier', 'közepes', 1, 20, 'foghiányos', 'egészséges', 'közepes vörös barna zöld', 'szeret futkosni a kertben', 1, 0, '2022-09-15 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/187.jpg'),
(168, 'Destiny', '2017-03-23', 6, 'szuka', 'Francia bulldog', 'rossz', 0, 3, 'fogszuvas', 'rossz', 'közepes tigriscsíkos barna zöld', 'szeret játszani', 1, 0, '2022-09-23 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/125.jpg'),
(169, 'Hobbit', '2020-03-27', 3, 'szuka', 'Spanyol vízikutya', 'közepes', 0, 20, 'foghiányos', 'rossz', 'nagy tigriscsíkos fekete zöld', 'szeret játszani', 1, 0, '2022-09-06 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/90.jpg'),
(170, 'Polli', '2016-07-25', 7, 'kan', 'Groenendael', 'rossz', 0, 14, 'egészséges', 'rossz', 'kicsi vörös sötétbarna barna', 'szeret sétálni a parkban', 1, 0, '2022-09-12 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/105.jpg'),
(171, 'Gandhi', '2016-12-27', 7, 'szuka', 'Hamilton-kopó', 'rossz', 1, 9, 'fogszuvas', 'közepes', 'nagy barna sötétbarna barna', 'szeret ölelni', 1, 0, '2021-05-15 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/19.jpg'),
(172, 'Dorel', '2018-08-25', 5, 'szuka', 'Blue lacy', 'közepes', 1, 17, 'egészséges', 'rossz', 'nagy sárga vörös zöld', 'szeret játszani', 1, 0, '2022-01-15 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/153.jpg'),
(173, 'Zafír', '2015-03-07', 8, 'szuka', 'bolonka cvetna', 'egészséges', 0, 24, 'foghiányos', 'közepes', 'nagy sárga vörös kék', 'szeret futkosni a kertben', 1, 0, '2021-01-27 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/39.jpg'),
(174, 'Rea', '2017-07-10', 6, 'kan', 'Padilokoon', 'közepes', 0, 23, 'egészséges', 'egészséges', 'nagy fehér sötétbarna zöld', 'be van gyulladva a füle', 1, 0, '2021-04-21 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/21.jpg'),
(175, 'Csülök', '2019-10-17', 4, 'kan', 'Sussexi spániel', 'rossz', 1, 1, 'egészséges', 'közepes', 'nagy arany fekete barna', 'több mozgást igényel', 1, 0, '2021-01-22 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/55.jpg'),
(176, 'Jonathan', '2017-02-17', 6, 'kan', 'Vizsla', 'közepes', 0, 22, 'egészséges', 'egészséges', 'nagy vörös fekete kék', 'be van gyulladva a füle', 1, 0, '2021-03-21 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/110.jpg'),
(177, 'Téra', '2020-12-16', 3, 'kan', 'Orosz fekete terrier', 'közepes', 1, 16, 'fogszuvas', 'közepes', 'kicsi fekete fekete barna', 'be van gyulladva a füle', 1, 0, '2022-03-28 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/193.jpg'),
(178, 'Dean', '2020-06-08', 3, 'kan', 'Drótszőrű isztriai kopó', 'közepes', 0, 6, 'fogszuvas', 'egészséges', 'nagy barna fekete barna', 'szeret kutyakölykökkel játszani', 1, 0, '2021-07-04 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/93.jpg'),
(179, 'Sonny', '2019-12-12', 4, 'kan', 'Lakeland terrier', 'rossz', 0, 27, 'fogszuvas', 'közepes', 'közepes foltos sötétbarna zöld', 'kedveli a sétákat', 1, 0, '2021-09-09 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/164.jpg'),
(180, 'Morti', '2015-09-22', 8, 'kan', 'Magyar agár', 'rossz', 0, 17, 'egészséges', 'egészséges', 'közepes barna rózsaszín zöld', 'be van gyulladva a füle', 1, 0, '2021-08-17 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/112.jpg'),
(181, 'Rénó', '2016-02-15', 7, 'szuka', 'Kangaroo Dog', 'közepes', 1, 28, 'egészséges', 'közepes', 'nagy fekete vörös barna', 'szeret játszani a labdával', 1, 0, '2022-01-23 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/7.jpg'),
(182, 'Wolf', '2015-01-04', 8, 'szuka', 'Bandog', 'egészséges', 0, 18, 'egészséges', 'közepes', 'közepes sárga fekete zöld', 'kedveli a sétákat', 1, 0, '2021-04-11 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/16.jpg'),
(183, 'Ádáz', '2017-02-27', 6, 'kan', 'Toy uszkár', 'egészséges', 0, 20, 'egészséges', 'közepes', 'nagy vörös vörös kék', 'szeret játszani a labdával', 1, 0, '2021-07-16 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/174.jpg'),
(184, 'Kelly', '2019-02-05', 4, 'kan', 'Tervueren', 'egészséges', 1, 14, 'foghiányos', 'rossz', 'közepes foltos vörös kék', 'több mozgást igényel', 1, 0, '2022-12-12 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/14.jpg'),
(185, 'Szofi', '2016-06-26', 7, 'szuka', 'Mioritic pásztorkutya', 'közepes', 0, 5, 'fogszuvas', 'egészséges', 'közepes arany rózsaszín kék', 'köröm vágást igényel', 1, 0, '2022-06-17 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/62.jpg'),
(186, 'Igloo', '2015-08-03', 8, 'szuka', 'Keverék', 'egészséges', 0, 11, 'egészséges', 'közepes', 'nagy szürke sötétbarna kék', 'szeret kutyakölykökkel játszani', 1, 0, '2021-04-06 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/110.jpg'),
(187, 'Lewis', '2016-02-02', 7, 'szuka', 'Lagotto romagnolo', 'egészséges', 0, 22, 'egészséges', 'közepes', 'nagy barna fekete kék', 'kedves és barátságos', 1, 0, '2021-06-18 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/129.jpg'),
(188, 'Sparco', '2017-04-19', 6, 'szuka', 'Argentin dog', 'egészséges', 0, 23, 'foghiányos', 'egészséges', 'kicsi fehér rózsaszín barna', 'kedveli a sétákat', 1, 0, '2022-07-04 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/131.jpg'),
(189, 'Zsozsó', '2019-10-09', 4, 'kan', 'Lagotto romagnolo', 'egészséges', 0, 26, 'foghiányos', 'rossz', 'közepes vörös vörös zöld', 'szeret kutyakölykökkel játszani', 1, 0, '2022-10-22 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/37.jpg'),
(190, 'Jockey', '2016-02-27', 7, 'kan', 'Schiller-kopó', 'közepes', 1, 28, 'egészséges', 'közepes', 'nagy foltos sötétbarna zöld', 'szeret úszni', 1, 0, '2022-11-20 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/7.jpg'),
(191, 'Jasper', '2015-04-19', 8, 'kan', 'Törpe schnauzer', 'rossz', 1, 16, 'foghiányos', 'egészséges', 'kicsi szürke rózsaszín zöld', 'szeret fürdeni a tóban', 1, 0, '2022-04-10 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/110.jpg'),
(192, 'Azték', '2017-03-04', 6, 'kan', 'Olasz agár', 'rossz', 0, 5, 'egészséges', 'közepes', 'nagy tigriscsíkos fekete kék', 'kedveli a sétákat', 1, 0, '2022-01-21 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/144.jpg'),
(193, 'Suzy', '2015-08-01', 8, 'szuka', 'Lagotto romagnolo', 'egészséges', 0, 7, 'fogszuvas', 'közepes', 'nagy arany sötétbarna zöld', 'szeret játszani a labdával', 1, 0, '2021-07-11 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/120.jpg'),
(194, 'Zsömi', '2017-02-04', 6, 'szuka', 'Orosz-európai lajka', 'közepes', 1, 28, 'egészséges', 'közepes', 'közepes barna rózsaszín zöld', 'szeret kutyakölykökkel játszani', 1, 0, '2022-01-26 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/154.jpg'),
(195, 'Nimród', '2020-01-22', 3, 'szuka', 'Angol agár', 'rossz', 1, 21, 'egészséges', 'egészséges', 'nagy szürke rózsaszín kék', 'bélférges', 1, 0, '2021-06-10 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/165.jpg'),
(196, 'Vacak', '2018-10-06', 5, 'kan', 'Norwich terrier', 'egészséges', 0, 18, 'foghiányos', 'rossz', 'közepes sárga vörös kék', 'szeret játszani a labdával', 1, 0, '2021-11-12 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/2.jpg'),
(197, 'Molly', '2020-04-14', 3, 'szuka', 'Brazil terrier', 'egészséges', 1, 22, 'foghiányos', 'rossz', 'kicsi fehér barna kék', 'imád aludni', 1, 0, '2022-12-16 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/8.jpg'),
(198, 'Fáraó', '2019-11-02', 4, 'szuka', 'Óriás uszkár', 'rossz', 0, 17, 'foghiányos', 'egészséges', 'nagy vörös sötétbarna kék', 'szeret nyugodtan pihenni', 1, 0, '2022-07-16 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/45.jpg'),
(199, 'Jasper', '2016-11-17', 7, 'kan', 'Shiloh juhászkutya', 'rossz', 1, 2, 'egészséges', 'rossz', 'közepes fekete fekete kék', 'imád aludni', 1, 0, '2022-09-15 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/137.jpg'),
(200, 'Magnipuss', '2019-01-23', 4, 'szuka', 'Tosza inu', 'rossz', 0, 27, 'egészséges', 'rossz', 'közepes arany vörös kék', 'szeret játszani', 1, 0, '2021-03-22 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/193.jpg'),
(201, 'Rézi', '2015-07-11', 8, 'kan', 'Uszkár', 'közepes', 1, 20, 'egészséges', 'egészséges', 'kicsi vörös vörös zöld', 'szeret játszani', 1, 0, '2022-11-19 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/51.jpg'),
(202, 'Parádé', '2016-02-22', 7, 'kan', 'Shikoku inu', 'egészséges', 1, 5, 'foghiányos', 'egészséges', 'nagy vörös fekete zöld', 'szeret ölelni', 1, 0, '2022-02-26 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/56.jpg'),
(203, 'Ollé', '2018-02-28', 5, 'szuka', 'Gascogne-i kék basset', 'rossz', 1, 19, 'fogszuvas', 'egészséges', 'kicsi foltos fekete barna', 'szeret játszani', 1, 0, '2022-07-16 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/175.jpg'),
(204, 'Lulu', '2015-01-08', 8, 'szuka', 'Orosz fekete terrier', 'közepes', 0, 30, 'foghiányos', 'közepes', 'közepes foltos fekete zöld', 'kedves és barátságos', 1, 0, '2021-01-08 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/96.jpg'),
(205, 'Ajax', '2016-08-20', 7, 'szuka', 'Bandog', 'egészséges', 0, 22, 'fogszuvas', 'egészséges', 'közepes fehér barna kék', 'szeret futkosni a kertben', 1, 0, '2021-07-18 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/97.jpg'),
(206, 'Úrfi', '2015-04-07', 8, 'szuka', 'Boykin spániel', 'egészséges', 0, 20, 'egészséges', 'egészséges', 'kicsi szürke vörös barna', 'kedves és barátságos', 1, 0, '2021-01-27 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/77.jpg'),
(207, 'Jimmy', '2017-04-14', 6, 'szuka', 'Tajvani kutya', 'közepes', 1, 20, 'foghiányos', 'rossz', 'közepes foltos sötétbarna kék', 'szeret labdázni', 1, 0, '2022-03-15 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/92.jpg'),
(208, 'Keksz', '2020-05-07', 3, 'szuka', 'Közép-ázsiai juhászkutya', 'közepes', 1, 12, 'egészséges', 'egészséges', 'nagy foltos barna kék', 'be van gyulladva a füle', 1, 0, '2022-10-24 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/76.jpg'),
(209, 'Nudli', '2018-10-28', 5, 'kan', 'Ariége-i vizsla', 'közepes', 1, 29, 'fogszuvas', 'rossz', 'nagy barna vörös kék', 'szeret játszani a labdával', 1, 0, '2022-10-01 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/61.jpg'),
(210, 'Mogyoró', '2017-07-28', 6, 'kan', 'Vendée-i griffonkopó', 'közepes', 1, 13, 'foghiányos', 'rossz', 'közepes fekete vörös zöld', 'szeret nyugodtan pihenni', 1, 0, '2021-11-16 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/117.jpg'),
(211, 'Jenny', '2018-06-01', 5, 'szuka', 'Estrelai hegyikutya', 'közepes', 0, 25, 'foghiányos', 'egészséges', 'kicsi foltos rózsaszín zöld', 'szeret ölelni', 1, 0, '2021-12-09 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/29.jpg'),
(212, 'Chilli', '2015-05-05', 8, 'szuka', 'Kangaroo Dog', 'egészséges', 1, 22, 'fogszuvas', 'egészséges', 'kicsi barna fekete barna', 'több mozgást igényel', 1, 0, '2021-05-10 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/188.jpg'),
(213, 'Pitti', '2019-07-16', 4, 'szuka', 'Rat terrier', 'egészséges', 0, 24, 'egészséges', 'egészséges', 'nagy sárga rózsaszín zöld', 'köröm vágást igényel', 1, 0, '2022-08-21 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/142.jpg');
INSERT INTO `allatok` (`allat_id`, `allat_nev`, `szul_ev`, `becsult_kor`, `neme`, `fajta`, `eu_allapot`, `ivar_ivartalanitot`, `suly`, `fogazatt`, `testi_allapott`, `ismertetojegyek`, `megjegyzes`, `chip`, `orokbeadas`, `befogadas_datuma`, `img`) VALUES
(214, 'Szultán', '2016-02-06', 7, 'szuka', 'Münsterlandi vizsla', 'egészséges', 0, 15, 'foghiányos', 'közepes', 'kicsi foltos barna barna', 'szeret úszni', 1, 0, '2021-08-24 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/146.jpg'),
(215, 'Don', '2017-02-25', 6, 'kan', 'Kis münsterlandi vizsla', 'közepes', 0, 19, 'egészséges', 'közepes', 'nagy sárga fekete zöld', 'szeret labdázni', 1, 0, '2022-06-12 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/167.jpg'),
(216, 'Szetti', '2015-12-12', 8, 'kan', 'Cseh juhászkutya', 'egészséges', 0, 28, 'foghiányos', 'közepes', 'közepes fekete sötétbarna kék', 'szeret kutyakölykökkel játszani', 1, 0, '2021-10-11 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/180.jpg'),
(217, 'Szetti', '2017-03-27', 6, 'kan', 'Spanyol agár', 'egészséges', 0, 25, 'fogszuvas', 'egészséges', 'közepes tigriscsíkos rózsaszín barna', 'szeret fürdeni a tóban', 1, 0, '2021-12-07 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/43.jpg'),
(218, 'Lulu', '2019-08-16', 4, 'szuka', 'Cardigan welsh corgi', 'közepes', 0, 10, 'egészséges', 'rossz', 'közepes arany barna barna', 'szeret úszni', 1, 0, '2021-05-09 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/42.jpg'),
(219, 'Stella', '2015-06-05', 8, 'szuka', 'Uszkár', 'közepes', 0, 24, 'foghiányos', 'egészséges', 'kicsi fekete fekete zöld', 'szeret játszani', 1, 0, '2021-01-13 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/146.jpg'),
(220, 'Inez', '2016-12-02', 7, 'kan', 'Keverék', 'közepes', 0, 30, 'egészséges', 'rossz', 'kicsi arany vörös kék', 'bélférges', 1, 0, '2021-07-28 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/23.jpg'),
(221, 'Furby', '2020-09-17', 3, 'kan', 'Kooikerhondje', 'rossz', 1, 23, 'fogszuvas', 'egészséges', 'közepes arany sötétbarna kék', 'be van gyulladva a füle', 1, 0, '2022-07-12 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/3.jpg'),
(222, 'Aramis', '2018-08-12', 5, 'kan', 'Szürke norvég elghund', 'egészséges', 1, 19, 'egészséges', 'közepes', 'közepes szürke sötétbarna kék', 'be van gyulladva a füle', 1, 0, '2022-08-22 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/95.jpg'),
(223, 'Rinó', '2017-11-04', 6, 'szuka', 'Tátrai juhászkutya', 'közepes', 1, 12, 'fogszuvas', 'egészséges', 'közepes tigriscsíkos rózsaszín barna', 'be van gyulladva a füle', 1, 0, '2022-08-10 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/160.jpg'),
(224, 'Suzy', '2018-05-15', 5, 'kan', 'bolonka francuska', 'közepes', 0, 17, 'foghiányos', 'közepes', 'közepes szürke vörös barna', 'szeret futkosni a kertben', 1, 0, '2022-12-23 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/195.jpg'),
(225, 'Csöpi', '2019-08-22', 4, 'kan', 'Moszkvai hosszú szőrű toy terrier', 'rossz', 1, 9, 'egészséges', 'rossz', 'nagy sárga barna barna', 'imád aludni', 1, 0, '2021-06-25 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/54.jpg'),
(226, 'Ládikó', '2019-11-15', 4, 'szuka', 'Mallorcai masztiff', 'közepes', 0, 16, 'foghiányos', 'rossz', 'kicsi foltos sötétbarna kék', 'szeret ölelni', 1, 0, '2022-11-24 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/22.jpg'),
(227, 'Elíz', '2016-12-19', 7, 'szuka', 'Tátrai juhászkutya', 'közepes', 0, 16, 'fogszuvas', 'közepes', 'kicsi fekete vörös kék', 'kedves és barátságos', 1, 0, '2022-12-17 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/168.jpg'),
(228, 'Héra', '2018-02-04', 5, 'szuka', 'Cardigan welsh corgi', 'egészséges', 0, 21, 'egészséges', 'közepes', 'közepes sárga vörös barna', 'szeret sétálni a parkban', 1, 0, '2021-03-03 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/119.jpg'),
(229, 'Nyikita', '2017-02-27', 6, 'szuka', 'Afgán agár', 'közepes', 1, 24, 'fogszuvas', 'rossz', 'közepes sárga rózsaszín barna', 'szeret labdázni', 1, 0, '2022-12-26 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/180.jpg'),
(230, 'Karesz', '2016-10-04', 7, 'kan', 'Schipperke', 'egészséges', 1, 7, 'fogszuvas', 'egészséges', 'közepes vörös barna kék', 'bélférges', 1, 0, '2021-07-09 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/34.jpg'),
(231, 'Nessy', '2016-11-21', 7, 'szuka', 'Welsh corgi', 'közepes', 1, 7, 'foghiányos', 'rossz', 'kicsi arany fekete zöld', 'be van gyulladva a füle', 1, 0, '2022-07-19 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/97.jpg'),
(232, 'Tekergő', '2017-09-07', 6, 'szuka', 'Lurcher', 'közepes', 0, 11, 'egészséges', 'egészséges', 'nagy tigriscsíkos barna barna', 'szeret labdázni', 1, 0, '2022-02-11 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/96.jpg'),
(233, 'Frakk', '2015-11-12', 8, 'kan', 'Kuvasz  Magyarország', 'egészséges', 0, 3, 'foghiányos', 'rossz', 'kicsi foltos vörös kék', 'bélférges', 1, 0, '2022-11-28 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/127.jpg'),
(234, 'Inzy', '2016-04-03', 7, 'kan', 'Perui meztelen kutya', 'közepes', 1, 30, 'egészséges', 'közepes', 'kicsi barna barna barna', 'szeret úszni', 1, 0, '2021-01-14 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/87.jpg'),
(235, 'Apolló', '2020-04-15', 3, 'kan', 'Saage kochee', 'rossz', 1, 7, 'foghiányos', 'egészséges', 'kicsi sárga barna zöld', 'szeret játszani a labdával', 1, 0, '2021-01-24 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/102.jpg'),
(236, 'Piszok', '2020-06-28', 3, 'kan', 'Hortaye Borzaya (Chortaj)', 'egészséges', 1, 18, 'foghiányos', 'egészséges', 'közepes barna sötétbarna zöld', 'szeret úszni', 1, 0, '2022-05-03 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/46.jpg'),
(237, 'Polli', '2020-03-01', 3, 'szuka', 'Bearded collie', 'rossz', 0, 10, 'fogszuvas', 'egészséges', 'kicsi vörös sötétbarna kék', 'szeret játszani a labdával', 1, 0, '2022-02-11 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/40.jpg'),
(238, 'Fló', '2017-03-07', 6, 'kan', 'Kai ken', 'közepes', 0, 24, 'fogszuvas', 'rossz', 'közepes tigriscsíkos barna barna', 'köröm vágást igényel', 1, 0, '2021-01-06 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/151.jpg'),
(239, 'Elza', '2015-05-26', 8, 'szuka', 'Labrador retriever', 'közepes', 1, 23, 'fogszuvas', 'rossz', 'kicsi arany vörös zöld', 'szeret futkosni a kertben', 1, 0, '2021-11-26 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/57.jpg'),
(240, 'Nudli', '2017-01-09', 6, 'kan', 'Rövidszőrű német vizsla', 'egészséges', 1, 6, 'egészséges', 'egészséges', 'nagy fekete fekete barna', 'szeret az ablakban ülni', 1, 0, '2022-10-24 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/6.jpg'),
(241, 'Espresso', '2019-10-01', 4, 'kan', 'Bukovinai pásztorkutya', 'rossz', 0, 11, 'foghiányos', 'egészséges', 'közepes arany barna zöld', 'szeret úszni', 1, 0, '2021-06-13 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/187.jpg'),
(242, 'Karesz', '2019-07-27', 4, 'kan', 'Pikárdiai kék spániel', 'közepes', 1, 8, 'egészséges', 'egészséges', 'kicsi fekete fekete kék', 'szeret futkosni a kertben', 1, 0, '2022-09-22 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/115.jpg'),
(243, 'Molly', '2016-09-25', 7, 'szuka', 'Laekenois', 'egészséges', 0, 6, 'foghiányos', 'egészséges', 'közepes szürke fekete kék', 'szeret kutyakölykökkel játszani', 1, 0, '2022-07-28 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/32.jpg'),
(244, 'Héra', '2017-03-13', 6, 'szuka', 'Kis jurai kopó', 'egészséges', 0, 19, 'fogszuvas', 'egészséges', 'közepes fekete barna kék', 'bélférges', 1, 0, '2021-10-18 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/28.jpg'),
(245, 'Don', '2015-08-09', 8, 'szuka', 'Drótszőrű magyar vizsla', 'egészséges', 1, 13, 'fogszuvas', 'közepes', 'közepes fekete vörös kék', 'szeret ölelni', 1, 0, '2021-09-23 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/137.jpg'),
(246, 'Aramis', '2020-05-09', 3, 'szuka', 'Azori-szigeteki kutya', 'egészséges', 1, 15, 'fogszuvas', 'rossz', 'nagy barna rózsaszín kék', 'köröm vágást igényel', 1, 0, '2022-08-09 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/74.jpg'),
(247, 'Karcsi', '2015-01-24', 8, 'szuka', 'Német vadászterrier', 'közepes', 1, 5, 'fogszuvas', 'közepes', 'közepes sárga sötétbarna zöld', 'szeret fürdeni a tóban', 1, 0, '2021-01-01 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/196.jpg'),
(248, 'Afton', '2018-06-13', 5, 'kan', 'Belga vizsla', 'egészséges', 1, 3, 'foghiányos', 'rossz', 'kicsi szürke vörös zöld', 'szeret labdázni', 1, 0, '2021-07-21 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/201.jpg'),
(249, 'Vanília', '2018-08-09', 5, 'kan', 'Pireneusi masztiff', 'közepes', 0, 1, 'fogszuvas', 'közepes', 'kicsi arany sötétbarna barna', 'bélférges', 1, 0, '2022-02-16 00:00:00', 'http://localhost/FKNmenhely/allat_kepek/88.jpg');

-- --------------------------------------------------------
CREATE TABLE `felhasznalok` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `kert_van` varchar(10) NOT NULL,
  `add_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `bizalom_v` tinyint(1) NOT NULL DEFAULT 1,
  `admin_e` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `felhasznalok`
--

INSERT INTO `felhasznalok` (`id`, `name`, `email`, `password_hash`, `kert_van`, `add_date`, `bizalom_v`, `admin_e`) VALUES
(1, 'Szász Gergő', 'szaszgergo005@gmail.com', '$2y$10$eSEZoPSsAp14WLSl94TrAOJnC33SSuvOZJZJScWeCBYdXPSFg/S12', 'kert', '2023-04-12 16:36:30', 1, 0),
(2, 'nincskert', 'nincskert@gmail.com', '$2y$10$cmDAQ/eX9ZmbBzwzDZIgquGjFYQD.K8t4TqSWWRmYx7erhGN5dB26', 'panel', '2023-04-12 16:37:02', 1, 0),
(3, 'kert1', 'kert1@gmail.com', '$2y$10$H9za3Y3kBMQHmgmjzMUKeONLZopGUsb6u8uuUckHdJV1YIWbjye6C', 'kert', '2023-04-13 18:22:56', 1, 0),
(4, 'kert2', 'kert2@gmail.com', '$2y$10$EMKF.5gsyscqXyBG2o3DuOfyIDq1McY8wMvWDAvRIfJUghKWXn0Pa', 'kert', '2023-04-13 18:23:06', 1, 0),
(5, 'admin', 'admin@gmail.com', '$2y$10$qVgFO3VuaDuy5mWc.tqJUumt.PK3OF1X3HesZHEU6T6J.0o2tb7.S', 'kert', '2023-04-16 08:20:03', 1, 1),
(28, 'SzaszGergo', 'szaszgergo00105@gmail.com', '$2y$10$hsUB/QVcCHNDgECWopnbFeHaWMCvwaRS6B0BTYC6m.Rd23/Pjg2IO', 'kert', '2023-05-02 16:36:23', 1, 0),
(40, 'szaszgergo', 'sziauramgergo05@gmail.com', '$2y$10$cDiAi3k/0R409/Nj4AgZv.3q7lqx2y7K2wgn9pVfKFHFbEcK8HO7q', 'kert', '2023-05-02 18:46:03', 1, 0),
(44, 'szaszgergo', 'szaszgergo00005@gmail.com', '$2y$10$YEZE.sxUo.RG3JAfxln/seGnIxc6vbrzeLxkqhPpIsOvH5Th8bDEm', 'kert', '2023-05-02 19:05:04', 1, 0),
(46, 'szaszgergo', 'szaszgergo000005@gmail.com', '$2y$10$u6weJZ2s3B6dLzRcQ4vQ7OlA4UNhjbYeblIyjiKOH63udub20C3Em', 'kert', '2023-05-02 19:05:49', 1, 0),
(47, 'szaszgergo', 'gerike@gmail.com', '$2y$10$sefjg9yXTNO7j3FGSrpRNOqC1G3nwFPHx6jq14Sdgfyq07CIpNdr2', 'kert', '2023-05-02 19:49:09', 1, 0),
(78, 'sziabela', 'sziabela@gmail.com', '$2y$10$KYMbnmRexNZ3D3W.OihF6u1piMdOruuv/q60CY75IwwUIckLzfnPu', 'kert', '2023-05-03 14:00:03', 1, 0);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `felhasznalok`
--
ALTER TABLE `felhasznalok`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `felhasznalok`
--
ALTER TABLE `felhasznalok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
--
-- Tábla szerkezet ehhez a táblához `orokbeadott_allatok`
--

CREATE TABLE `orokbeadott_allatok` (
  `id` int(11) NOT NULL,
  `user_id` int(255) NOT NULL,
  `allat_id` int(255) NOT NULL,
  `be_datum` datetime NOT NULL DEFAULT current_timestamp(),
  `ki_datum` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `orokbeadott_allatok`
--

INSERT INTO `orokbeadott_allatok` (`id`, `user_id`, `allat_id`, `be_datum`, `ki_datum`, `status`) VALUES
(1, 1, 3, '2023-05-02 16:39:11', NULL, 1),
(2, 1, 5, '2023-05-02 16:45:50', NULL, 1);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `allatok`
--
ALTER TABLE `allatok`
  ADD PRIMARY KEY (`allat_id`);

--
-- A tábla indexei `orokbeadott_allatok`
--
ALTER TABLE `orokbeadott_allatok`
  ADD PRIMARY KEY (`id`),
  ADD KEY `allat_id` (`allat_id`),
  ADD KEY `user_id` (`user_id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `allatok`
--
ALTER TABLE `allatok`
  MODIFY `allat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=256;

--
-- AUTO_INCREMENT a táblához `orokbeadott_allatok`
--
ALTER TABLE `orokbeadott_allatok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `orokbeadott_allatok`
--
ALTER TABLE `orokbeadott_allatok`
  ADD CONSTRAINT `orokbeadott_allatok_ibfk_1` FOREIGN KEY (`allat_id`) REFERENCES `allatok` (`allat_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orokbeadott_user_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `felhasznalok` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
