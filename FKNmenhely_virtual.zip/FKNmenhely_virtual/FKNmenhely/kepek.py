import os
os.getcwd()
collection = "C:/xampp/htdocs/FKNmenhely/allat_kepek"
for i, filename in enumerate(os.listdir(collection)):
    os.rename(
        f"C:/xampp/htdocs/FKNmenhely/allat_kepek/{filename}",
       f"C:/xampp/htdocs/FKNmenhely/allat_kepek/{i}.jpg",
    )

