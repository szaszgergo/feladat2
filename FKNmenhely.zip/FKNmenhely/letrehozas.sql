CREATE DATABASE fknmenhely
default character set utf8 
collate utf8_hungarian_ci;
USE fknmenhely;


CREATE TABLE allatok(
allat_id int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT, 
allat_nev varchar(50) NOT NULL,
szul_ev date NOT NULL,
becsult_kor int(11) NULL,
neme varchar(255) DEFAULT 'kan' NOT NULL,
fajta varchar(255) NOT NULL,
eu_allapot varchar(255) NOT NULL,
ivar_ivartalanitot tinyint(1) NOT NULL,
suly float NOT NULL,
fogazatt varchar(255) NOT NULL,
testi_allapott varchar(255) NOT NULL,
ismertetojegyek	varchar(255) NOT NULL,
megjegyzes varchar(255) NOT NULL,
chip tinyint(1) NOT NULL,
orokbeadas tinyint(1) NOT NULL,
befogadas_datuma datetime NOT NULL,
img	varchar(255) NULL DEFAULT NUll
);

CREATE TABLE user(
id int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT, 
name varchar(128)	NOT NULL,
email varchar(255) NOT NULL,
UNIQUE (email),
password_hash	varchar(255) NOT NULL
);


CREATE TABLE listazott_allatok(
allat_nev_id int(11) NOT NULL,
id int(11) NOT NULL,
PRIMARY KEY (allat_nev_id),
FOREIGN KEY (id) REFERENCES user(id)
);

CREATE TABLE orokbeadot_allatok(
allat_nev_id int(11) NOT NULL,
id int(11) NOT NULL,
PRIMARY KEY (allat_nev_id),
FOREIGN KEY (id) REFERENCES user(id)
);