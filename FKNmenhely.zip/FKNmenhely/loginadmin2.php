<?php
$is_invalid = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    $mysqli = require __DIR__ . "/database.php";
    
    $sql = sprintf("SELECT * FROM user
                    WHERE email = '%s'",
                   $mysqli->real_escape_string($_POST["email"]));
    
    $result = $mysqli->query($sql);
    
    $user = $result->fetch_assoc();

 
    
    if ($user) {
        
        if (password_verify($_POST["password"], $user["password_hash"]) And  $user["admin_e"]=='1') {
            
            session_start();

            session_regenerate_id();

            $db = new mysqli("localhost", "root", "", "fknmenhely");
            $db_amount = $db->query("SELECT COUNT(*) FROM allatok");
            $totalItem = $db_amount->fetch_row()[0];
            $url_allat_id = $_GET['id'];
            if ($url_allat_id <= $totalItem) {
                $allat = $db->query("SELECT * FROM `allatok` WHERE `allat_id` = \"$url_allat_id\"");
                
             
                $mezo = $allat -> fetch_row();
                $allat_id = $mezo[0];
                $allat_orokebadas = $mezo[14];
            }

            $_SESSION["user_id"] = $user["id"];
            header("Location: allatok_frissites.php?id=$allat_id");
            exit;
        }
    }

    $is_invalid = true;


}
?>



<!DOCTYPE html>
<html lang="en">
<head>
<title>Bejelentkezés Örökebadáshoz</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/just-validate@latest/dist/just-validate.production.min.js" defer></script>
    <script src="/js/validation.js" defer></script>
   
    <link rel="stylesheet" href="stilus/style.css?v=<?php echo time(); ?>">

    
</head>
<body>
  <!------------------------fej-eleje------------------------------------------>
  <header class="bg-light" id="fej1">
    <div class="container">
      
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <a class="navbar-brand" href="#">
            <img src="kepek/logo2.png" width="50" height="50" alt="">
          </a>
            <a class="navbar-brand" href="#">Menü</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                  <a class="nav-link" href="index.html">Főoldal <span class="sr-only">(jelenlegi)</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="allatok.php">Állatok</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php">Saját oldalam</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="loginadmin.php">Állatok örökbeadása</a>
                </li>
                      
              </ul>
            </div>
          </nav>
    </div>
</header> 

<!---------------------fej-vége----------------->    
<!---------------------tartalom-eleje----------------->   
<div class="wrapper">

   
<h1>Bejelentkezés az állatok felvételéhez:</h1>

<?php if ($is_invalid): ?>
    <em>Helytelen bejelentkezés/Az adott felhasználó nem rendelkezik adminisztrátori jogosultsággal.</em>
<?php endif; ?>


<form method="post">
    <label for="email">Adminisztrátori jogosultság szükséges. </label>
    <input type="email" name="email" id="email"
           value="<?= htmlspecialchars($_POST["email"] ?? "") ?>">
    
    <label for="password"></label>
    <input type="password" name="password" id="password">
    
    <button id="btn1">Bejelentkezés</button>
</form>
  </div>
<!---------------------tartalom-vége----------------->   
<!---------------------lábjegyzet-eleje----------------->   

<footer>

<div class="container-fluid" id="elerhetoseg">
 <hr>
 <h2>Elérhetőségeink:</h2>
 <ul id="foot_li">
  <li>Email:szaszgergo05@gmail.com</li>
  <li>Cím:Budapest Sügér utca 24. 1213</li>
  <li>Telefon szám:+36 50 121 1150</li>
  
 </ul>
</div>
</footer>
<!---------------------lábjegyzet-vége----------------->   
</body>
</html>



