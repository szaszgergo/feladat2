

<!DOCTYPE html>
<html>
<head>
    <title>Regisztáció</title>
    <!--navkb-->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
<!------->
<link rel="stylesheet" href="/stilus/signup.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://unpkg.com/just-validate@latest/dist/just-validate.production.min.js" defer></script>
    <script src="js/validation.js" defer></script>
    
</head>
<body>
 
     <!------------------------fej-eleje------------------------------------------>
  <header class="bg-light" id="fej1">
    <div class="container">
      
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <a class="navbar-brand" href="#">
            <img src="/kepek/logo2.png" width="50" height="50" alt="">
          </a>
            <a class="navbar-brand" href="#">Menü</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                  <a class="nav-link" href="index.html">Főoldal </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="allatok.php">Állatok</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="user.php">Saját oldalam</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="loginadmin.php">Állatok örökbeadása</a>
                </li>
                       
              </ul>
            </div>
          </nav>
    </div>
</header> 

<!---------------------fej-vége----------------->    
<!---------------------tartalom-eleje----------------->   
<div class="wrapper">
<div class=""> <!---------REGISZTRACIO-->
  <h1>Regisztráció</h1>
      
  <form action="process-signup.php" target="gomb" method="post" id="signup" novalidate><!--novalidate gmail-hez van hogy valid emailt használunk e -->
      <div>
          <label for="name"></label>
          <input type="text" id="name" name="name" placeholder="Név" data-just-validate-fallback-disabled="false" style class="just-validate-error-field">
         

      </div>
      
      <div>
          <label for="email"></label>
          <input type="email" id="email" name="email" placeholder="Email">
      </div>
      
      <div>
          <label for="password"></label>
          <input type="password" id="password" name="password" placeholder="Jelszó">
      </div>
      
      <div>
          <label for="password_confirmation"></label>
          <input type="password" id="password_confirmation" name="password_confirmation" placeholder="Jelszó megerősitése">
      </div>

      <div class="container-fluid">  <div class="row">
        <div class="col" ><div>
          <img src="kepek/Question_mark.png" title=' "Kertes lakás" annak tegintünk aminek van szabad tere, ebbe bele tartozik a tanya stb. is.' alt="segítség" id="Question_mark">
          <label for="kert" >Kertes házam van: </label>
         
           <input  class="nagysag"type="radio" name="ans" value="kert" />
           
         </div></div>
        <div class="col"><div>
          <img src="kepek/Question_mark.png" title=' "Panel"-t annak tekintünk aminek nincs megteremthető szabad' alt="segítség" id="Question_mark"><label for="panel">Panel lákásom van: </label>
         
          <input class="nagysag" type="radio" name="ans" value="panel" checked />
        </div></div>
        
              </div>
              
              </div>
             
      <button id="btn1">Regisztrálok</button>  

     
  </form>
  <div class="member">
    Van fiókod ? <a href="login.php">Jelentkezz be</a>
  </div>
    <!---------REGISZTRACIO--></div>
 
</div>

<!---------------------tartalom-vége----------------->   
<!---------------------lábjegyzet-eleje----------------->   

<footer>

  <div class="container-fluid" id="elerhetoseg">
   <hr>
   <h2>Elérhetőségeink:</h2>
   <ul id="foot_li">
    <li>Email:szaszgergo05@gmail.com</li>
    <li>Cím:Budapest Sügér utca 24. 1213</li>
    <li>Telefon szám:+36 50 121 1150</li>
    
   </ul>
  </div>
  </footer>
<!---------------------lábjegyzet-vége----------------->   


</body>
</html>

