-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2023. Máj 14. 10:10
-- Kiszolgáló verziója: 10.4.27-MariaDB
-- PHP verzió: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `fknmenhely`
--

DELIMITER $$
--
-- Eljárások
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_allatok` ()   SELECT * FROM allatok$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `allatok`
--

CREATE TABLE IF NOT EXISTS `allatok` (
  `allat_id` int(11) NOT NULL AUTO_INCREMENT,
  `allat_nev` varchar(50) NOT NULL,
  `szul_ev` date NOT NULL,
  `becsult_kor` int(11) NOT NULL,
  `neme` varchar(255) NOT NULL DEFAULT 'kan',
  `fajta` varchar(255) NOT NULL,
  `eu_allapot` varchar(255) NOT NULL,
  `ivar_ivartalanitot` tinyint(1) NOT NULL,
  `suly` float NOT NULL,
  `fogazatt` varchar(255) NOT NULL,
  `testi_allapott` varchar(255) NOT NULL,
  `ismertetojegyek` varchar(255) NOT NULL,
  `megjegyzes` varchar(255) NOT NULL,
  `chip` tinyint(1) NOT NULL,
  `orokbeadas` tinyint(1) NOT NULL DEFAULT 0,
  `befogadas_datuma` datetime NOT NULL DEFAULT current_timestamp(),
  `img` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`allat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=250 DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `allatok`
--

INSERT INTO `allatok` (`allat_id`, `allat_nev`, `szul_ev`, `becsult_kor`, `neme`, `fajta`, `eu_allapot`, `ivar_ivartalanitot`, `suly`, `fogazatt`, `testi_allapott`, `ismertetojegyek`, `megjegyzes`, `chip`, `orokbeadas`, `befogadas_datuma`, `img`) VALUES
(1, 'Alfonz', '2018-03-24', 5, 'kan', 'Pikárdiai spániel', 'egészséges', 1, 24, 'foghiányos', 'egészséges', 'kicsi foltos fekete zöld', 'A jólelkű Goldie mindig boldoggá teszi az embereket, kedves és szeretetre méltó társ.', 1, 0, '2021-01-27 00:00:00', 'allat_kepek/119.jpg'),
(2, 'Zafír', '2020-11-28', 3, 'kan', 'Bernáthegyi', 'rossz', 0, 25, 'foghiányos', 'egészséges', 'kicsi tigriscsíkos rózsaszín zöld', 'A tacskó, Oscar, egy nagyon öntudatos és bátor kutya, aki ragaszkodik a szokásaihoz.', 1, 0, '2022-05-01 00:00:00', 'allat_kepek/21.jpg'),
(3, 'Vénusz', '2017-07-08', 6, 'szuka', 'Rottweiler', 'egészséges', 1, 8, 'foghiányos', 'közepes', 'közepes vörös sötétbarna barna', 'Szeret a kedvenc plüssjátékával játszani.', 0, 1, '2022-09-16 00:00:00', 'allat_kepek/15.jpg'),
(4, 'Killer', '2020-08-27', 3, 'szuka', 'Szlovák kopó', 'egészséges', 1, 6, 'egészséges', 'rossz', 'kicsi sárga fekete zöld', 'A kis Westie, Lulu, a legaranyosabb és legkedvesebb kutyus, akivel valaha találkoztam.', 1, 0, '2021-05-28 00:00:00', 'allat_kepek/127.jpg'),
(5, 'Sparco', '2019-11-13', 4, 'szuka', 'Eurázsiai', 'közepes', 1, 17, 'fogszuvas', 'egészséges', 'nagy fehér rózsaszín kék', 'A hatalmas Saint Bernard, Brutus, imádja a gyerekeket és egy igazi öleb.', 0, 1, '2022-05-13 00:00:00', 'allat_kepek/45.jpg'),
(6, 'Grész', '2020-03-22', 3, 'kan', 'Rövidszőrű isztriai kopó', 'egészséges', 0, 6, 'fogszuvas', 'egészséges', 'közepes foltos fekete zöld', 'Szeret játszani a gazdájával a kertben és a szobában is.', 1, 0, '2021-05-04 00:00:00', 'allat_kepek/96.jpg'),
(7, 'Léda', '2018-05-21', 5, 'kan', 'Jack Russell terrier', 'rossz', 0, 12, 'egészséges', 'egészséges', 'nagy vörös barna zöld', 'A családi kutyánk, Max, egy érzékeny és játékos cocker spániel, aki mindig vidámságot visz a házba.', 0, 0, '2021-05-11 00:00:00', 'allat_kepek/74.jpg'),
(8, 'Melák', '2016-05-26', 7, 'kan', 'Fehérorosz juhászkutya vagy kelet-európai juhászkutya', 'rossz', 1, 20, 'egészséges', 'közepes', 'közepes fekete rózsaszín barna', 'A picinyke Chico nagyon aktív és energikus, mindig készen áll egy játékra vagy egy sétára.', 1, 0, '2021-11-18 00:00:00', 'allat_kepek/137.jpg'),
(9, 'Gringó', '2016-08-01', 7, 'kan', 'Groenendael', 'rossz', 0, 10, 'egészséges', 'rossz', 'kicsi vörös fekete barna', 'A hatalmas Saint Bernard, Brutus, imádja a gyerekeket és egy igazi öleb.', 1, 0, '2022-07-28 00:00:00', 'allat_kepek/111.jpg'),
(10, 'Vadóc', '2018-07-07', 5, 'kan', 'Közép-ázsiai juhászkutya', 'közepes', 1, 12, 'foghiányos', 'közepes', 'kicsi vörös barna barna', 'Szeret összebújni a gazdájával az esőben.', 0, 0, '2022-09-24 00:00:00', 'allat_kepek/128.jpg'),
(11, 'Azték', '2015-06-05', 8, 'kan', 'Tibeti spániel', 'egészséges', 1, 16, 'egészséges', 'közepes', 'nagy vörös sötétbarna kék', 'Szeret más kutyákkal játszani a kutyaparkban.', 0, 0, '2021-06-12 00:00:00', 'allat_kepek/108.jpg'),
(12, 'Adolf', '2019-09-12', 4, 'kan', 'Angol juhászkutya', 'közepes', 1, 23, 'foghiányos', 'rossz', 'kicsi sárga rózsaszín zöld', 'Az élénk Vizsla, Daisy, mindig készen áll egy jó futásra vagy egy strandolásra.', 1, 0, '2021-04-12 00:00:00', 'allat_kepek/28.jpg'),
(13, 'Zsozsó', '2018-12-26', 5, 'kan', 'Cardigan welsh corgi', 'rossz', 1, 21, 'fogszuvas', 'egészséges', 'kicsi foltos rózsaszín barna', 'Kedveli a más kutyák jelenlétét.', 1, 0, '2021-03-15 00:00:00', 'allat_kepek/102.jpg'),
(14, 'Igric', '2019-08-07', 4, 'kan', 'Szlovák csuvacs', 'rossz', 1, 30, 'fogszuvas', 'rossz', 'kicsi fehér vörös zöld', 'Szeret kirándulni az erdőben és felfedezni az új helyeket.', 1, 0, '2021-01-16 00:00:00', 'allat_kepek/141.jpg'),
(15, 'Pufók', '2016-01-16', 7, 'szuka', 'Német vadászterrier', 'közepes', 1, 1, 'fogszuvas', 'közepes', 'közepes fehér vörös zöld', 'Imádja a strandot és a tengerpartot.', 0, 0, '2021-04-17 00:00:00', 'allat_kepek/137.jpg'),
(16, 'Bagira', '2017-04-27', 6, 'szuka', 'Alpesi tacskókopó', 'egészséges', 0, 10, 'foghiányos', 'rossz', 'kicsi fehér vörös zöld', 'A tacskó, Oscar, egy nagyon öntudatos és bátor kutya, aki ragaszkodik a szokásaihoz.', 1, 0, '2022-02-22 00:00:00', 'allat_kepek/100.jpg'),
(17, 'Edith', '2016-12-22', 7, 'szuka', 'Lhasa apso', 'egészséges', 1, 5, 'fogszuvas', 'egészséges', 'nagy arany barna kék', 'Imádja a virágokat és a leveleket rágcsálni a kertben.', 0, 0, '2021-12-21 00:00:00', 'allat_kepek/102.jpg'),
(18, 'Ursula', '2018-11-01', 5, 'kan', 'Nagy gascogne-i kék kopó', 'közepes', 0, 7, 'fogszuvas', 'egészséges', 'közepes barna vörös barna', 'Kedveli az egyszerű ételeket, mint a csirkehús.', 0, 0, '2022-06-04 00:00:00', 'allat_kepek/66.jpg'),
(19, 'Rénó', '2016-08-16', 7, 'szuka', 'Törpe pinscher', 'egészséges', 1, 30, 'egészséges', 'rossz', 'kicsi foltos fekete kék', 'Szeret játszani a gazdájával a kertben és a szobában is.', 1, 0, '2021-04-07 00:00:00', 'allat_kepek/198.jpg'),
(20, 'Zsozsó', '2017-04-05', 6, 'kan', 'Lengyel alföldi juhászkutya', 'egészséges', 1, 23, 'egészséges', 'közepes', 'közepes sárga rózsaszín kék', 'Tudja, hogy hogyan köszönjön és megálljon a piros lámpánál.', 1, 0, '2022-12-03 00:00:00', 'allat_kepek/63.jpg'),
(21, 'Fifi', '2016-08-21', 7, 'szuka', 'Kis vendée-i griffon basset', 'közepes', 0, 7, 'foghiányos', 'rossz', 'kicsi sárga rózsaszín zöld', 'Szeret kóborolni az erdőben.', 1, 0, '2022-06-14 00:00:00', 'allat_kepek/122.jpg'),
(22, 'Lassie', '2015-05-02', 8, 'kan', 'Kis svájci kopó', 'rossz', 1, 16, 'foghiányos', 'egészséges', 'nagy vörös sötétbarna kék', 'A vidám és játékos spániel, Lucky, imádja a strandolást és a vízben való pancsolást.', 0, 0, '2021-09-14 00:00:00', 'allat_kepek/128.jpg'),
(23, 'Vitéz', '2019-09-03', 4, 'kan', 'Saarloosi farkaskutya', 'rossz', 0, 25, 'foghiányos', 'egészséges', 'közepes foltos sötétbarna barna', 'Imádja a virágokat és a leveleket rágcsálni a kertben.', 1, 0, '2021-05-07 00:00:00', 'allat_kepek/130.jpg'),
(24, 'Askim', '2018-05-28', 5, 'szuka', 'Törpe pinscher', 'közepes', 0, 12, 'foghiányos', 'rossz', 'kicsi foltos sötétbarna barna', 'Szeret a kedvenc plüssjátékával játszani.', 0, 0, '2021-05-22 00:00:00', 'allat_kepek/204.jpg'),
(25, 'Nimród', '2019-11-05', 4, 'kan', 'Vendée-i griffonkopó', 'rossz', 1, 30, 'foghiányos', 'rossz', 'közepes fehér sötétbarna zöld', 'Szeret összebújni a gazdájával az esőben.', 0, 0, '2022-09-02 00:00:00', 'allat_kepek/160.jpg'),
(26, 'Jimmy', '2017-07-13', 6, 'kan', 'Lundehund', 'rossz', 0, 9, 'egészséges', 'egészséges', 'közepes fekete sötétbarna zöld', 'A nyugodt és okos labrador, Bella, egy igazi kisgyermekbarát kutya, aki imádja a családját.', 1, 0, '2022-09-24 00:00:00', 'allat_kepek/89.jpg'),
(27, 'Milli', '2020-12-05', 3, 'kan', 'Brabanti kis griffon', 'közepes', 0, 16, 'fogszuvas', 'közepes', 'kicsi arany vörös zöld', 'Az élénk Vizsla, Daisy, mindig készen áll egy jó futásra vagy egy strandolásra.', 0, 0, '2022-03-16 00:00:00', 'allat_kepek/170.jpg'),
(28, 'Inez', '2015-01-25', 8, 'szuka', 'Pembroke welsh corgi', 'rossz', 0, 24, 'egészséges', 'rossz', 'nagy fekete barna barna', 'A kis Westie, Lulu, a legaranyosabb és legkedvesebb kutyus, akivel valaha találkoztam.', 0, 0, '2022-06-11 00:00:00', 'allat_kepek/193.jpg'),
(29, 'Pötyi', '2019-09-23', 4, 'szuka', 'Chesapeake Bay retriever', 'rossz', 0, 9, 'foghiányos', 'egészséges', 'közepes arany barna kék', 'Imádja a virágokat és a leveleket rágcsálni a kertben.', 1, 0, '2021-10-23 00:00:00', 'allat_kepek/178.jpg'),
(30, 'Hobbit', '2018-08-02', 5, 'kan', 'Nagy angol-francia kopó', 'közepes', 0, 22, 'foghiányos', 'egészséges', 'közepes szürke fekete barna', 'A tacskó, Oscar, egy nagyon öntudatos és bátor kutya, aki ragaszkodik a szokásaihoz.', 0, 0, '2022-01-18 00:00:00', 'allat_kepek/142.jpg'),
(31, 'Destiny', '2015-10-11', 8, 'kan', 'Wolfspitz', 'rossz', 1, 9, 'egészséges', 'rossz', 'közepes foltos fekete barna', 'Imádja a strandot és a tengerpartot.', 0, 0, '2022-07-03 00:00:00', 'allat_kepek/53.jpg'),
(32, 'Bütyök', '2020-07-14', 3, 'kan', 'Spanyol masztiff', 'egészséges', 0, 23, 'foghiányos', 'rossz', 'kicsi foltos vörös zöld', 'Kedveli az egyszerű ételeket, mint a csirkehús.', 0, 0, '2022-11-28 00:00:00', 'allat_kepek/75.jpg'),
(33, 'Pedró', '2020-11-26', 3, 'szuka', 'Artois-i kopó', 'rossz', 0, 18, 'fogszuvas', 'rossz', 'kicsi foltos fekete kék', 'A picinyke Chico nagyon aktív és energikus, mindig készen áll egy játékra vagy egy sétára.', 0, 0, '2022-05-13 00:00:00', 'allat_kepek/59.jpg'),
(34, 'Szeti', '2019-07-09', 4, 'kan', 'Osztrák kopó', 'közepes', 1, 14, 'foghiányos', 'közepes', 'nagy sárga sötétbarna kék', 'A picinyke Chico nagyon aktív és energikus, mindig készen áll egy játékra vagy egy sétára.', 0, 0, '2022-07-12 00:00:00', 'allat_kepek/142.jpg'),
(35, 'Karesz', '2018-11-23', 5, 'szuka', 'Chinook', 'rossz', 1, 17, 'foghiányos', 'közepes', 'közepes fehér sötétbarna zöld', 'Szeret a kedvenc plüssjátékával játszani.', 0, 0, '2021-04-28 00:00:00', 'allat_kepek/185.jpg'),
(36, 'Mackó', '2015-04-10', 8, 'kan', 'Patterdale terrier', 'rossz', 1, 24, 'egészséges', 'egészséges', 'kicsi arany rózsaszín kék', 'A nyugodt és okos labrador, Bella, egy igazi kisgyermekbarát kutya, aki imádja a családját.', 0, 0, '2021-01-04 00:00:00', 'allat_kepek/64.jpg'),
(37, 'Zizi', '2015-12-08', 8, 'kan', 'Rövidszőrű skót juhászkutya', 'rossz', 1, 30, 'foghiányos', 'egészséges', 'kicsi vörös vörös barna', 'Szeret összebújni a gazdájával az esőben.', 0, 0, '2022-01-10 00:00:00', 'allat_kepek/36.jpg'),
(38, 'Emil', '2015-03-12', 8, 'kan', 'Kis oroszlánkutya', 'közepes', 0, 25, 'foghiányos', 'egészséges', 'közepes szürke sötétbarna zöld', 'Szeret a gazdájával együtt aludni.', 1, 0, '2022-08-25 00:00:00', 'allat_kepek/63.jpg'),
(39, 'Jázmina', '2015-02-22', 8, 'kan', 'Pireneusi juhászkutya', 'egészséges', 0, 24, 'fogszuvas', 'rossz', 'kicsi barna vörös barna', 'Szeret összebújni a gazdájával az esőben.', 0, 0, '2021-09-04 00:00:00', 'allat_kepek/208.jpg'),
(40, 'Szeti', '2015-04-11', 8, 'kan', 'Shikoku inu', 'rossz', 1, 11, 'egészséges', 'egészséges', 'kicsi foltos sötétbarna zöld', 'Szeret sétálni az utcán és megfigyelni az embereket és az állatokat.', 0, 0, '2022-04-26 00:00:00', 'allat_kepek/114.jpg'),
(41, 'Pongó', '2020-02-03', 3, 'kan', 'Fehér-fekete nagy angol-francia kopó', 'közepes', 1, 13, 'egészséges', 'közepes', 'nagy foltos barna barna', 'A kis Westie, Lulu, a legaranyosabb és legkedvesebb kutyus, akivel valaha találkoztam.', 0, 0, '2022-05-03 00:00:00', 'allat_kepek/10.jpg'),
(42, 'Napóleon', '2018-07-18', 5, 'szuka', 'Catahoulai leopárdkutya', 'egészséges', 0, 6, 'foghiányos', 'rossz', 'közepes vörös rózsaszín kék', 'A családi kutyánk, Max, egy érzékeny és játékos cocker spániel, aki mindig vidámságot visz a házba.', 1, 0, '2022-10-22 00:00:00', 'allat_kepek/181.jpg'),
(43, 'Pisze', '2017-01-21', 6, 'kan', 'Ariége-i kopó', 'közepes', 0, 9, 'fogszuvas', 'egészséges', 'közepes szürke vörös kék', 'Szeret más kutyákkal játszani a kutyaparkban.', 0, 0, '2021-07-28 00:00:00', 'allat_kepek/103.jpg'),
(44, 'Zola', '2017-12-05', 6, 'kan', 'Törpespicc', 'egészséges', 1, 1, 'fogszuvas', 'rossz', 'kicsi foltos sötétbarna kék', 'A jólelkű Goldie mindig boldoggá teszi az embereket, kedves és szeretetre méltó társ.', 1, 0, '2021-07-14 00:00:00', 'allat_kepek/20.jpg'),
(45, 'Teo', '2016-05-22', 7, 'szuka', 'Artois-i kopó', 'közepes', 1, 23, 'fogszuvas', 'közepes', 'nagy szürke barna barna', 'Szeret a kedvenc plüssjátékával játszani.', 0, 0, '2022-06-11 00:00:00', 'allat_kepek/200.jpg'),
(46, 'Szultán', '2019-10-06', 4, 'szuka', 'Broholmer', 'közepes', 0, 27, 'foghiányos', 'rossz', 'kicsi arany rózsaszín kék', 'Tudja, hogy hogyan köszönjön és megálljon a piros lámpánál.', 0, 0, '2021-11-27 00:00:00', 'allat_kepek/30.jpg'),
(47, 'Vitéz', '2017-09-07', 6, 'szuka', 'Kunming kutya', 'közepes', 0, 1, 'fogszuvas', 'rossz', 'közepes fehér sötétbarna zöld', 'Szeret a kedvenc plüssjátékával játszani.', 0, 0, '2022-09-18 00:00:00', 'allat_kepek/123.jpg'),
(48, 'Karesz', '2019-11-20', 4, 'kan', 'Tervueren', 'közepes', 1, 16, 'egészséges', 'egészséges', 'kicsi fekete vörös zöld', 'A játékos és barátságos Beagle, Snoopy, az összes családtag kedvence.', 1, 0, '2021-06-07 00:00:00', 'allat_kepek/22.jpg'),
(49, 'Charlie', '2016-11-05', 7, 'kan', 'Boxer', 'közepes', 1, 17, 'egészséges', 'egészséges', 'közepes foltos rózsaszín barna', 'A picinyke Chico nagyon aktív és energikus, mindig készen áll egy játékra vagy egy sétára.', 0, 0, '2021-09-17 00:00:00', 'allat_kepek/31.jpg'),
(50, 'Luigi', '2019-06-18', 4, 'szuka', 'Gascogne-i kék basset', 'egészséges', 0, 18, 'egészséges', 'egészséges', 'közepes fekete sötétbarna barna', 'A picinyke Chico nagyon aktív és energikus, mindig készen áll egy játékra vagy egy sétára.', 1, 0, '2021-07-15 00:00:00', 'allat_kepek/191.jpg'),
(51, 'Zsozsó', '2016-02-14', 7, 'kan', 'Moszkvai hosszú szőrű toy terrier', 'egészséges', 0, 11, 'fogszuvas', 'közepes', 'kicsi vörös sötétbarna kék', 'A jólelkű Goldie mindig boldoggá teszi az embereket, kedves és szeretetre méltó társ.', 0, 0, '2022-12-06 00:00:00', 'allat_kepek/105.jpg'),
(52, 'Nessy', '2016-01-02', 7, 'szuka', 'Brazil masztiff', 'egészséges', 1, 8, 'egészséges', 'közepes', 'nagy fekete sötétbarna kék', 'A jólelkű Goldie mindig boldoggá teszi az embereket, kedves és szeretetre méltó társ.', 1, 0, '2022-01-10 00:00:00', 'allat_kepek/143.jpg'),
(53, 'Stella', '2019-11-18', 4, 'kan', 'Pireneusi juhászkutya', 'közepes', 1, 17, 'egészséges', 'egészséges', 'kicsi vörös fekete barna', 'Imádja a virágokat és a leveleket rágcsálni a kertben.', 0, 0, '2021-01-11 00:00:00', 'allat_kepek/180.jpg'),
(54, 'Kaarjack', '2018-04-10', 5, 'kan', 'Artois-i kopó', 'közepes', 0, 15, 'fogszuvas', 'rossz', 'nagy tigriscsíkos fekete zöld', 'Imádja a virágokat és a leveleket rágcsálni a kertben.', 1, 0, '2021-09-01 00:00:00', 'allat_kepek/23.jpg'),
(55, 'Jet', '2017-04-08', 6, 'szuka', 'Kaukázusi juhászkutya', 'rossz', 1, 14, 'foghiányos', 'rossz', 'közepes sárga rózsaszín kék', 'A picinyke Chico nagyon aktív és energikus, mindig készen áll egy játékra vagy egy sétára.', 0, 0, '2022-01-25 00:00:00', 'allat_kepek/177.jpg'),
(56, 'Fickel', '2017-03-02', 6, 'szuka', 'Cseh juhászkutya', 'közepes', 0, 15, 'foghiányos', 'egészséges', 'nagy foltos rózsaszín zöld', 'Szeret más kutyákkal játszani a kutyaparkban.', 1, 0, '2021-05-16 00:00:00', 'allat_kepek/31.jpg'),
(57, 'Lasszó', '2019-04-09', 4, 'kan', 'Norvég lundehund', 'rossz', 0, 14, 'foghiányos', 'rossz', 'kicsi tigriscsíkos sötétbarna kék', 'Szeret dörgölőzni a gazdájával és más emberekkel is.', 1, 0, '2021-06-17 00:00:00', 'allat_kepek/125.jpg'),
(58, 'Rézi', '2019-04-16', 4, 'szuka', 'Ariége-i kopó', 'közepes', 0, 3, 'foghiányos', 'közepes', 'nagy fehér rózsaszín zöld', 'Az érzékeny és odaadó pitbull, Luna, a család kiskedvence, aki imádja a játékot és a simogatást.', 0, 0, '2022-07-24 00:00:00', 'allat_kepek/38.jpg'),
(59, 'Tofi', '2017-03-07', 6, 'szuka', 'Törpespicc', 'közepes', 0, 14, 'fogszuvas', 'rossz', 'közepes szürke barna kék', 'A tacskó, Oscar, egy nagyon öntudatos és bátor kutya, aki ragaszkodik a szokásaihoz.', 0, 0, '2022-11-21 00:00:00', 'allat_kepek/155.jpg'),
(60, 'Nina', '2020-06-19', 3, 'szuka', 'Portugál juhászkutya', 'rossz', 0, 23, 'egészséges', 'egészséges', 'nagy fekete sötétbarna zöld', 'A vidám és játékos spániel, Lucky, imádja a strandolást és a vízben való pancsolást.', 1, 0, '2021-06-19 00:00:00', 'allat_kepek/162.jpg'),
(61, 'Foxi', '2018-10-02', 5, 'kan', 'Laekenois', 'közepes', 0, 14, 'foghiányos', 'rossz', 'nagy barna vörös barna', 'A tacskó, Oscar, egy nagyon öntudatos és bátor kutya, aki ragaszkodik a szokásaihoz.', 0, 0, '2021-03-16 00:00:00', 'allat_kepek/173.jpg'),
(62, 'Cézár', '2019-08-16', 4, 'kan', 'Olasz agár', 'rossz', 1, 16, 'egészséges', 'rossz', 'közepes tigriscsíkos vörös barna', 'A csendes és kiegyensúlyozott Bernese hegyi kutya, Maxine, nagyon szeret játszani és sétálni.', 0, 0, '2022-08-03 00:00:00', 'allat_kepek/182.jpg'),
(63, 'Dolfi', '2015-05-26', 8, 'szuka', 'Affenpinscher', 'közepes', 1, 16, 'fogszuvas', 'egészséges', 'nagy foltos sötétbarna barna', 'Szeret kóborolni az erdőben.', 1, 0, '2021-08-23 00:00:00', 'allat_kepek/159.jpg'),
(64, 'Wolf', '2020-10-25', 3, 'kan', 'Portugál juhászkutya', 'rossz', 0, 29, 'fogszuvas', 'rossz', 'kicsi vörös fekete barna', 'A nyugodt és okos labrador, Bella, egy igazi kisgyermekbarát kutya, aki imádja a családját.', 1, 0, '2022-01-16 00:00:00', 'allat_kepek/193.jpg'),
(65, 'Luigi', '2015-05-13', 8, 'szuka', 'Welsh springer spániel', 'közepes', 1, 30, 'egészséges', 'közepes', 'nagy sárga vörös barna', 'Az én kutyám, Fido, egy fantasztikus és okos németjuhász, aki mindig megvédi a családját.', 0, 0, '2021-12-24 00:00:00', 'allat_kepek/7.jpg'),
(66, 'Gerry', '2018-01-15', 5, 'szuka', 'Komondor  Magyarország', 'rossz', 1, 27, 'foghiányos', 'rossz', 'nagy szürke barna barna', 'Az érzékeny és odaadó pitbull, Luna, a család kiskedvence, aki imádja a játékot és a simogatást.', 1, 0, '2021-08-04 00:00:00', 'allat_kepek/101.jpg'),
(67, 'Ördög', '2020-08-26', 3, 'kan', 'Hosszúszőrű német vizsla', 'rossz', 1, 12, 'foghiányos', 'rossz', 'közepes foltos vörös kék', 'Szeret kirándulni az erdőben és felfedezni az új helyeket.', 1, 0, '2021-09-21 00:00:00', 'allat_kepek/126.jpg'),
(68, 'Teddy', '2020-11-18', 3, 'kan', 'Moszkvai hosszú szőrű toy terrier', 'rossz', 1, 18, 'foghiányos', 'rossz', 'kicsi arany fekete kék', 'A családi kutyánk, Max, egy érzékeny és játékos cocker spániel, aki mindig vidámságot visz a házba.', 0, 0, '2021-06-20 00:00:00', 'allat_kepek/183.jpg'),
(69, 'Jockey', '2018-11-01', 5, 'kan', 'Kromfohrlandi', 'rossz', 0, 16, 'foghiányos', 'egészséges', 'közepes arany sötétbarna kék', 'Szeret összebújni a gazdájával az esőben.', 0, 0, '2021-02-01 00:00:00', 'allat_kepek/61.jpg'),
(70, 'Neutron', '2017-09-16', 6, 'szuka', 'Akita inu', 'közepes', 1, 2, 'fogszuvas', 'közepes', 'kicsi vörös sötétbarna zöld', 'Az öreg bulldog, Rocky, igazi kincs, aki mindig boldogságot hoz a házba.', 0, 0, '2021-12-23 00:00:00', 'allat_kepek/55.jpg'),
(71, 'Igric', '2017-03-04', 6, 'kan', 'Japán spicc', 'egészséges', 0, 11, 'egészséges', 'egészséges', 'kicsi szürke rózsaszín kék', 'Szeret kirándulni az erdőben és felfedezni az új helyeket.', 1, 0, '2022-09-15 00:00:00', 'allat_kepek/72.jpg'),
(72, 'Héra', '2015-03-25', 8, 'kan', 'Golden retriever', 'közepes', 1, 6, 'fogszuvas', 'közepes', 'kicsi fekete vörös zöld', 'A jólelkű Goldie mindig boldoggá teszi az embereket, kedves és szeretetre méltó társ.', 1, 0, '2021-12-18 00:00:00', 'allat_kepek/134.jpg'),
(73, 'Ládikó', '2020-09-03', 3, 'szuka', 'Vizsla', 'közepes', 1, 9, 'fogszuvas', 'rossz', 'nagy fekete fekete zöld', 'Szeret más kutyákkal játszani a kutyaparkban.', 0, 0, '2022-03-14 00:00:00', 'allat_kepek/138.jpg'),
(74, 'Azték', '2020-11-25', 3, 'szuka', 'Német pinscher', 'rossz', 0, 3, 'fogszuvas', 'egészséges', 'kicsi tigriscsíkos rózsaszín zöld', 'Kedveli a más kutyák jelenlétét.', 0, 0, '2022-05-21 00:00:00', 'allat_kepek/190.jpg'),
(75, 'Milli', '2019-11-17', 4, 'kan', 'Szamojéd', 'egészséges', 0, 8, 'egészséges', 'egészséges', 'közepes szürke rózsaszín barna', 'Az én kutyám, Fido, egy fantasztikus és okos németjuhász, aki mindig megvédi a családját.', 1, 0, '2022-06-26 00:00:00', 'allat_kepek/93.jpg'),
(76, 'Pongó', '2017-08-19', 6, 'kan', 'Nagy vendée-i griffon basset', 'egészséges', 1, 17, 'egészséges', 'egészséges', 'nagy tigriscsíkos fekete barna', 'Szeret futkározni a futópályán.', 1, 0, '2022-01-12 00:00:00', 'allat_kepek/181.jpg'),
(77, 'Lolka', '2020-03-11', 3, 'kan', 'Német fürjészeb', 'egészséges', 0, 6, 'fogszuvas', 'egészséges', 'közepes tigriscsíkos vörös zöld', 'Az élénk Vizsla, Daisy, mindig készen áll egy jó futásra vagy egy strandolásra.', 1, 0, '2022-01-17 00:00:00', 'allat_kepek/82.jpg'),
(78, 'Gingy', '2016-01-04', 7, 'szuka', 'Újfundlandi', 'rossz', 0, 7, 'egészséges', 'rossz', 'nagy fehér sötétbarna zöld', 'Imádja a virágokat és a leveleket rágcsálni a kertben.', 0, 0, '2022-05-27 00:00:00', 'allat_kepek/98.jpg'),
(79, 'Horka', '2015-02-28', 8, 'kan', 'Törpe uszkár', 'közepes', 0, 17, 'fogszuvas', 'rossz', 'kicsi szürke sötétbarna zöld', 'A vidám és játékos spániel, Lucky, imádja a strandolást és a vízben való pancsolást.', 1, 0, '2022-10-19 00:00:00', 'allat_kepek/89.jpg'),
(80, 'Pandúr', '2017-10-13', 6, 'szuka', 'Münsterlandi vizsla', 'rossz', 0, 30, 'fogszuvas', 'egészséges', 'nagy fehér sötétbarna kék', 'Tudja, hogy hogyan köszönjön és megálljon a piros lámpánál.', 0, 0, '2022-06-01 00:00:00', 'allat_kepek/44.jpg'),
(81, 'Zsüti', '2015-02-18', 8, 'szuka', 'Hosszúszőrű skót juhászkutya', 'egészséges', 0, 21, 'foghiányos', 'közepes', 'közepes sárga barna zöld', 'A vidám és játékos spániel, Lucky, imádja a strandolást és a vízben való pancsolást.', 1, 0, '2021-08-17 00:00:00', 'allat_kepek/91.jpg'),
(82, 'Jet', '2016-02-25', 7, 'szuka', 'King Shepherd', 'egészséges', 1, 27, 'fogszuvas', 'egészséges', 'nagy vörös vörös barna', 'Kedveli a más kutyák jelenlétét.', 0, 0, '2022-04-15 00:00:00', 'allat_kepek/21.jpg'),
(83, 'Oszkár', '2018-04-03', 5, 'szuka', 'Hovawart', 'rossz', 1, 14, 'fogszuvas', 'rossz', 'kicsi tigriscsíkos fekete kék', 'Imádja a virágokat és a leveleket rágcsálni a kertben.', 1, 0, '2022-02-08 00:00:00', 'allat_kepek/153.jpg'),
(84, 'Gombi', '2018-03-15', 5, 'kan', 'Angol-francia falkavadász kopó', 'egészséges', 1, 16, 'foghiányos', 'egészséges', 'közepes sárga fekete zöld', 'Az öreg bulldog, Rocky, igazi kincs, aki mindig boldogságot hoz a házba.', 0, 0, '2022-10-01 00:00:00', 'allat_kepek/12.jpg'),
(85, 'Killer', '2015-06-20', 8, 'kan', 'Ausztrál pásztorkutya', 'egészséges', 0, 5, 'fogszuvas', 'egészséges', 'kicsi sárga vörös barna', 'A csendes és kiegyensúlyozott Bernese hegyi kutya, Maxine, nagyon szeret játszani és sétálni.', 0, 0, '2022-11-22 00:00:00', 'allat_kepek/183.jpg'),
(86, 'Csöpi', '2020-12-27', 3, 'kan', 'Yorkshire terrier', 'közepes', 1, 28, 'foghiányos', 'egészséges', 'nagy arany barna kék', 'A családi kutyánk, Max, egy érzékeny és játékos cocker spániel, aki mindig vidámságot visz a házba.', 1, 0, '2021-08-01 00:00:00', 'allat_kepek/190.jpg'),
(87, 'Bodri', '2020-07-24', 3, 'szuka', 'Black mouth cur', 'közepes', 0, 2, 'egészséges', 'közepes', 'közepes szürke rózsaszín barna', 'Kedveli az egyszerű ételeket, mint a csirkehús.', 0, 0, '2022-07-04 00:00:00', 'allat_kepek/207.jpg'),
(88, 'Úrfi', '2018-01-09', 5, 'kan', 'Bordeaux-i dog', 'rossz', 0, 14, 'fogszuvas', 'rossz', 'nagy barna fekete barna', 'Imádja a strandot és a tengerpartot.', 1, 0, '2021-06-11 00:00:00', 'allat_kepek/14.jpg'),
(89, 'Lucy', '2020-02-05', 3, 'kan', 'Armant', 'rossz', 1, 22, 'foghiányos', 'közepes', 'közepes fehér sötétbarna kék', 'Az élénk Vizsla, Daisy, mindig készen áll egy jó futásra vagy egy strandolásra.', 1, 0, '2021-10-20 00:00:00', 'allat_kepek/118.jpg'),
(90, 'Ibis', '2015-01-08', 8, 'szuka', 'Máltai selyemkutya', 'egészséges', 1, 4, 'egészséges', 'rossz', 'közepes vörös barna kék', 'Az én kutyám, Fido, egy fantasztikus és okos németjuhász, aki mindig megvédi a családját.', 0, 0, '2021-04-15 00:00:00', 'allat_kepek/138.jpg'),
(91, 'Jázmina', '2019-02-26', 4, 'kan', 'Skye terrier', 'egészséges', 1, 26, 'egészséges', 'rossz', 'közepes tigriscsíkos vörös zöld', 'Imádja a strandot és a tengerpartot.', 0, 0, '2022-02-25 00:00:00', 'allat_kepek/49.jpg'),
(92, 'Gerry', '2016-09-20', 7, 'szuka', 'Svájci fehér juhászkutya', 'egészséges', 1, 16, 'fogszuvas', 'rossz', 'közepes fekete fekete zöld', 'Szeret kirándulni az erdőben és felfedezni az új helyeket.', 0, 0, '2022-02-20 00:00:00', 'allat_kepek/19.jpg'),
(93, 'Mackó', '2015-06-05', 8, 'szuka', 'Magyar vizsla', 'rossz', 0, 24, 'foghiányos', 'rossz', 'nagy sárga fekete zöld', 'A hatalmas Saint Bernard, Brutus, imádja a gyerekeket és egy igazi öleb.', 0, 0, '2021-08-21 00:00:00', 'allat_kepek/21.jpg'),
(94, 'Melák', '2015-03-24', 8, 'kan', 'Törpespitz', 'egészséges', 1, 17, 'foghiányos', 'közepes', 'nagy fekete vörös kék', 'A játékos és barátságos Beagle, Snoopy, az összes családtag kedvence.', 0, 0, '2022-12-28 00:00:00', 'allat_kepek/84.jpg'),
(95, 'Gerry', '2015-05-14', 8, 'kan', 'Porcelánkopó', 'közepes', 1, 16, 'fogszuvas', 'közepes', 'nagy foltos rózsaszín zöld', 'Kedveli az egyszerű ételeket, mint a csirkehús.', 1, 0, '2022-03-18 00:00:00', 'allat_kepek/123.jpg'),
(96, 'Fáraó', '2019-09-16', 4, 'kan', 'Arab agár', 'közepes', 0, 5, 'egészséges', 'egészséges', 'nagy foltos rózsaszín kék', 'Kedveli a más kutyák jelenlétét.', 0, 0, '2021-08-12 00:00:00', 'allat_kepek/134.jpg'),
(97, 'Bagira', '2018-12-28', 5, 'szuka', 'Pikárdiai juhászkutya', 'egészséges', 1, 1, 'fogszuvas', 'közepes', 'nagy szürke barna zöld', 'Szeret más kutyákkal játszani a kutyaparkban.', 1, 0, '2022-01-27 00:00:00', 'allat_kepek/81.jpg'),
(98, 'Hobbit', '2016-07-03', 7, 'szuka', 'Spanyol agár', 'egészséges', 1, 1, 'foghiányos', 'egészséges', 'közepes tigriscsíkos sötétbarna barna', 'Szeret kirándulni az erdőben és felfedezni az új helyeket.', 0, 0, '2022-10-25 00:00:00', 'allat_kepek/83.jpg'),
(99, 'Fló', '2015-06-13', 8, 'kan', 'Norrbotteni spicc', 'rossz', 1, 17, 'egészséges', 'rossz', 'közepes fehér rózsaszín zöld', 'A családi kutyánk, Max, egy érzékeny és játékos cocker spániel, aki mindig vidámságot visz a házba.', 0, 0, '2022-04-10 00:00:00', 'allat_kepek/87.jpg'),
(100, 'Behemót', '2019-07-17', 4, 'szuka', 'Shikoku inu', 'rossz', 1, 25, 'egészséges', 'közepes', 'közepes foltos barna barna', 'Szeret játszani a gazdájával a kertben és a szobában is.', 0, 0, '2021-10-03 00:00:00', 'allat_kepek/10.jpg'),
(101, 'Jabba', '2017-03-16', 6, 'szuka', 'Boston terrier', 'közepes', 1, 24, 'foghiányos', 'egészséges', 'közepes foltos barna zöld', 'Az öreg bulldog, Rocky, igazi kincs, aki mindig boldogságot hoz a házba.', 1, 0, '2021-12-06 00:00:00', 'allat_kepek/110.jpg'),
(102, 'Zeusz', '2015-12-27', 8, 'kan', 'Fehér-fekete francia kopó', 'rossz', 1, 15, 'foghiányos', 'közepes', 'nagy fekete rózsaszín kék', 'A hatalmas Saint Bernard, Brutus, imádja a gyerekeket és egy igazi öleb.', 0, 0, '2022-01-01 00:00:00', 'allat_kepek/141.jpg'),
(103, 'Pufók', '2015-07-17', 8, 'kan', 'Német spicc', 'közepes', 0, 10, 'fogszuvas', 'közepes', 'kicsi szürke sötétbarna zöld', 'A border collie, Skipper, rendkívül intelligens és tanulékony, és szeret mindenféle trükköt és feladatot megoldani.', 1, 0, '2021-12-16 00:00:00', 'allat_kepek/4.jpg'),
(104, 'Rézi', '2020-01-26', 3, 'szuka', 'Perzsa agár', 'közepes', 1, 7, 'fogszuvas', 'egészséges', 'közepes fekete fekete zöld', 'A játékos és barátságos Beagle, Snoopy, az összes családtag kedvence.', 1, 0, '2021-12-28 00:00:00', 'allat_kepek/7.jpg'),
(105, 'Mancs', '2015-03-25', 8, 'szuka', 'Nagy angol-francia kopó', 'rossz', 1, 24, 'foghiányos', 'rossz', 'kicsi fehér barna barna', 'Szeret a kedvenc plüssjátékával játszani.', 0, 0, '2021-11-16 00:00:00', 'allat_kepek/83.jpg'),
(106, 'Kefir', '2018-06-07', 5, 'kan', 'Rouilers-i pászorkutya', 'egészséges', 1, 16, 'foghiányos', 'közepes', 'közepes foltos fekete barna', 'Szeret a gazdájával együtt aludni.', 0, 0, '2021-12-04 00:00:00', 'allat_kepek/80.jpg'),
(107, 'Shiva', '2018-07-16', 5, 'kan', 'Havannai pincs', 'rossz', 1, 6, 'fogszuvas', 'közepes', 'kicsi foltos barna barna', 'Szeret kirándulni az erdőben és felfedezni az új helyeket.', 1, 0, '2022-10-03 00:00:00', 'allat_kepek/125.jpg'),
(108, 'Zsuzsu', '2019-03-08', 4, 'kan', 'Bichon havanese', 'egészséges', 0, 19, 'egészséges', 'egészséges', 'kicsi foltos barna zöld', 'Kedveli a más kutyák jelenlétét.', 0, 0, '2022-11-27 00:00:00', 'allat_kepek/150.jpg'),
(109, 'Meggi', '2017-04-16', 6, 'szuka', 'Törpe uszkár', 'közepes', 0, 1, 'fogszuvas', 'rossz', 'kicsi barna sötétbarna kék', 'A kis Westie, Lulu, a legaranyosabb és legkedvesebb kutyus, akivel valaha találkoztam.', 0, 0, '2022-05-23 00:00:00', 'allat_kepek/164.jpg'),
(110, 'Bugatti', '2017-11-22', 6, 'kan', 'Magyar agár', 'rossz', 1, 25, 'egészséges', 'közepes', 'kicsi szürke rózsaszín zöld', 'Imádja, amikor a gazdája a gyomrát simogatja és kedvesen beszél hozzá.', 1, 0, '2022-09-21 00:00:00', 'allat_kepek/144.jpg'),
(111, 'Csöpi', '2019-07-08', 4, 'szuka', 'Spániel', 'rossz', 1, 30, 'fogszuvas', 'egészséges', 'kicsi sárga rózsaszín barna', 'A csendes és kiegyensúlyozott Bernese hegyi kutya, Maxine, nagyon szeret játszani és sétálni.', 0, 0, '2021-03-15 00:00:00', 'allat_kepek/1.jpg'),
(112, 'Müzli', '2017-08-19', 6, 'szuka', 'Hortaye Borzaya (Chortaj)', 'közepes', 0, 24, 'egészséges', 'rossz', 'közepes sárga rózsaszín zöld', 'A hatalmas Saint Bernard, Brutus, imádja a gyerekeket és egy igazi öleb.', 1, 0, '2022-06-17 00:00:00', 'allat_kepek/63.jpg'),
(113, 'Shiva', '2017-12-14', 6, 'kan', 'Armant', 'rossz', 1, 13, 'foghiányos', 'rossz', 'nagy fehér fekete zöld', 'A csendes és kiegyensúlyozott Bernese hegyi kutya, Maxine, nagyon szeret játszani és sétálni.', 0, 0, '2022-09-18 00:00:00', 'allat_kepek/144.jpg'),
(114, 'Suzy', '2017-01-04', 6, 'kan', 'Hosszúszőrű német vizsla', 'rossz', 1, 3, 'fogszuvas', 'egészséges', 'közepes foltos vörös kék', 'Kedveli a más kutyák jelenlétét.', 1, 0, '2021-10-06 00:00:00', 'allat_kepek/171.jpg'),
(115, 'Kloé', '2019-02-27', 4, 'szuka', 'Drótszőrű isztriai kopó', 'közepes', 1, 17, 'fogszuvas', 'egészséges', 'kicsi foltos sötétbarna zöld', 'Kedveli az egyszerű ételeket, mint a csirkehús.', 1, 0, '2021-05-07 00:00:00', 'allat_kepek/39.jpg'),
(116, 'Suzy', '2016-05-03', 7, 'kan', 'Csehszlovák farkaskutya', 'egészséges', 0, 15, 'foghiányos', 'egészséges', 'kicsi vörös sötétbarna barna', 'Kedveli az egyszerű ételeket, mint a csirkehús.', 1, 0, '2021-05-22 00:00:00', 'allat_kepek/177.jpg'),
(117, 'Kleó', '2019-08-28', 4, 'kan', 'Finn kopó', 'rossz', 1, 20, 'egészséges', 'közepes', 'nagy arany vörös barna', 'A játékos és barátságos Beagle, Snoopy, az összes családtag kedvence.', 1, 0, '2022-10-17 00:00:00', 'allat_kepek/162.jpg'),
(118, 'Bűvész', '2015-10-06', 8, 'szuka', 'Észak-amerikai juhászkutya', 'közepes', 1, 11, 'foghiányos', 'rossz', 'közepes szürke rózsaszín kék', 'A tacskó, Oscar, egy nagyon öntudatos és bátor kutya, aki ragaszkodik a szokásaihoz.', 1, 0, '2022-08-19 00:00:00', 'allat_kepek/169.jpg'),
(119, 'Adolf', '2015-11-04', 8, 'kan', 'Shar pei', 'rossz', 1, 6, 'fogszuvas', 'egészséges', 'nagy fekete vörös kék', 'Kedveli a más kutyák jelenlétét.', 0, 0, '2021-12-10 00:00:00', 'allat_kepek/131.jpg'),
(120, 'Ajax', '2018-01-13', 5, 'kan', 'Ausztrál selyemszőrű terrier', 'egészséges', 1, 13, 'foghiányos', 'egészséges', 'közepes tigriscsíkos fekete zöld', 'Imádja, amikor a gazdája a gyomrát simogatja és kedvesen beszél hozzá.', 1, 0, '2021-11-06 00:00:00', 'allat_kepek/65.jpg'),
(121, 'Molly', '2015-07-25', 8, 'kan', 'Bichon bolognese', 'rossz', 1, 29, 'egészséges', 'rossz', 'nagy barna fekete zöld', 'Szeret a kedvenc plüssjátékával játszani.', 1, 0, '2022-03-09 00:00:00', 'allat_kepek/184.jpg'),
(122, 'Leó', '2019-04-11', 4, 'kan', 'Kis schwyzi kopó', 'egészséges', 0, 1, 'fogszuvas', 'közepes', 'kicsi foltos barna barna', 'Kedveli az egyszerű ételeket, mint a csirkehús.', 0, 0, '2022-03-05 00:00:00', 'allat_kepek/76.jpg'),
(123, 'Nudli', '2017-12-12', 6, 'kan', 'Spanyol kopó', 'egészséges', 0, 8, 'foghiányos', 'közepes', 'kicsi vörös vörös barna', 'A nyugodt és okos labrador, Bella, egy igazi kisgyermekbarát kutya, aki imádja a családját.', 1, 0, '2022-03-06 00:00:00', 'allat_kepek/163.jpg'),
(124, 'Jimmy', '2020-02-08', 3, 'kan', 'Chippiparai', 'rossz', 1, 28, 'egészséges', 'rossz', 'nagy sárga sötétbarna kék', 'Tudja, hogy hogyan köszönjön és megálljon a piros lámpánál.', 1, 0, '2022-09-16 00:00:00', 'allat_kepek/187.jpg'),
(125, 'Inzy', '2016-12-03', 7, 'szuka', 'Groenendael', 'egészséges', 0, 16, 'fogszuvas', 'közepes', 'közepes barna barna zöld', 'A jólelkű Goldie mindig boldoggá teszi az embereket, kedves és szeretetre méltó társ.', 0, 0, '2022-03-15 00:00:00', 'allat_kepek/28.jpg'),
(126, 'Károly', '2017-01-19', 6, 'kan', 'Porcelánkopó', 'közepes', 1, 1, 'foghiányos', 'egészséges', 'közepes tigriscsíkos vörös kék', 'A jólelkű Goldie mindig boldoggá teszi az embereket, kedves és szeretetre méltó társ.', 1, 0, '2021-02-03 00:00:00', 'allat_kepek/122.jpg'),
(127, 'Jasper', '2016-08-22', 7, 'szuka', 'Óangol juhászkutya', 'rossz', 0, 27, 'foghiányos', 'egészséges', 'közepes szürke vörös kék', 'Kedveli a más kutyák jelenlétét.', 1, 0, '2022-11-10 00:00:00', 'allat_kepek/189.jpg'),
(128, 'Ursula', '2015-05-01', 8, 'szuka', 'Közép schnauzer', 'egészséges', 1, 2, 'egészséges', 'közepes', 'nagy arany vörös barna', 'Tudja, hogy hogyan köszönjön és megálljon a piros lámpánál.', 1, 0, '2021-09-25 00:00:00', 'allat_kepek/155.jpg'),
(129, 'Apolló', '2015-02-07', 8, 'kan', 'Bulldog', 'rossz', 0, 14, 'foghiányos', 'közepes', 'közepes arany vörös kék', 'A nyugodt és okos labrador, Bella, egy igazi kisgyermekbarát kutya, aki imádja a családját.', 1, 0, '2021-10-15 00:00:00', 'allat_kepek/40.jpg'),
(130, 'Okonor', '2019-04-07', 4, 'szuka', 'Alentejo masztiff', 'közepes', 1, 23, 'foghiányos', 'egészséges', 'nagy vörös vörös kék', 'Szeret más kutyákkal játszani a kutyaparkban.', 0, 0, '2021-09-15 00:00:00', 'allat_kepek/90.jpg'),
(131, 'Sámson', '2017-08-12', 6, 'szuka', 'Törpe uszkár', 'közepes', 1, 20, 'egészséges', 'közepes', 'nagy fekete rózsaszín barna', 'Imádja a virágokat és a leveleket rágcsálni a kertben.', 1, 0, '2021-11-16 00:00:00', 'allat_kepek/168.jpg'),
(132, 'Adél', '2018-01-08', 5, 'szuka', 'Glen of Imaal terrier', 'közepes', 1, 28, 'fogszuvas', 'közepes', 'közepes sárga sötétbarna zöld', 'A border collie, Skipper, rendkívül intelligens és tanulékony, és szeret mindenféle trükköt és feladatot megoldani.', 0, 0, '2022-10-05 00:00:00', 'allat_kepek/164.jpg'),
(133, 'Orchidea', '2019-12-23', 4, 'szuka', 'Hosszúszőrű pireneusi juhászkutya', 'egészséges', 0, 16, 'egészséges', 'rossz', 'nagy fekete fekete barna', 'A családi kutyánk, Max, egy érzékeny és játékos cocker spániel, aki mindig vidámságot visz a házba.', 1, 0, '2021-10-02 00:00:00', 'allat_kepek/78.jpg'),
(134, 'Fifi', '2015-12-09', 8, 'kan', 'Utonagan', 'egészséges', 0, 24, 'fogszuvas', 'rossz', 'közepes arany barna barna', 'Az élénk Vizsla, Daisy, mindig készen áll egy jó futásra vagy egy strandolásra.', 0, 0, '2021-07-26 00:00:00', 'allat_kepek/22.jpg'),
(135, 'Wolf', '2015-06-17', 8, 'kan', 'Lucas terrier', 'egészséges', 1, 9, 'foghiányos', 'rossz', 'kicsi arany barna kék', 'A játékos és barátságos Beagle, Snoopy, az összes családtag kedvence.', 0, 0, '2022-01-25 00:00:00', 'allat_kepek/64.jpg'),
(136, 'Don', '2016-06-27', 7, 'kan', 'Toy uszkár', 'közepes', 1, 21, 'foghiányos', 'egészséges', 'közepes fekete sötétbarna barna', 'A nyugodt és okos labrador, Bella, egy igazi kisgyermekbarát kutya, aki imádja a családját.', 1, 0, '2021-04-11 00:00:00', 'allat_kepek/91.jpg'),
(137, 'Gopher', '2017-12-10', 6, 'szuka', 'Tervueren', 'közepes', 1, 14, 'egészséges', 'egészséges', 'nagy fekete fekete kék', 'A kis Westie, Lulu, a legaranyosabb és legkedvesebb kutyus, akivel valaha találkoztam.', 1, 0, '2022-11-02 00:00:00', 'allat_kepek/180.jpg'),
(138, 'Jet', '2020-08-10', 3, 'szuka', 'Belga griffon', 'egészséges', 0, 16, 'egészséges', 'rossz', 'közepes sárga sötétbarna zöld', 'A picinyke Chico nagyon aktív és energikus, mindig készen áll egy játékra vagy egy sétára.', 1, 0, '2022-02-06 00:00:00', 'allat_kepek/128.jpg'),
(139, 'Jet', '2018-10-16', 5, 'szuka', 'Saage kochee', 'egészséges', 0, 6, 'foghiányos', 'egészséges', 'kicsi fehér sötétbarna zöld', 'A csendes és kiegyensúlyozott Bernese hegyi kutya, Maxine, nagyon szeret játszani és sétálni.', 0, 0, '2021-04-10 00:00:00', 'allat_kepek/16.jpg'),
(140, 'Jágó', '2018-05-17', 5, 'kan', 'Szamojéd', 'egészséges', 0, 30, 'foghiányos', 'egészséges', 'kicsi tigriscsíkos vörös zöld', 'A játékos és barátságos Beagle, Snoopy, az összes családtag kedvence.', 0, 0, '2021-04-26 00:00:00', 'allat_kepek/35.jpg'),
(141, 'Éva', '2017-07-09', 6, 'szuka', 'Kis angol-francia rókakopó', 'rossz', 0, 8, 'foghiányos', 'rossz', 'közepes fehér vörös barna', 'A családi kutyánk, Max, egy érzékeny és játékos cocker spániel, aki mindig vidámságot visz a házba.', 0, 0, '2021-12-13 00:00:00', 'allat_kepek/144.jpg'),
(142, 'Milli', '2015-01-26', 8, 'szuka', 'Román pásztor kutya', 'egészséges', 0, 18, 'fogszuvas', 'egészséges', 'kicsi tigriscsíkos sötétbarna barna', 'Imádja a virágokat és a leveleket rágcsálni a kertben.', 0, 0, '2022-04-10 00:00:00', 'allat_kepek/191.jpg'),
(143, 'Pedró', '2018-06-08', 5, 'kan', 'Bullterrier', 'egészséges', 0, 18, 'egészséges', 'közepes', 'nagy sárga barna kék', 'Szeret a gazdájával együtt aludni.', 1, 0, '2021-07-06 00:00:00', 'allat_kepek/39.jpg'),
(144, 'Fifi', '2020-01-28', 3, 'szuka', 'Clumber spániel', 'rossz', 0, 3, 'fogszuvas', 'egészséges', 'nagy foltos rózsaszín zöld', 'Szeret dörgölőzni a gazdájával és más emberekkel is.', 1, 0, '2022-05-03 00:00:00', 'allat_kepek/127.jpg'),
(145, 'Kleó', '2019-12-03', 4, 'kan', 'Chippiparai', 'rossz', 0, 6, 'egészséges', 'egészséges', 'nagy barna vörös kék', 'Szeret dörgölőzni a gazdájával és más emberekkel is.', 1, 0, '2022-12-08 00:00:00', 'allat_kepek/18.jpg'),
(146, 'Milli', '2018-03-13', 5, 'szuka', 'Chinook', 'közepes', 1, 15, 'fogszuvas', 'egészséges', 'kicsi vörös vörös kék', 'Imádja a virágokat és a leveleket rágcsálni a kertben.', 0, 0, '2021-06-28 00:00:00', 'allat_kepek/8.jpg'),
(147, 'Shiva', '2019-06-12', 4, 'kan', 'Markiesje', 'rossz', 0, 30, 'fogszuvas', 'egészséges', 'nagy barna fekete barna', 'Az öreg bulldog, Rocky, igazi kincs, aki mindig boldogságot hoz a házba.', 0, 0, '2021-02-05 00:00:00', 'allat_kepek/149.jpg'),
(148, 'Gerry', '2020-09-23', 3, 'kan', 'Keverék', 'közepes', 1, 11, 'foghiányos', 'rossz', 'közepes fekete barna zöld', 'A tacskó, Oscar, egy nagyon öntudatos és bátor kutya, aki ragaszkodik a szokásaihoz.', 1, 0, '2021-09-21 00:00:00', 'allat_kepek/82.jpg'),
(149, 'Elíz', '2017-01-19', 6, 'szuka', 'Cardigan welsh corgi', 'közepes', 0, 26, 'fogszuvas', 'egészséges', 'nagy sárga sötétbarna zöld', 'Az élénk Vizsla, Daisy, mindig készen áll egy jó futásra vagy egy strandolásra.', 1, 0, '2022-11-09 00:00:00', 'allat_kepek/37.jpg'),
(150, 'Lasszó', '2017-05-01', 6, 'szuka', 'Airedale terrier', 'közepes', 1, 8, 'fogszuvas', 'rossz', 'nagy arany rózsaszín barna', 'A hatalmas Saint Bernard, Brutus, imádja a gyerekeket és egy igazi öleb.', 0, 0, '2021-09-15 00:00:00', 'allat_kepek/20.jpg'),
(151, 'Mogyoró', '2020-03-10', 3, 'kan', 'Amerikai Bulldog', 'közepes', 0, 20, 'fogszuvas', 'rossz', 'kicsi tigriscsíkos barna zöld', 'A vidám és játékos spániel, Lucky, imádja a strandolást és a vízben való pancsolást.', 0, 0, '2022-02-12 00:00:00', 'allat_kepek/47.jpg'),
(152, 'Grész', '2016-02-24', 7, 'kan', 'Szerb kopó', 'egészséges', 0, 28, 'fogszuvas', 'rossz', 'kicsi sárga barna barna', 'Szeret a kedvenc plüssjátékával játszani.', 1, 0, '2022-04-12 00:00:00', 'allat_kepek/30.jpg'),
(153, 'Ládikó', '2018-08-12', 5, 'szuka', 'Cardigan welsh corgi', 'közepes', 1, 13, 'foghiányos', 'egészséges', 'kicsi fehér rózsaszín barna', 'Szeret kirándulni az erdőben és felfedezni az új helyeket.', 1, 0, '2021-11-02 00:00:00', 'allat_kepek/178.jpg'),
(154, 'Kai', '2015-06-04', 8, 'kan', 'Akbash', 'egészséges', 1, 28, 'egészséges', 'rossz', 'közepes fekete barna barna', 'Szeret sétálni az utcán és megfigyelni az embereket és az állatokat.', 1, 0, '2021-07-27 00:00:00', 'allat_kepek/68.jpg'),
(155, 'Scott', '2019-11-19', 4, 'szuka', 'Ibizai kopó', 'egészséges', 0, 25, 'egészséges', 'közepes', 'nagy foltos rózsaszín kék', 'A vidám és játékos spániel, Lucky, imádja a strandolást és a vízben való pancsolást.', 0, 0, '2022-02-15 00:00:00', 'allat_kepek/54.jpg'),
(156, 'Gombi', '2020-07-25', 3, 'szuka', 'Pumi', 'egészséges', 1, 16, 'foghiányos', 'egészséges', 'kicsi fehér barna zöld', 'Szeret játszani a gazdájával a kertben és a szobában is.', 0, 0, '2021-10-25 00:00:00', 'allat_kepek/75.jpg'),
(157, 'Jerry', '2015-06-11', 8, 'szuka', 'Norfolk terrier', 'közepes', 1, 16, 'fogszuvas', 'közepes', 'kicsi szürke fekete kék', 'A vidám és játékos spániel, Lucky, imádja a strandolást és a vízben való pancsolást.', 1, 0, '2021-05-16 00:00:00', 'allat_kepek/126.jpg'),
(158, 'Furby', '2016-01-16', 7, 'kan', 'Perui meztelen kutya', 'közepes', 1, 29, 'fogszuvas', 'közepes', 'kicsi tigriscsíkos vörös barna', 'Az érzékeny és odaadó pitbull, Luna, a család kiskedvence, aki imádja a játékot és a simogatást.', 1, 0, '2021-07-16 00:00:00', 'allat_kepek/100.jpg'),
(159, 'Ádáz', '2016-10-15', 7, 'szuka', 'bolonka francuska', 'közepes', 0, 19, 'fogszuvas', 'rossz', 'kicsi szürke fekete zöld', 'A picinyke Chico nagyon aktív és energikus, mindig készen áll egy játékra vagy egy sétára.', 1, 0, '2022-05-17 00:00:00', 'allat_kepek/88.jpg'),
(160, 'Sparco', '2020-07-02', 3, 'szuka', 'Groenendael', 'rossz', 1, 30, 'foghiányos', 'egészséges', 'közepes sárga fekete kék', 'A csendes és kiegyensúlyozott Bernese hegyi kutya, Maxine, nagyon szeret játszani és sétálni.', 0, 0, '2022-03-05 00:00:00', 'allat_kepek/132.jpg'),
(161, 'Hektor', '2019-08-09', 4, 'kan', 'Kishu ken', 'közepes', 1, 25, 'egészséges', 'rossz', 'kicsi barna barna zöld', 'A játékos és barátságos Beagle, Snoopy, az összes családtag kedvence.', 1, 0, '2021-04-06 00:00:00', 'allat_kepek/12.jpg'),
(162, 'Jerry', '2017-09-15', 6, 'szuka', 'Keverék', 'egészséges', 0, 3, 'foghiányos', 'rossz', 'nagy sárga barna barna', 'A nyugodt és okos labrador, Bella, egy igazi kisgyermekbarát kutya, aki imádja a családját.', 1, 0, '2022-11-15 00:00:00', 'allat_kepek/90.jpg'),
(163, 'Rénó', '2020-02-03', 3, 'szuka', 'Trikolor francia kopó', 'egészséges', 1, 30, 'egészséges', 'rossz', 'nagy fehér rózsaszín kék', 'A border collie, Skipper, rendkívül intelligens és tanulékony, és szeret mindenféle trükköt és feladatot megoldani.', 0, 0, '2021-02-28 00:00:00', 'allat_kepek/166.jpg'),
(164, 'Don', '2019-09-14', 4, 'szuka', 'Svéd juhászspitz', 'rossz', 1, 7, 'fogszuvas', 'egészséges', 'kicsi foltos vörös zöld', 'A tacskó, Oscar, egy nagyon öntudatos és bátor kutya, aki ragaszkodik a szokásaihoz.', 1, 0, '2022-05-05 00:00:00', 'allat_kepek/57.jpg'),
(165, 'Apolló', '2020-07-19', 3, 'szuka', 'Jämthund', 'közepes', 1, 22, 'fogszuvas', 'rossz', 'nagy arany barna barna', 'Az én kutyám, Fido, egy fantasztikus és okos németjuhász, aki mindig megvédi a családját.', 1, 0, '2022-10-16 00:00:00', 'allat_kepek/163.jpg'),
(166, 'Lassie', '2020-07-07', 3, 'szuka', 'Leonbergi', 'rossz', 0, 5, 'egészséges', 'közepes', 'kicsi vörös vörös kék', 'A jólelkű Goldie mindig boldoggá teszi az embereket, kedves és szeretetre méltó társ.', 0, 0, '2021-03-06 00:00:00', 'allat_kepek/170.jpg'),
(167, 'Suhanc', '2018-06-19', 5, 'szuka', 'Malinois', 'közepes', 1, 14, 'fogszuvas', 'közepes', 'közepes fekete vörös barna', 'Szeret kirándulni az erdőben és felfedezni az új helyeket.', 1, 0, '2021-07-11 00:00:00', 'allat_kepek/140.jpg'),
(168, 'Jenny', '2015-05-08', 8, 'kan', 'Dunker', 'rossz', 0, 17, 'fogszuvas', 'rossz', 'közepes fehér barna zöld', 'A családi kutyánk, Max, egy érzékeny és játékos cocker spániel, aki mindig vidámságot visz a házba.', 1, 0, '2021-06-01 00:00:00', 'allat_kepek/43.jpg'),
(169, 'Jasper', '2016-12-13', 7, 'szuka', 'Cirneco dell’Etna', 'egészséges', 0, 1, 'egészséges', 'rossz', 'kicsi barna fekete barna', 'Szeret sétálni az utcán és megfigyelni az embereket és az állatokat.', 0, 0, '2021-12-27 00:00:00', 'allat_kepek/3.jpg'),
(170, 'Pajtás', '2018-06-23', 5, 'szuka', 'Halden kopó', 'egészséges', 0, 28, 'foghiányos', 'rossz', 'közepes barna vörös zöld', 'Szeret dörgölőzni a gazdájával és más emberekkel is.', 0, 0, '2021-02-02 00:00:00', 'allat_kepek/63.jpg'),
(171, 'Glédis', '2017-02-25', 6, 'szuka', 'Nagyspitz', 'közepes', 1, 6, 'egészséges', 'közepes', 'nagy barna fekete kék', 'A vidám és játékos spániel, Lucky, imádja a strandolást és a vízben való pancsolást.', 0, 0, '2021-06-07 00:00:00', 'allat_kepek/203.jpg'),
(172, 'Sonny', '2017-10-20', 6, 'kan', 'Kaukázusi juhászkutya', 'egészséges', 1, 27, 'egészséges', 'rossz', 'nagy fehér sötétbarna kék', 'Szeret dörgölőzni a gazdájával és más emberekkel is.', 1, 0, '2021-02-20 00:00:00', 'allat_kepek/49.jpg'),
(173, 'Izabell', '2017-02-11', 6, 'szuka', 'Malinois', 'rossz', 1, 7, 'egészséges', 'rossz', 'közepes fehér rózsaszín zöld', 'Szeret más kutyákkal játszani a kutyaparkban.', 1, 0, '2022-09-25 00:00:00', 'allat_kepek/126.jpg'),
(174, 'Ádáz', '2015-10-04', 8, 'szuka', 'Kínai kopasz kutya', 'közepes', 1, 15, 'egészséges', 'rossz', 'kicsi fehér sötétbarna barna', 'Szeret sétálni az utcán és megfigyelni az embereket és az állatokat.', 1, 0, '2022-10-03 00:00:00', 'allat_kepek/2.jpg'),
(175, 'Úrfi', '2019-01-17', 4, 'kan', 'Hosszúszőrű skót juhászkutya', 'rossz', 0, 26, 'fogszuvas', 'rossz', 'nagy tigriscsíkos fekete barna', 'Szeret a kedvenc plüssjátékával játszani.', 1, 0, '2021-05-10 00:00:00', 'allat_kepek/26.jpg'),
(176, 'Maggie', '2017-12-11', 6, 'szuka', 'Beauce-i juhászkutya', 'egészséges', 1, 8, 'egészséges', 'közepes', 'közepes tigriscsíkos fekete kék', 'Kedveli a más kutyák jelenlétét.', 0, 0, '2021-04-21 00:00:00', 'allat_kepek/22.jpg'),
(177, 'Nevada', '2016-11-11', 7, 'kan', 'Stájeri drótszőrű kopó', 'közepes', 1, 30, 'foghiányos', 'rossz', 'közepes barna sötétbarna zöld', 'A hatalmas Saint Bernard, Brutus, imádja a gyerekeket és egy igazi öleb.', 0, 0, '2022-02-05 00:00:00', 'allat_kepek/168.jpg'),
(178, 'Csibész', '2018-04-23', 5, 'szuka', 'Barbet', 'egészséges', 1, 18, 'foghiányos', 'rossz', 'közepes fekete fekete barna', 'Szeret dörgölőzni a gazdájával és más emberekkel is.', 1, 0, '2021-08-22 00:00:00', 'allat_kepek/69.jpg'),
(179, 'Sámson', '2016-01-18', 7, 'kan', 'Hosszúszőrű pireneusi juhászkutya', 'rossz', 0, 29, 'egészséges', 'egészséges', 'nagy vörös rózsaszín barna', 'Kedveli a más kutyák jelenlétét.', 1, 0, '2021-09-21 00:00:00', 'allat_kepek/24.jpg'),
(180, 'Kai', '2019-07-19', 4, 'szuka', 'Cairn terrier', 'egészséges', 0, 29, 'fogszuvas', 'közepes', 'nagy fekete sötétbarna barna', 'Imádja a virágokat és a leveleket rágcsálni a kertben.', 0, 0, '2021-03-07 00:00:00', 'allat_kepek/181.jpg'),
(181, 'Szerecsendió', '2020-01-09', 3, 'kan', 'bolonka cvetna', 'egészséges', 0, 19, 'foghiányos', 'egészséges', 'közepes tigriscsíkos vörös kék', 'Az élénk Vizsla, Daisy, mindig készen áll egy jó futásra vagy egy strandolásra.', 0, 0, '2022-04-05 00:00:00', 'allat_kepek/71.jpg'),
(182, 'Wolf', '2017-03-26', 6, 'szuka', 'Amerikai vízispániel', 'közepes', 0, 6, 'fogszuvas', 'közepes', 'kicsi sárga vörös barna', 'A picinyke Chico nagyon aktív és energikus, mindig készen áll egy játékra vagy egy sétára.', 0, 0, '2021-03-12 00:00:00', 'allat_kepek/0.jpg'),
(183, 'Molly', '2015-04-05', 8, 'szuka', 'King Shepherd', 'közepes', 0, 2, 'foghiányos', 'rossz', 'nagy fekete sötétbarna kék', 'Az érzékeny és odaadó pitbull, Luna, a család kiskedvence, aki imádja a játékot és a simogatást.', 0, 0, '2021-04-08 00:00:00', 'allat_kepek/201.jpg'),
(184, 'Gerry', '2015-12-14', 8, 'szuka', 'Tibeti terrier', 'közepes', 0, 30, 'foghiányos', 'közepes', 'nagy fehér barna zöld', 'Az élénk Vizsla, Daisy, mindig készen áll egy jó futásra vagy egy strandolásra.', 0, 0, '2022-01-01 00:00:00', 'allat_kepek/117.jpg'),
(185, 'Anasztázia', '2015-05-23', 8, 'szuka', 'Orosz toy terrier', 'rossz', 0, 20, 'foghiányos', 'rossz', 'kicsi vörös rózsaszín barna', 'Imádja, amikor a gazdája a gyomrát simogatja és kedvesen beszél hozzá.', 0, 0, '2021-03-05 00:00:00', 'allat_kepek/106.jpg'),
(186, 'Amanda', '2018-09-05', 5, 'szuka', 'Angol mosómedvekopó', 'egészséges', 1, 10, 'foghiányos', 'egészséges', 'kicsi sárga rózsaszín kék', 'A családi kutyánk, Max, egy érzékeny és játékos cocker spániel, aki mindig vidámságot visz a házba.', 1, 0, '2022-10-18 00:00:00', 'allat_kepek/110.jpg'),
(187, 'Karcsi', '2017-04-27', 6, 'szuka', 'Si-cu', 'rossz', 0, 30, 'foghiányos', 'egészséges', 'közepes sárga barna kék', 'A csendes és kiegyensúlyozott Bernese hegyi kutya, Maxine, nagyon szeret játszani és sétálni.', 0, 0, '2022-05-17 00:00:00', 'allat_kepek/108.jpg'),
(188, 'Suhanc', '2019-04-28', 4, 'kan', 'Szávavölgyi kopó', 'közepes', 0, 16, 'fogszuvas', 'rossz', 'nagy barna vörös barna', 'Az érzékeny és odaadó pitbull, Luna, a család kiskedvence, aki imádja a játékot és a simogatást.', 0, 0, '2022-03-25 00:00:00', 'allat_kepek/144.jpg'),
(189, 'Bessz', '2019-01-15', 4, 'szuka', 'Kangaroo Dog', 'rossz', 1, 10, 'egészséges', 'közepes', 'közepes fehér barna zöld', 'Az élénk Vizsla, Daisy, mindig készen áll egy jó futásra vagy egy strandolásra.', 1, 0, '2021-05-08 00:00:00', 'allat_kepek/63.jpg'),
(190, 'Dolfi', '2015-06-20', 8, 'szuka', 'Manchester terrier', 'közepes', 1, 28, 'foghiányos', 'közepes', 'kicsi arany fekete zöld', 'A tacskó, Oscar, egy nagyon öntudatos és bátor kutya, aki ragaszkodik a szokásaihoz.', 1, 0, '2022-02-16 00:00:00', 'allat_kepek/95.jpg'),
(191, 'Gombi', '2015-09-03', 8, 'szuka', 'Lundehund', 'közepes', 0, 9, 'fogszuvas', 'közepes', 'kicsi tigriscsíkos sötétbarna kék', 'Szeret dörgölőzni a gazdájával és más emberekkel is.', 0, 0, '2021-05-22 00:00:00', 'allat_kepek/194.jpg'),
(192, 'Gombi', '2015-01-11', 8, 'szuka', 'Stájeri drótszőrű kopó', 'egészséges', 1, 2, 'fogszuvas', 'közepes', 'nagy fehér rózsaszín barna', 'A csendes és kiegyensúlyozott Bernese hegyi kutya, Maxine, nagyon szeret játszani és sétálni.', 0, 0, '2022-10-24 00:00:00', 'allat_kepek/40.jpg'),
(193, 'Jágó', '2016-06-05', 7, 'szuka', 'Fehér-cser nagy angol-francia kopó', 'rossz', 0, 2, 'egészséges', 'rossz', 'közepes tigriscsíkos barna kék', 'Szeret sétálni az utcán és megfigyelni az embereket és az állatokat.', 0, 0, '2021-07-21 00:00:00', 'allat_kepek/37.jpg'),
(194, 'Rómeó', '2020-11-04', 3, 'szuka', 'Pudelpointer', 'rossz', 0, 7, 'foghiányos', 'közepes', 'nagy vörös fekete barna', 'A hatalmas Saint Bernard, Brutus, imádja a gyerekeket és egy igazi öleb.', 0, 0, '2022-04-16 00:00:00', 'allat_kepek/18.jpg'),
(195, 'Kuku', '2017-05-01', 6, 'kan', 'Entlebuchi havasi kutya', 'közepes', 0, 9, 'egészséges', 'rossz', 'közepes arany vörös kék', 'Szeret a gazdájával együtt aludni.', 0, 0, '2021-09-14 00:00:00', 'allat_kepek/120.jpg');
INSERT INTO `allatok` (`allat_id`, `allat_nev`, `szul_ev`, `becsult_kor`, `neme`, `fajta`, `eu_allapot`, `ivar_ivartalanitot`, `suly`, `fogazatt`, `testi_allapott`, `ismertetojegyek`, `megjegyzes`, `chip`, `orokbeadas`, `befogadas_datuma`, `img`) VALUES
(196, 'Shiva', '2015-05-02', 8, 'kan', 'Olasz kopó', 'rossz', 0, 28, 'foghiányos', 'egészséges', 'nagy arany rózsaszín barna', 'A picinyke Chico nagyon aktív és energikus, mindig készen áll egy játékra vagy egy sétára.', 1, 0, '2022-07-23 00:00:00', 'allat_kepek/88.jpg'),
(197, 'Félix', '2017-06-22', 6, 'szuka', 'Svéd lapphund', 'közepes', 1, 23, 'fogszuvas', 'közepes', 'nagy tigriscsíkos sötétbarna barna', 'Szeret más kutyákkal játszani a kutyaparkban.', 1, 0, '2022-06-14 00:00:00', 'allat_kepek/140.jpg'),
(198, 'Edith', '2019-08-18', 4, 'szuka', 'Skót szarvasagár', 'egészséges', 0, 2, 'foghiányos', 'rossz', 'kicsi fekete sötétbarna barna', 'Imádja a strandot és a tengerpartot.', 1, 0, '2021-08-06 00:00:00', 'allat_kepek/101.jpg'),
(199, 'Inzy', '2020-04-12', 3, 'kan', 'Spániel', 'rossz', 1, 25, 'fogszuvas', 'rossz', 'kicsi fekete rózsaszín barna', 'A border collie, Skipper, rendkívül intelligens és tanulékony, és szeret mindenféle trükköt és feladatot megoldani.', 1, 0, '2021-11-21 00:00:00', 'allat_kepek/185.jpg'),
(200, 'Gigi', '2016-10-27', 7, 'kan', 'Welsh terrier', 'közepes', 0, 8, 'egészséges', 'közepes', 'nagy fehér rózsaszín barna', 'Szeret összebújni a gazdájával az esőben.', 1, 0, '2021-08-13 00:00:00', 'allat_kepek/185.jpg'),
(201, 'Beethoven', '2019-12-17', 4, 'szuka', 'Kínai kopasz kutya', 'közepes', 1, 23, 'fogszuvas', 'rossz', 'kicsi fekete vörös zöld', 'Szeret kóborolni az erdőben.', 0, 0, '2022-04-24 00:00:00', 'allat_kepek/208.jpg'),
(202, 'Adolf', '2015-02-17', 8, 'szuka', 'Szlovák csuvacs', 'rossz', 1, 9, 'foghiányos', 'rossz', 'kicsi sárga fekete barna', 'Szeret futkározni a futópályán.', 1, 0, '2021-03-02 00:00:00', 'allat_kepek/112.jpg'),
(203, 'Jasper', '2019-10-08', 4, 'szuka', 'Angol cocker spániel', 'egészséges', 1, 5, 'foghiányos', 'egészséges', 'kicsi arany rózsaszín barna', 'Szeret a gazdájával együtt aludni.', 0, 0, '2021-08-03 00:00:00', 'allat_kepek/30.jpg'),
(204, 'Kuku', '2017-06-21', 6, 'kan', 'Lengyel vadászkutya', 'egészséges', 0, 17, 'foghiányos', 'egészséges', 'közepes fehér vörös barna', 'A családi kutyánk, Max, egy érzékeny és játékos cocker spániel, aki mindig vidámságot visz a házba.', 0, 0, '2021-11-19 00:00:00', 'allat_kepek/75.jpg'),
(205, 'Maggie', '2019-12-27', 4, 'kan', 'Norvég elghund', 'rossz', 1, 18, 'foghiányos', 'egészséges', 'kicsi foltos vörös kék', 'Szeret a gazdájával együtt aludni.', 1, 0, '2021-09-02 00:00:00', 'allat_kepek/8.jpg'),
(206, 'Kloé', '2016-11-08', 7, 'szuka', 'Karéliai medvekutya', 'egészséges', 0, 10, 'fogszuvas', 'egészséges', 'kicsi vörös sötétbarna kék', 'Szeret dörgölőzni a gazdájával és más emberekkel is.', 1, 0, '2021-05-09 00:00:00', 'allat_kepek/1.jpg'),
(207, 'Don', '2019-08-13', 4, 'szuka', 'Whippet', 'egészséges', 1, 29, 'foghiányos', 'egészséges', 'közepes tigriscsíkos rózsaszín zöld', 'Kedveli az egyszerű ételeket, mint a csirkehús.', 1, 0, '2021-11-22 00:00:00', 'allat_kepek/119.jpg'),
(208, 'Úrfi', '2019-06-07', 4, 'szuka', 'Artois-i kopó', 'egészséges', 1, 2, 'fogszuvas', 'közepes', 'nagy sárga rózsaszín barna', 'Az én kutyám, Fido, egy fantasztikus és okos németjuhász, aki mindig megvédi a családját.', 1, 0, '2021-11-25 00:00:00', 'allat_kepek/9.jpg'),
(209, 'Rejtély', '2020-09-11', 3, 'szuka', 'Kai ken', 'rossz', 0, 17, 'foghiányos', 'közepes', 'közepes szürke barna zöld', 'Az érzékeny és odaadó pitbull, Luna, a család kiskedvence, aki imádja a játékot és a simogatást.', 1, 0, '2022-03-02 00:00:00', 'allat_kepek/77.jpg'),
(210, 'Maya', '2018-05-04', 5, 'szuka', 'West highland white terrier', 'rossz', 0, 4, 'egészséges', 'rossz', 'nagy vörös rózsaszín barna', 'Szeret kirándulni az erdőben és felfedezni az új helyeket.', 1, 0, '2022-10-27 00:00:00', 'allat_kepek/86.jpg'),
(211, 'Orlando', '2016-11-27', 7, 'kan', 'Kínai kopasz kutya', 'rossz', 0, 18, 'foghiányos', 'egészséges', 'közepes vörös sötétbarna zöld', 'Szeret a gazdájával együtt aludni.', 0, 0, '2021-09-08 00:00:00', 'allat_kepek/34.jpg'),
(212, 'Goldy', '2019-05-05', 4, 'kan', 'Sinka', 'közepes', 1, 2, 'egészséges', 'rossz', 'kicsi arany vörös zöld', 'Szeret játszani a gazdájával a kertben és a szobában is.', 0, 0, '2022-12-12 00:00:00', 'allat_kepek/28.jpg'),
(213, 'Melák', '2017-01-13', 6, 'szuka', 'Ariége-i kopó', 'egészséges', 1, 19, 'egészséges', 'rossz', 'nagy szürke fekete kék', 'A tacskó, Oscar, egy nagyon öntudatos és bátor kutya, aki ragaszkodik a szokásaihoz.', 0, 0, '2021-03-22 00:00:00', 'allat_kepek/188.jpg'),
(214, 'Kefir', '2017-09-07', 6, 'szuka', 'Ausztrál kelpie', 'rossz', 1, 26, 'fogszuvas', 'közepes', 'kicsi sárga barna zöld', 'A kis Westie, Lulu, a legaranyosabb és legkedvesebb kutyus, akivel valaha találkoztam.', 0, 0, '2022-04-22 00:00:00', 'allat_kepek/71.jpg'),
(215, 'Glédis', '2016-04-18', 7, 'szuka', 'Német pinscher', 'közepes', 0, 7, 'fogszuvas', 'rossz', 'közepes barna rózsaszín zöld', 'Szeret kirándulni az erdőben és felfedezni az új helyeket.', 1, 0, '2021-07-02 00:00:00', 'allat_kepek/124.jpg'),
(216, 'Alfonz', '2015-10-26', 8, 'szuka', 'Szlovák drótszőrű vizsla', 'közepes', 1, 5, 'fogszuvas', 'közepes', 'kicsi foltos rózsaszín zöld', 'Kedveli az egyszerű ételeket, mint a csirkehús.', 0, 0, '2022-11-10 00:00:00', 'allat_kepek/112.jpg'),
(217, 'Azték', '2020-11-15', 3, 'kan', 'Fáraókutya', 'közepes', 1, 20, 'foghiányos', 'közepes', 'nagy fekete fekete zöld', 'A nyugodt és okos labrador, Bella, egy igazi kisgyermekbarát kutya, aki imádja a családját.', 1, 0, '2022-05-24 00:00:00', 'allat_kepek/91.jpg'),
(218, 'Jet', '2020-05-25', 3, 'kan', 'Drótszőrű német vizsla', 'rossz', 0, 1, 'egészséges', 'rossz', 'közepes fekete sötétbarna barna', 'A családi kutyánk, Max, egy érzékeny és játékos cocker spániel, aki mindig vidámságot visz a házba.', 1, 0, '2022-12-09 00:00:00', 'allat_kepek/74.jpg'),
(219, 'Mimi', '2016-01-17', 7, 'szuka', 'Fríz vízikutya', 'közepes', 1, 10, 'egészséges', 'egészséges', 'közepes arany vörös kék', 'A nyugodt és okos labrador, Bella, egy igazi kisgyermekbarát kutya, aki imádja a családját.', 1, 0, '2022-02-03 00:00:00', 'allat_kepek/16.jpg'),
(220, 'Sparco', '2016-06-24', 7, 'kan', 'Német kopó', 'közepes', 0, 5, 'foghiányos', 'rossz', 'nagy sárga fekete zöld', 'A hatalmas Saint Bernard, Brutus, imádja a gyerekeket és egy igazi öleb.', 1, 0, '2021-12-17 00:00:00', 'allat_kepek/38.jpg'),
(221, 'Kelly', '2018-09-25', 5, 'szuka', 'Blue lacy', 'közepes', 0, 22, 'egészséges', 'egészséges', 'kicsi szürke vörös barna', 'Szeret dörgölőzni a gazdájával és más emberekkel is.', 0, 0, '2021-08-13 00:00:00', 'allat_kepek/87.jpg'),
(222, 'Peggi', '2017-10-27', 6, 'szuka', 'Ír farkaskutya', 'egészséges', 1, 10, 'foghiányos', 'közepes', 'kicsi vörös barna kék', 'A tacskó, Oscar, egy nagyon öntudatos és bátor kutya, aki ragaszkodik a szokásaihoz.', 0, 0, '2022-11-25 00:00:00', 'allat_kepek/137.jpg'),
(223, 'Okonor', '2018-11-20', 5, 'szuka', 'Hosszúszőrű német vizsla', 'közepes', 0, 12, 'fogszuvas', 'egészséges', 'nagy fekete fekete zöld', 'A picinyke Chico nagyon aktív és energikus, mindig készen áll egy játékra vagy egy sétára.', 0, 0, '2022-07-23 00:00:00', 'allat_kepek/49.jpg'),
(224, 'Keisha', '2019-11-11', 4, 'szuka', 'Moszkvai hosszú szőrű toy terrier', 'egészséges', 1, 8, 'fogszuvas', 'közepes', 'közepes foltos sötétbarna barna', 'Szeret játszani a gazdájával a kertben és a szobában is.', 1, 0, '2022-03-28 00:00:00', 'allat_kepek/56.jpg'),
(225, 'Anasztázia', '2018-11-02', 5, 'kan', 'Bullmasztiff', 'rossz', 1, 24, 'egészséges', 'rossz', 'nagy arany vörös kék', 'Szeret más kutyákkal játszani a kutyaparkban.', 0, 0, '2022-10-21 00:00:00', 'allat_kepek/7.jpg'),
(226, 'Sziszi', '2019-12-07', 4, 'szuka', 'Tornjak', 'rossz', 1, 23, 'foghiányos', 'rossz', 'nagy vörös rózsaszín barna', 'A családi kutyánk, Max, egy érzékeny és játékos cocker spániel, aki mindig vidámságot visz a házba.', 1, 0, '2022-05-25 00:00:00', 'allat_kepek/25.jpg'),
(227, 'Orchidea', '2018-05-07', 5, 'szuka', 'Amerikai meztelen terrier', 'rossz', 0, 6, 'foghiányos', 'rossz', 'kicsi arany sötétbarna zöld', 'Az öreg bulldog, Rocky, igazi kincs, aki mindig boldogságot hoz a házba.', 1, 0, '2022-12-27 00:00:00', 'allat_kepek/13.jpg'),
(228, 'Behemót', '2016-05-26', 7, 'kan', 'Barbet', 'egészséges', 1, 3, 'fogszuvas', 'egészséges', 'nagy sárga barna zöld', 'Az érzékeny és odaadó pitbull, Luna, a család kiskedvence, aki imádja a játékot és a simogatást.', 0, 0, '2021-12-14 00:00:00', 'allat_kepek/180.jpg'),
(229, 'Ollé', '2016-04-09', 7, 'szuka', 'Újfundlandi', 'rossz', 0, 13, 'egészséges', 'közepes', 'közepes fekete rózsaszín kék', 'A picinyke Chico nagyon aktív és energikus, mindig készen áll egy játékra vagy egy sétára.', 0, 0, '2022-03-22 00:00:00', 'allat_kepek/22.jpg'),
(230, 'Suhanc', '2020-08-18', 3, 'szuka', 'Brazil terrier', 'rossz', 1, 8, 'foghiányos', 'rossz', 'kicsi sárga sötétbarna zöld', 'A tacskó, Oscar, egy nagyon öntudatos és bátor kutya, aki ragaszkodik a szokásaihoz.', 0, 0, '2022-08-06 00:00:00', 'allat_kepek/113.jpg'),
(231, 'Maya', '2015-08-18', 8, 'kan', 'Ausztrál juhászkutya', 'egészséges', 0, 29, 'foghiányos', 'közepes', 'kicsi foltos vörös zöld', 'A border collie, Skipper, rendkívül intelligens és tanulékony, és szeret mindenféle trükköt és feladatot megoldani.', 0, 0, '2022-03-22 00:00:00', 'allat_kepek/96.jpg'),
(232, 'Limbó', '2017-03-04', 6, 'szuka', 'Gordon szetter', 'rossz', 0, 8, 'fogszuvas', 'közepes', 'közepes sárga fekete barna', 'A tacskó, Oscar, egy nagyon öntudatos és bátor kutya, aki ragaszkodik a szokásaihoz.', 0, 0, '2022-02-17 00:00:00', 'allat_kepek/142.jpg'),
(233, 'Csülök', '2015-06-05', 8, 'kan', 'Argentin dog', 'egészséges', 0, 23, 'egészséges', 'egészséges', 'közepes fehér barna barna', 'Szeret kóborolni az erdőben.', 0, 0, '2022-12-06 00:00:00', 'allat_kepek/182.jpg'),
(234, 'Jockey', '2017-02-22', 6, 'szuka', 'Artois-i kopó', 'egészséges', 0, 10, 'foghiányos', 'közepes', 'kicsi fehér vörös barna', 'Az élénk Vizsla, Daisy, mindig készen áll egy jó futásra vagy egy strandolásra.', 0, 0, '2021-10-26 00:00:00', 'allat_kepek/154.jpg'),
(235, 'Jabba', '2017-11-22', 6, 'szuka', 'Azori-szigeteki kutya', 'egészséges', 1, 3, 'egészséges', 'közepes', 'közepes foltos rózsaszín barna', 'A tacskó, Oscar, egy nagyon öntudatos és bátor kutya, aki ragaszkodik a szokásaihoz.', 1, 0, '2022-07-08 00:00:00', 'allat_kepek/23.jpg'),
(236, 'Bagira', '2017-01-13', 6, 'kan', 'Koreai jindo kutya', 'egészséges', 1, 4, 'fogszuvas', 'közepes', 'kicsi szürke fekete zöld', 'Imádja a strandot és a tengerpartot.', 1, 0, '2021-07-20 00:00:00', 'allat_kepek/56.jpg'),
(237, 'Ballu', '2017-01-01', 6, 'kan', 'Pikárdiai juhászkutya', 'egészséges', 1, 17, 'fogszuvas', 'egészséges', 'nagy barna sötétbarna kék', 'Az öreg bulldog, Rocky, igazi kincs, aki mindig boldogságot hoz a házba.', 0, 0, '2022-05-02 00:00:00', 'allat_kepek/57.jpg'),
(238, 'Orlando', '2019-09-21', 4, 'kan', 'Wolfspitz', 'egészséges', 1, 30, 'fogszuvas', 'rossz', 'nagy fekete fekete kék', 'A kis Westie, Lulu, a legaranyosabb és legkedvesebb kutyus, akivel valaha találkoztam.', 1, 0, '2022-01-25 00:00:00', 'allat_kepek/191.jpg'),
(239, 'Lassie', '2017-05-23', 6, 'szuka', 'Vadkacsavadász retriever', 'egészséges', 0, 3, 'foghiányos', 'közepes', 'nagy tigriscsíkos sötétbarna zöld', 'Szeret dörgölőzni a gazdájával és más emberekkel is.', 0, 0, '2022-09-08 00:00:00', 'allat_kepek/209.jpg'),
(240, 'Téra', '2018-06-01', 5, 'szuka', 'Amerikai akita inu', 'egészséges', 1, 21, 'fogszuvas', 'rossz', 'kicsi szürke sötétbarna barna', 'Az érzékeny és odaadó pitbull, Luna, a család kiskedvence, aki imádja a játékot és a simogatást.', 0, 0, '2021-05-06 00:00:00', 'allat_kepek/192.jpg'),
(241, 'Rinó', '2016-10-22', 7, 'szuka', 'Wetterhoun', 'egészséges', 0, 13, 'foghiányos', 'közepes', 'közepes barna vörös barna', 'Szeret játszani a gazdájával a kertben és a szobában is.', 1, 0, '2021-08-26 00:00:00', 'allat_kepek/163.jpg'),
(242, 'Jasper', '2015-01-19', 8, 'szuka', 'Welsh corgi', 'egészséges', 1, 2, 'fogszuvas', 'egészséges', 'közepes fehér fekete zöld', 'Imádja a virágokat és a leveleket rágcsálni a kertben.', 1, 0, '2022-07-02 00:00:00', 'allat_kepek/195.jpg'),
(243, 'Edith', '2020-11-09', 3, 'kan', 'Kis angol terrier', 'rossz', 0, 16, 'fogszuvas', 'rossz', 'nagy tigriscsíkos vörös barna', 'A jólelkű Goldie mindig boldoggá teszi az embereket, kedves és szeretetre méltó társ.', 0, 0, '2022-05-10 00:00:00', 'allat_kepek/164.jpg'),
(244, 'Don', '2020-09-02', 3, 'kan', 'Szamojéd', 'rossz', 1, 26, 'foghiányos', 'egészséges', 'nagy barna sötétbarna kék', 'Szeret más kutyákkal játszani a kutyaparkban.', 1, 0, '2021-10-13 00:00:00', 'allat_kepek/22.jpg'),
(245, 'Shiva', '2019-10-27', 4, 'kan', 'Orosz toy terrier', 'rossz', 0, 4, 'foghiányos', 'egészséges', 'nagy vörös barna kék', 'A csendes és kiegyensúlyozott Bernese hegyi kutya, Maxine, nagyon szeret játszani és sétálni.', 0, 0, '2021-09-19 00:00:00', 'allat_kepek/197.jpg'),
(246, 'Meggi', '2017-02-16', 6, 'kan', 'Dandie Dinmont-terrier', 'közepes', 1, 19, 'egészséges', 'egészséges', 'közepes vörös rózsaszín barna', 'A border collie, Skipper, rendkívül intelligens és tanulékony, és szeret mindenféle trükköt és feladatot megoldani.', 0, 0, '2021-01-19 00:00:00', 'allat_kepek/181.jpg'),
(247, 'Adél', '2018-06-01', 5, 'szuka', 'Bearded collie', 'rossz', 0, 30, 'fogszuvas', 'közepes', 'közepes arany barna kék', 'Imádja, amikor a gazdája a gyomrát simogatja és kedvesen beszél hozzá.', 0, 0, '2021-08-10 00:00:00', 'allat_kepek/61.jpg'),
(248, 'Rea', '2017-11-26', 6, 'kan', 'Kis angol agár', 'rossz', 0, 23, 'egészséges', 'egészséges', 'közepes vörös fekete zöld', 'Szeret kóborolni az erdőben.', 1, 0, '2022-11-24 00:00:00', 'allat_kepek/126.jpg'),
(249, 'Károly', '2018-08-27', 5, 'szuka', 'Bedlington terrier', 'egészséges', 0, 19, 'foghiányos', 'rossz', 'kicsi arany barna zöld', 'Imádja a virágokat és a leveleket rágcsálni a kertben.', 1, 0, '2021-01-11 00:00:00', 'allat_kepek/164.jpg');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `felhasznalok`
--

CREATE TABLE IF NOT EXISTS `felhasznalok` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `kert_van` varchar(10) NOT NULL,
  `add_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `bizalom_v` tinyint(1) NOT NULL DEFAULT 1,
  `admin_e` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `felhasznalok`
--

INSERT INTO `felhasznalok` (`id`, `name`, `email`, `password_hash`, `kert_van`, `add_date`, `bizalom_v`, `admin_e`) VALUES
(1, 'Szász Gergő', 'szaszgergo005@gmail.com', '$2y$10$eSEZoPSsAp14WLSl94TrAOJnC33SSuvOZJZJScWeCBYdXPSFg/S12', 'kert', '2023-04-12 16:36:30', 1, 0),
(2, 'nincskert', 'nincskert@gmail.com', '$2y$10$cmDAQ/eX9ZmbBzwzDZIgquGjFYQD.K8t4TqSWWRmYx7erhGN5dB26', 'panel', '2023-04-12 16:37:02', 1, 0),
(3, 'kert1', 'kert1@gmail.com', '$2y$10$H9za3Y3kBMQHmgmjzMUKeONLZopGUsb6u8uuUckHdJV1YIWbjye6C', 'kert', '2023-04-13 18:22:56', 1, 0),
(4, 'kert2', 'kert2@gmail.com', '$2y$10$EMKF.5gsyscqXyBG2o3DuOfyIDq1McY8wMvWDAvRIfJUghKWXn0Pa', 'kert', '2023-04-13 18:23:06', 1, 0),
(5, 'admin', 'admin@gmail.com', '$2y$10$qVgFO3VuaDuy5mWc.tqJUumt.PK3OF1X3HesZHEU6T6J.0o2tb7.S', 'kert', '2023-04-16 08:20:03', 1, 1),
(28, 'SzaszGergo', 'szaszgergo00105@gmail.com', '$2y$10$hsUB/QVcCHNDgECWopnbFeHaWMCvwaRS6B0BTYC6m.Rd23/Pjg2IO', 'kert', '2023-05-02 16:36:23', 1, 0),
(40, 'szaszgergo', 'sziauramgergo05@gmail.com', '$2y$10$cDiAi3k/0R409/Nj4AgZv.3q7lqx2y7K2wgn9pVfKFHFbEcK8HO7q', 'kert', '2023-05-02 18:46:03', 1, 0),
(44, 'szaszgergo', 'szaszgergo00005@gmail.com', '$2y$10$YEZE.sxUo.RG3JAfxln/seGnIxc6vbrzeLxkqhPpIsOvH5Th8bDEm', 'kert', '2023-05-02 19:05:04', 1, 0),
(46, 'szaszgergo', 'szaszgergo000005@gmail.com', '$2y$10$u6weJZ2s3B6dLzRcQ4vQ7OlA4UNhjbYeblIyjiKOH63udub20C3Em', 'kert', '2023-05-02 19:05:49', 1, 0),
(47, 'szaszgergo', 'gerike@gmail.com', '$2y$10$sefjg9yXTNO7j3FGSrpRNOqC1G3nwFPHx6jq14Sdgfyq07CIpNdr2', 'kert', '2023-05-02 19:49:09', 1, 0),
(78, 'sziabela', 'sziabela@gmail.com', '$2y$10$KYMbnmRexNZ3D3W.OihF6u1piMdOruuv/q60CY75IwwUIckLzfnPu', 'kert', '2023-05-03 14:00:03', 1, 0),
(79, 'aasdasd', 'admaaain@gmail.com', '$2y$10$C6D8jpkKund17haMqCZnG.DB7Xuy4zAlM6B4OmNtKxf1uha.8yDiu', 'kert', '2023-05-03 16:17:03', 1, 0);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `orokbeadott_allatok`
--

CREATE TABLE IF NOT EXISTS `orokbeadott_allatok` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(255) NOT NULL,
  `allat_id` int(255) NOT NULL,
  `be_datum` datetime NOT NULL DEFAULT current_timestamp(),
  `ki_datum` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `allat_id` (`allat_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `orokbeadott_allatok`
--

INSERT INTO `orokbeadott_allatok` (`id`, `user_id`, `allat_id`, `be_datum`, `ki_datum`, `status`) VALUES
(1, 1, 3, '2023-05-02 16:39:11', NULL, 1),
(2, 1, 5, '2023-05-02 16:45:50', NULL, 1);

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `orokbeadott_allatok`
--
ALTER TABLE `orokbeadott_allatok`
  ADD CONSTRAINT `orokbeadott_allatok_ibfk_1` FOREIGN KEY (`allat_id`) REFERENCES `allatok` (`allat_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orokbeadott_user_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `felhasznalok` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
