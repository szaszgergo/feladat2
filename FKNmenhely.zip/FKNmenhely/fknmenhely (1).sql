-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2023. Ápr 16. 16:45
-- Kiszolgáló verziója: 10.4.27-MariaDB
-- PHP verzió: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `fknmenhely`
--

DELIMITER $$
--
-- Eljárások
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_allatok` ()   SELECT * FROM allatok$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `allatok`
--

CREATE TABLE `allatok` (
  `allat_id` int(11) NOT NULL,
  `allat_nev` varchar(50) NOT NULL,
  `szul_ev` date NOT NULL,
  `becsult_kor` int(11) NOT NULL,
  `neme` varchar(255) NOT NULL DEFAULT 'kan',
  `fajta` varchar(255) NOT NULL,
  `eu_allapot` varchar(255) NOT NULL,
  `ivar_ivartalanitot` tinyint(1) NOT NULL,
  `suly` float NOT NULL,
  `fogazatt` varchar(255) NOT NULL,
  `testi_allapott` varchar(255) NOT NULL,
  `ismertetojegyek` varchar(255) NOT NULL,
  `megjegyzes` varchar(255) NOT NULL,
  `chip` tinyint(1) NOT NULL,
  `orokbeadas` tinyint(1) NOT NULL DEFAULT 0,
  `befogadas_datuma` datetime NOT NULL DEFAULT current_timestamp(),
  `img` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `allatok`
--

INSERT INTO `allatok` (`allat_id`, `allat_nev`, `szul_ev`, `becsult_kor`, `neme`, `fajta`, `eu_allapot`, `ivar_ivartalanitot`, `suly`, `fogazatt`, `testi_allapott`, `ismertetojegyek`, `megjegyzes`, `chip`, `orokbeadas`, `befogadas_datuma`, `img`) VALUES
(1, 'Pedró', '2015-03-19', 8, 'kan', 'Drever', 'közepes', 1, 23, 'fogszuvas', 'rossz', 'nagy fehér barna kék', 'szeret futkosni a kertben', 1, 1, '2022-03-22 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/22.jpg'),
(2, 'Jimmy', '2020-10-07', 3, 'szuka', 'Nagy vendée-i griffon', 'közepes', 0, 12, 'foghiányos', 'rossz', 'kicsi vörös fekete zöld', 'be van gyulladva a füle', 1, 0, '2021-02-05 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/67.jpg'),
(3, 'Amanda', '2019-08-05', 4, 'szuka', 'Eurázsiai', 'egészséges', 1, 3, 'fogszuvas', 'közepes', 'kicsi fehér sötétbarna barna', 'kedveli a sétákat', 1, 0, '2022-10-22 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/165.jpg'),
(4, 'Gopher', '2016-12-20', 7, 'szuka', 'Olasz kopó', 'egészséges', 1, 21, 'fogszuvas', 'egészséges', 'közepes sárga rózsaszín barna', 'szeret játszani a labdával', 1, 1, '2022-03-08 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/90.jpg'),
(5, 'Rolf', '2016-03-06', 7, 'kan', 'Mudi', 'közepes', 0, 8, 'fogszuvas', 'rossz', 'közepes tigriscsíkos vörös barna', 'kedveli a sétákat', 1, 0, '2022-07-14 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/76.jpg'),
(6, 'Alfonz', '2018-10-22', 5, 'szuka', 'Spanyol kopó', 'közepes', 1, 28, 'egészséges', 'egészséges', 'kicsi tigriscsíkos vörös zöld', 'szeret sétálni a parkban', 1, 1, '2021-10-19 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/151.jpg'),
(7, 'Goldy', '2018-06-26', 5, 'szuka', 'Eszkimó kutya', 'rossz', 0, 18, 'fogszuvas', 'rossz', 'kicsi vörös vörös barna', 'szeret az ablakban ülni', 1, 0, '2022-12-23 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/107.jpg'),
(8, 'Lassie', '2020-08-03', 3, 'kan', 'Karéliai medvekutya', 'rossz', 0, 22, 'foghiányos', 'közepes', 'kicsi fehér barna zöld', 'köröm vágást igényel', 1, 0, '2021-11-01 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/116.jpg'),
(9, 'Mambó', '2016-03-14', 7, 'szuka', 'Boykin spániel', 'közepes', 1, 9, 'foghiányos', 'rossz', 'közepes tigriscsíkos fekete barna', 'be van gyulladva a füle', 1, 0, '2023-06-23 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/169.jpg'),
(10, 'Rézi', '2015-03-01', 8, 'kan', 'Boykin spániel', 'rossz', 0, 4, 'foghiányos', 'közepes', 'kicsi barna barna zöld', 'szeret játszani', 1, 0, '2022-10-20 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/204.jpg'),
(11, 'Sonny', '2020-11-02', 3, 'szuka', 'Castro Laboreiro-i pásztorkutya', 'rossz', 0, 19, 'foghiányos', 'rossz', 'kicsi sárga fekete barna', 'szeret ölelni', 1, 0, '2022-10-20 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/3.jpg'),
(12, 'Kai', '2020-01-23', 3, 'szuka', 'Göndörszőrű retriever', 'rossz', 1, 17, 'egészséges', 'rossz', 'kicsi barna barna barna', 'szeret fürdeni a tóban', 1, 0, '2021-01-04 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/0.jpg'),
(13, 'Karesz', '2018-02-08', 5, 'kan', 'Chesapeake Bay retriever', 'rossz', 0, 6, 'fogszuvas', 'rossz', 'kicsi vörös sötétbarna zöld', 'bélférges', 1, 0, '2021-07-09 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/171.jpg'),
(14, 'Rézi', '2016-06-19', 7, 'kan', 'Berni pásztorkutya', 'rossz', 0, 7, 'foghiányos', 'rossz', 'közepes tigriscsíkos sötétbarna zöld', 'kedveli a sétákat', 1, 0, '2023-04-17 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/147.jpg'),
(15, 'Aramis', '2015-03-08', 8, 'szuka', 'Portugál juhászkutya', 'közepes', 0, 19, 'fogszuvas', 'rossz', 'nagy sárga sötétbarna zöld', 'bélférges', 1, 0, '2023-03-23 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/155.jpg'),
(16, 'Károly', '2016-10-17', 7, 'szuka', 'Nagy gascogne-i kék kopó', 'közepes', 0, 9, 'foghiányos', 'egészséges', 'nagy szürke fekete barna', 'be van gyulladva a füle', 1, 0, '2021-12-17 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/205.jpg'),
(17, 'Igric', '2016-08-23', 7, 'kan', 'Berni kopó', 'egészséges', 1, 17, 'egészséges', 'egészséges', 'nagy arany sötétbarna barna', 'szeret az ablakban ülni', 1, 0, '2021-06-15 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/129.jpg'),
(18, 'Ofélia', '2017-02-16', 6, 'szuka', 'Kelet-szibériai lajka', 'rossz', 0, 2, 'fogszuvas', 'egészséges', 'nagy tigriscsíkos vörös barna', 'szeret futkosni a kertben', 1, 0, '2022-04-24 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/85.jpg'),
(19, 'Edward', '2016-11-08', 7, 'kan', 'Pointer', 'egészséges', 1, 19, 'foghiányos', 'egészséges', 'nagy barna fekete barna', 'köröm vágást igényel', 1, 0, '2023-11-18 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/163.jpg'),
(20, 'Nessy', '2015-11-15', 8, 'szuka', 'Bretagne-i cserszínű basset', 'közepes', 0, 7, 'foghiányos', 'közepes', 'közepes barna barna barna', 'szeret az ablakban ülni', 1, 0, '2023-05-23 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/122.jpg'),
(21, 'Espresso', '2020-10-09', 3, 'szuka', 'Boston terrier', 'közepes', 1, 19, 'foghiányos', 'közepes', 'nagy arany rózsaszín barna', 'több mozgást igényel', 1, 0, '2023-06-20 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/42.jpg'),
(22, 'Cherie', '2017-06-12', 6, 'kan', 'Finn spicc', 'közepes', 1, 26, 'foghiányos', 'egészséges', 'nagy fehér fekete kék', 'szeret sétálni a parkban', 1, 0, '2021-10-08 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/163.jpg'),
(23, 'Furby', '2019-02-27', 4, 'szuka', 'Bichon bolognese', 'közepes', 0, 1, 'egészséges', 'közepes', 'kicsi barna barna kék', 'szeret labdázni', 1, 0, '2021-10-22 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/131.jpg'),
(24, 'Gigi', '2020-04-01', 3, 'kan', 'Foxterrier', 'rossz', 1, 14, 'fogszuvas', 'egészséges', 'nagy sárga fekete kék', 'szeret ölelni', 1, 0, '2023-11-19 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/77.jpg'),
(25, 'Bűvész', '2018-03-04', 5, 'szuka', 'Mudi', 'közepes', 1, 12, 'foghiányos', 'rossz', 'kicsi barna fekete zöld', 'bélférges', 1, 0, '2023-12-21 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/146.jpg'),
(26, 'Rea', '2020-01-16', 3, 'szuka', 'Szerb kopó', 'rossz', 1, 6, 'fogszuvas', 'rossz', 'kicsi foltos barna barna', 'bélférges', 1, 0, '2022-11-10 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/3.jpg'),
(27, 'Pepe', '2019-07-25', 4, 'szuka', 'Thai ridgeback', 'egészséges', 0, 21, 'egészséges', 'egészséges', 'nagy barna sötétbarna kék', 'több mozgást igényel', 1, 0, '2023-02-25 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/193.jpg'),
(28, 'Edith', '2018-01-20', 5, 'szuka', 'Schnauzer', 'közepes', 0, 24, 'egészséges', 'rossz', 'közepes foltos vörös barna', 'több mozgást igényel', 1, 0, '2022-01-06 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/207.jpg'),
(29, 'Csibész', '2018-07-09', 5, 'kan', 'Basenji', 'közepes', 1, 8, 'fogszuvas', 'rossz', 'nagy barna fekete kék', 'bélférges', 1, 0, '2021-02-21 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/0.jpg'),
(30, 'Gróf', '2018-12-05', 5, 'szuka', 'Telomian', 'rossz', 1, 17, 'fogszuvas', 'egészséges', 'nagy vörös vörös barna', 'szeret sétálni a parkban', 1, 0, '2023-11-11 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/104.jpg'),
(31, 'Stella', '2016-08-09', 7, 'szuka', 'Máltai selyemkutya', 'rossz', 0, 23, 'egészséges', 'rossz', 'nagy sárga sötétbarna zöld', 'szeret fürdeni a tóban', 1, 0, '2022-09-17 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/204.jpg'),
(32, 'Morti', '2017-11-22', 6, 'szuka', 'Angol agár', 'rossz', 1, 19, 'egészséges', 'közepes', 'kicsi arany fekete barna', 'szeret úszni', 1, 0, '2023-02-18 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/194.jpg'),
(33, 'Pepe', '2018-02-12', 5, 'szuka', 'Cimarrón Uruguayo', 'egészséges', 0, 18, 'fogszuvas', 'közepes', 'nagy tigriscsíkos barna barna', 'szeret úszni', 1, 0, '2021-09-18 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/187.jpg'),
(34, 'Maya', '2020-12-15', 3, 'szuka', 'Carolina kutya', 'rossz', 1, 26, 'foghiányos', 'közepes', 'közepes tigriscsíkos fekete kék', 'kedveli a sétákat', 1, 0, '2022-04-24 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/181.jpg'),
(35, 'Pufók', '2020-01-26', 3, 'kan', 'Saage kochee', 'közepes', 0, 6, 'egészséges', 'közepes', 'nagy fehér sötétbarna barna', 'szeret nyugodtan pihenni', 1, 0, '2023-03-18 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/135.jpg'),
(36, 'Inzy', '2020-08-18', 3, 'szuka', 'Bullterrier', 'közepes', 1, 25, 'egészséges', 'rossz', 'közepes sárga rózsaszín kék', 'szeret játszani', 1, 0, '2023-04-17 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/183.jpg'),
(37, 'Gerry', '2015-04-16', 8, 'szuka', 'Isztriai kopó', 'egészséges', 1, 1, 'foghiányos', 'közepes', 'nagy barna fekete barna', 'szeret játszani', 1, 0, '2023-09-02 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/26.jpg'),
(38, 'Killer', '2020-07-19', 3, 'kan', 'Ír farkaskutya', 'rossz', 1, 12, 'fogszuvas', 'közepes', 'nagy foltos rózsaszín barna', 'szeret játszani', 1, 0, '2023-02-19 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/160.jpg'),
(39, 'Mancs', '2019-07-20', 4, 'kan', 'Német dog', 'egészséges', 1, 2, 'fogszuvas', 'rossz', 'kicsi barna vörös zöld', 'kedveli a sétákat', 1, 0, '2023-06-08 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/53.jpg'),
(40, 'Gandhi', '2019-08-13', 4, 'szuka', 'Fekete-cser mosómedvekopó', 'rossz', 1, 4, 'fogszuvas', 'rossz', 'közepes tigriscsíkos barna barna', 'szeret nyugodtan pihenni', 1, 0, '2022-07-05 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/169.jpg'),
(41, 'Pitti', '2015-11-25', 8, 'szuka', 'Cardigan welsh corgi', 'egészséges', 0, 15, 'fogszuvas', 'egészséges', 'közepes barna vörös kék', 'szeret nyugodtan pihenni', 1, 0, '2023-11-28 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/138.jpg'),
(42, 'Bohém', '2020-10-12', 3, 'szuka', 'Pudelpointer', 'közepes', 1, 16, 'fogszuvas', 'egészséges', 'közepes sárga vörös barna', 'szeret játszani', 1, 0, '2021-08-12 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/173.jpg'),
(43, 'Polli', '2017-02-18', 6, 'szuka', 'Nagy vendée-i griffon', 'közepes', 0, 16, 'fogszuvas', 'közepes', 'közepes szürke vörös zöld', 'szeret fürdeni a tóban', 1, 0, '2021-04-28 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/113.jpg'),
(44, 'Axel', '2016-02-19', 7, 'kan', 'Német juhászkutya', 'közepes', 0, 10, 'egészséges', 'rossz', 'kicsi sárga sötétbarna zöld', 'be van gyulladva a füle', 1, 0, '2021-01-23 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/66.jpg'),
(45, 'Csöpi', '2015-11-03', 8, 'szuka', 'Drever', 'egészséges', 0, 23, 'foghiányos', 'rossz', 'közepes fekete rózsaszín zöld', 'szeret nyugodtan pihenni', 1, 0, '2021-06-07 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/144.jpg'),
(46, 'Adél', '2017-04-22', 6, 'kan', 'Schiller-kopó', 'közepes', 1, 28, 'fogszuvas', 'egészséges', 'közepes foltos rózsaszín kék', 'szeret játszani', 1, 0, '2022-05-02 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/172.jpg'),
(47, 'Zola', '2016-04-14', 7, 'kan', 'Rövidszőrű isztriai kopó', 'közepes', 1, 15, 'egészséges', 'rossz', 'közepes fekete barna kék', 'szeret az ablakban ülni', 1, 0, '2021-10-04 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/18.jpg'),
(48, 'Bözsi', '2019-11-13', 4, 'kan', 'Fehérorosz juhászkutya vagy kelet-európai juhászkutya', 'közepes', 0, 10, 'fogszuvas', 'közepes', 'kicsi arany vörös kék', 'szeret kutyakölykökkel játszani', 1, 0, '2023-05-11 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/72.jpg'),
(49, 'Okonor', '2020-12-20', 3, 'kan', 'Longdog', 'egészséges', 1, 16, 'fogszuvas', 'rossz', 'nagy sárga vörös barna', 'kedves és barátságos', 1, 0, '2022-11-04 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/92.jpg'),
(50, 'Azték', '2018-02-07', 5, 'szuka', 'Bali hegyikutya', 'rossz', 0, 26, 'foghiányos', 'egészséges', 'kicsi szürke sötétbarna kék', 'szeret labdázni', 1, 0, '2022-06-17 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/94.jpg'),
(51, 'Pénzecske', '2020-02-17', 3, 'kan', 'Olasz agár', 'egészséges', 1, 5, 'fogszuvas', 'közepes', 'nagy foltos barna barna', 'szeret ölelni', 1, 0, '2023-02-27 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/155.jpg'),
(52, 'Bohém', '2015-06-21', 8, 'kan', 'Norfolk terrier', 'rossz', 1, 6, 'foghiányos', 'rossz', 'nagy arany vörös kék', 'szeret játszani', 1, 0, '2022-03-04 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/81.jpg'),
(53, 'Gandhi', '2016-08-12', 7, 'szuka', 'Ausztrál kelpie', 'rossz', 0, 5, 'fogszuvas', 'közepes', 'közepes fehér sötétbarna zöld', 'szeret labdázni', 1, 0, '2023-06-21 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/12.jpg'),
(54, 'Rézi', '2019-01-20', 4, 'szuka', 'Halden kopó', 'rossz', 0, 2, 'fogszuvas', 'közepes', 'közepes foltos rózsaszín barna', 'szeret ölelni', 1, 0, '2021-10-11 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/2.jpg'),
(55, 'Keisha', '2017-06-18', 6, 'szuka', 'Vizsla', 'egészséges', 1, 2, 'foghiányos', 'egészséges', 'nagy foltos barna barna', 'szeret labdázni', 1, 0, '2023-02-01 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/202.jpg'),
(56, 'Lewis', '2016-11-23', 7, 'szuka', 'Ausztrál selyemszőrű terrier', 'közepes', 1, 2, 'egészséges', 'rossz', 'közepes foltos sötétbarna kék', 'szeret kutyakölykökkel játszani', 1, 0, '2021-09-06 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/34.jpg'),
(57, 'Hasszán', '2015-03-23', 8, 'kan', 'Német spicc', 'rossz', 0, 19, 'fogszuvas', 'közepes', 'nagy vörös sötétbarna barna', 'kedveli a sétákat', 1, 0, '2022-01-27 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/35.jpg'),
(58, 'Gopher', '2017-09-25', 6, 'kan', 'Magyar vizsla', 'rossz', 1, 13, 'egészséges', 'egészséges', 'nagy barna rózsaszín kék', 'imád aludni', 1, 0, '2023-09-01 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/204.jpg'),
(59, 'Smokie', '2020-09-10', 3, 'szuka', 'Belga juhászkutya', 'rossz', 0, 14, 'fogszuvas', 'egészséges', 'közepes tigriscsíkos rózsaszín zöld', 'szeret futkosni a kertben', 1, 0, '2022-06-03 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/166.jpg'),
(60, 'Elvis', '2019-11-24', 4, 'kan', 'Perzsa agár', 'rossz', 1, 6, 'egészséges', 'egészséges', 'nagy barna barna kék', 'köröm vágást igényel', 1, 0, '2022-03-14 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/174.jpg'),
(61, 'Pufók', '2018-09-21', 5, 'kan', 'Thai ridgeback', 'közepes', 1, 2, 'fogszuvas', 'egészséges', 'közepes szürke vörös kék', 'szeret nyugodtan pihenni', 1, 0, '2023-02-05 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/148.jpg'),
(62, 'FuFu', '2019-02-20', 4, 'kan', 'Francia vizsla', 'közepes', 0, 27, 'foghiányos', 'közepes', 'közepes foltos vörös barna', 'szeret kutyakölykökkel játszani', 1, 0, '2023-02-15 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/57.jpg'),
(63, 'Shiva', '2020-04-14', 3, 'szuka', 'Német pinscher', 'egészséges', 1, 6, 'foghiányos', 'közepes', 'közepes fehér sötétbarna zöld', 'kedveli a sétákat', 1, 0, '2021-05-25 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/154.jpg'),
(64, 'Rénó', '2019-09-21', 4, 'szuka', 'Csehszlovák farkaskutya', 'rossz', 1, 11, 'egészséges', 'közepes', 'közepes fekete sötétbarna kék', 'szeret úszni', 1, 0, '2023-12-10 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/21.jpg'),
(65, 'Goldy', '2017-04-16', 6, 'szuka', 'Nagy gascogne-i kék kopó', 'közepes', 1, 25, 'fogszuvas', 'közepes', 'közepes fekete barna kék', 'imád aludni', 1, 0, '2021-06-21 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/60.jpg'),
(66, 'Sakál', '2015-02-26', 8, 'kan', 'Kis gascon-saintonge-i kopó', 'rossz', 0, 5, 'foghiányos', 'egészséges', 'közepes tigriscsíkos barna zöld', 'be van gyulladva a füle', 1, 0, '2023-01-03 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/1.jpg'),
(67, 'Viti', '2015-12-06', 8, 'kan', 'Rampur agár', 'rossz', 1, 21, 'fogszuvas', 'rossz', 'kicsi vörös vörös zöld', 'szeret labdázni', 1, 0, '2023-04-05 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/191.jpg'),
(68, 'Gandhi', '2018-10-01', 5, 'kan', 'Kis gascon-saintonge-i kopó', 'egészséges', 0, 27, 'foghiányos', 'egészséges', 'kicsi barna barna zöld', 'kedveli a sétákat', 1, 0, '2023-02-18 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/93.jpg'),
(69, 'Adolf', '2015-12-06', 8, 'szuka', 'Saarloosi farkaskutya', 'rossz', 0, 10, 'fogszuvas', 'rossz', 'nagy fehér rózsaszín zöld', 'kedves és barátságos', 1, 0, '2022-07-18 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/66.jpg'),
(70, 'Morti', '2017-04-01', 6, 'kan', 'Field spániel', 'közepes', 1, 17, 'fogszuvas', 'egészséges', 'közepes sárga rózsaszín barna', 'szeret játszani', 1, 0, '2022-08-17 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/159.jpg'),
(71, 'Peggi', '2018-03-06', 5, 'szuka', 'Ausztrál csonkafarkú pásztorkutya', 'közepes', 1, 29, 'fogszuvas', 'egészséges', 'nagy barna fekete kék', 'szeret futkosni a kertben', 1, 0, '2021-09-10 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/35.jpg'),
(72, 'Lucy', '2015-06-19', 8, 'szuka', 'Alaszkai malamut', 'egészséges', 1, 11, 'foghiányos', 'közepes', 'közepes arany rózsaszín zöld', 'köröm vágást igényel', 1, 0, '2021-08-21 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/90.jpg'),
(73, 'Teddy', '2016-12-19', 7, 'kan', 'Ausztrál terrier', 'egészséges', 1, 4, 'foghiányos', 'közepes', 'kicsi vörös barna kék', 'imád aludni', 1, 0, '2021-05-28 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/96.jpg'),
(74, 'Meggi', '2019-02-01', 4, 'kan', 'Azawakh', 'közepes', 0, 1, 'fogszuvas', 'egészséges', 'közepes barna rózsaszín zöld', 'szeret ölelni', 1, 0, '2021-10-05 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/127.jpg'),
(75, 'Axel', '2016-07-18', 7, 'kan', 'Mudhol Hound', 'rossz', 0, 4, 'foghiányos', 'egészséges', 'kicsi vörös fekete barna', 'kedveli a sétákat', 1, 0, '2022-08-12 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/16.jpg'),
(76, 'Bugatti', '2016-06-24', 7, 'szuka', 'Schwyzi kopó', 'egészséges', 1, 18, 'fogszuvas', 'egészséges', 'kicsi szürke fekete kék', 'imád aludni', 1, 0, '2021-09-02 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/204.jpg'),
(77, 'Kuku', '2018-09-20', 5, 'szuka', 'Angol mosómedvekopó', 'közepes', 1, 27, 'foghiányos', 'egészséges', 'nagy foltos vörös zöld', 'szeret az ablakban ülni', 1, 0, '2023-05-01 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/26.jpg'),
(78, 'Jasper', '2018-08-04', 5, 'kan', 'Katalán pásztorkutya', 'közepes', 0, 17, 'foghiányos', 'közepes', 'nagy szürke vörös barna', 'szeret sétálni a parkban', 1, 0, '2022-04-02 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/115.jpg'),
(79, 'Pajtás', '2018-05-12', 5, 'kan', 'Drótszőrű magyar vizsla', 'közepes', 0, 30, 'fogszuvas', 'egészséges', 'közepes fehér barna barna', 'bélférges', 1, 0, '2021-10-13 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/94.jpg'),
(80, 'Szeszi', '2015-03-19', 8, 'kan', 'Sibaken', 'közepes', 1, 3, 'egészséges', 'közepes', 'kicsi fehér sötétbarna zöld', 'köröm vágást igényel', 1, 0, '2021-11-22 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/81.jpg'),
(81, 'Milli', '2016-12-11', 7, 'kan', 'Rottweiler', 'egészséges', 1, 9, 'egészséges', 'közepes', 'kicsi barna vörös zöld', 'szeret labdázni', 1, 0, '2021-01-03 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/0.jpg'),
(82, 'Jázmina', '2018-04-16', 5, 'kan', 'Amerikai eszkimó kutya', 'egészséges', 0, 22, 'egészséges', 'egészséges', 'közepes szürke sötétbarna zöld', 'szeret kutyakölykökkel játszani', 1, 0, '2021-05-05 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/65.jpg'),
(83, 'Jasper', '2019-08-23', 4, 'kan', 'Nápolyi masztiff', 'rossz', 1, 5, 'egészséges', 'egészséges', 'kicsi sárga sötétbarna barna', 'imád aludni', 1, 0, '2021-09-18 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/192.jpg'),
(84, 'Rex', '2019-05-25', 4, 'szuka', 'Bajor hegyi véreb', 'közepes', 1, 26, 'egészséges', 'egészséges', 'közepes fehér sötétbarna kék', 'szeret nyugodtan pihenni', 1, 0, '2022-05-27 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/108.jpg'),
(85, 'Illés', '2016-12-18', 7, 'kan', 'Német pinscher', 'egészséges', 1, 20, 'foghiányos', 'egészséges', 'közepes arany vörös zöld', 'szeret játszani', 1, 0, '2022-02-12 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/109.jpg'),
(86, 'Luigi', '2015-12-16', 8, 'kan', 'Kanári-szigeteki kopó', 'egészséges', 1, 10, 'egészséges', 'rossz', 'kicsi vörös barna kék', 'szeret kutyakölykökkel játszani', 1, 0, '2021-11-15 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/101.jpg'),
(87, 'Maggie', '2018-06-24', 5, 'szuka', 'Welsh terrier', 'közepes', 0, 4, 'egészséges', 'rossz', 'kicsi szürke fekete zöld', 'bélférges', 1, 0, '2021-08-18 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/173.jpg'),
(88, 'Kuku', '2018-09-02', 5, 'szuka', 'Husky', 'rossz', 0, 16, 'foghiányos', 'közepes', 'nagy foltos barna kék', 'kedveli a sétákat', 1, 0, '2022-07-21 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/20.jpg'),
(89, 'Gadget', '2017-08-15', 6, 'kan', 'Szlovák csuvacs', 'közepes', 1, 25, 'foghiányos', 'rossz', 'nagy sárga sötétbarna barna', 'szeret fürdeni a tóban', 1, 0, '2022-12-24 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/9.jpg'),
(90, 'Amaya', '2015-07-05', 8, 'kan', 'Skye terrier', 'közepes', 1, 20, 'foghiányos', 'rossz', 'közepes sárga fekete kék', 'szeret fürdeni a tóban', 1, 0, '2021-04-10 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/132.jpg'),
(91, 'Kelly', '2017-10-05', 6, 'kan', 'Német vizsla', 'közepes', 0, 2, 'egészséges', 'egészséges', 'közepes tigriscsíkos rózsaszín barna', 'szeret játszani', 1, 0, '2022-02-26 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/85.jpg'),
(92, 'Fifi', '2016-07-20', 7, 'szuka', 'Drótszőrű foxterrier', 'egészséges', 1, 14, 'foghiányos', 'egészséges', 'nagy szürke fekete zöld', 'imád aludni', 1, 0, '2022-09-23 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/41.jpg'),
(93, 'Bella', '2015-03-06', 8, 'kan', 'Lhasa apso', 'közepes', 1, 27, 'fogszuvas', 'közepes', 'közepes foltos vörös kék', 'szeret kutyakölykökkel játszani', 1, 0, '2023-10-13 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/144.jpg'),
(94, 'Szultán', '2019-02-18', 4, 'kan', 'Sinka', 'egészséges', 0, 5, 'fogszuvas', 'közepes', 'kicsi tigriscsíkos fekete barna', 'kedveli a sétákat', 1, 0, '2022-06-19 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/92.jpg'),
(95, 'Destiny', '2015-12-14', 8, 'kan', 'Kanári-szigeteki kutya', 'rossz', 1, 14, 'fogszuvas', 'egészséges', 'nagy sárga sötétbarna kék', 'több mozgást igényel', 1, 0, '2021-05-12 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/79.jpg'),
(96, 'Rüszi', '2017-04-22', 6, 'kan', 'Berni pásztorkutya', 'rossz', 0, 22, 'fogszuvas', 'egészséges', 'kicsi szürke fekete zöld', 'kedves és barátságos', 1, 0, '2022-04-10 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/148.jpg'),
(97, 'Lexi', '2018-11-22', 5, 'kan', 'Simaszőrű foxterrier', 'egészséges', 0, 25, 'fogszuvas', 'közepes', 'közepes tigriscsíkos rózsaszín zöld', 'szeret az ablakban ülni', 1, 0, '2023-03-07 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/62.jpg'),
(98, 'Zafír', '2018-12-22', 5, 'szuka', 'Malinois', 'egészséges', 1, 29, 'egészséges', 'rossz', 'közepes sárga vörös zöld', 'szeret az ablakban ülni', 1, 0, '2022-09-12 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/82.jpg'),
(99, 'Pamacs', '2020-12-06', 3, 'kan', 'Kalag Tazi', 'közepes', 0, 25, 'foghiányos', 'rossz', 'nagy vörös fekete kék', 'szeret fürdeni a tóban', 1, 0, '2022-05-03 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/127.jpg'),
(100, 'Luigi', '2018-06-11', 5, 'kan', 'Glen of Imaal terrier', 'közepes', 1, 27, 'foghiányos', 'rossz', 'kicsi arany fekete barna', 'szeret az ablakban ülni', 1, 0, '2022-02-01 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/120.jpg'),
(101, 'Sátán', '2020-11-17', 3, 'kan', 'Jämthund', 'rossz', 1, 24, 'fogszuvas', 'rossz', 'kicsi fehér vörös kék', 'szeret játszani', 1, 0, '2023-01-16 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/106.jpg'),
(102, 'Ördög', '2015-12-03', 8, 'kan', 'Tibeti spániel', 'rossz', 0, 10, 'foghiányos', 'rossz', 'közepes tigriscsíkos rózsaszín zöld', 'be van gyulladva a füle', 1, 0, '2021-04-20 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/115.jpg'),
(103, 'Kaarjack', '2016-12-22', 7, 'kan', 'Pont-Audemer-i spániel', 'egészséges', 0, 26, 'foghiányos', 'rossz', 'közepes vörös vörös kék', 'szeret futkosni a kertben', 1, 0, '2021-05-25 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/39.jpg'),
(104, 'Neutron', '2015-06-12', 8, 'kan', 'Kanadai eszkimó kutya', 'egészséges', 0, 3, 'foghiányos', 'közepes', 'kicsi barna rózsaszín zöld', 'szeret úszni', 1, 0, '2022-02-19 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/38.jpg'),
(105, 'Melák', '2019-03-12', 4, 'szuka', 'Vesztfáliai tacskókopó', 'közepes', 1, 22, 'fogszuvas', 'egészséges', 'kicsi fehér vörös barna', 'imád aludni', 1, 0, '2023-06-20 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/119.jpg'),
(106, 'Frakk', '2018-07-25', 5, 'szuka', 'Akita inu', 'rossz', 1, 13, 'fogszuvas', 'közepes', 'nagy foltos rózsaszín barna', 'szeret úszni', 1, 0, '2023-05-05 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/166.jpg'),
(107, 'Polli', '2016-02-13', 7, 'szuka', 'Finn spicc', 'egészséges', 0, 7, 'foghiányos', 'közepes', 'közepes tigriscsíkos rózsaszín kék', 'szeret kutyakölykökkel játszani', 1, 0, '2021-07-28 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/155.jpg'),
(108, 'Nyikita', '2020-07-28', 3, 'szuka', 'Shikoku inu', 'egészséges', 0, 26, 'foghiányos', 'közepes', 'kicsi barna barna barna', 'több mozgást igényel', 1, 0, '2023-01-05 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/109.jpg'),
(109, 'Szofi', '2019-08-11', 4, 'kan', 'Német vadászterrier', 'közepes', 0, 19, 'fogszuvas', 'egészséges', 'kicsi arany barna barna', 'szeret játszani', 1, 0, '2021-06-14 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/138.jpg'),
(110, 'Bella', '2018-02-26', 5, 'szuka', 'Alaszkai malamut', 'egészséges', 1, 14, 'foghiányos', 'rossz', 'kicsi tigriscsíkos rózsaszín kék', 'szeret játszani', 1, 0, '2023-12-18 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/142.jpg'),
(111, 'Frida', '2020-10-28', 3, 'kan', 'Cimarrón Uruguayo', 'egészséges', 0, 29, 'fogszuvas', 'egészséges', 'nagy arany fekete zöld', 'szeret nyugodtan pihenni', 1, 0, '2022-02-17 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/160.jpg'),
(112, 'Glédis', '2016-07-14', 7, 'kan', 'Lakeland terrier', 'rossz', 0, 29, 'fogszuvas', 'egészséges', 'kicsi fehér rózsaszín kék', 'imád aludni', 1, 0, '2022-12-01 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/192.jpg'),
(113, 'Jumbó', '2019-01-07', 4, 'kan', 'Artois-i kopó', 'egészséges', 1, 25, 'egészséges', 'közepes', 'nagy arany sötétbarna kék', 'szeret játszani a labdával', 1, 0, '2023-09-17 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/76.jpg'),
(114, 'Kai', '2016-12-01', 7, 'kan', 'Eurázsiai', 'rossz', 0, 5, 'foghiányos', 'rossz', 'közepes barna sötétbarna barna', 'bélférges', 1, 0, '2022-10-13 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/175.jpg'),
(115, 'Tekergő', '2020-12-12', 3, 'szuka', 'Bernáthegyi', 'egészséges', 1, 15, 'egészséges', 'közepes', 'nagy szürke fekete zöld', 'több mozgást igényel', 1, 0, '2022-03-15 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/154.jpg'),
(116, 'Goldy', '2020-05-15', 3, 'kan', 'Skye terrier', 'egészséges', 1, 25, 'foghiányos', 'egészséges', 'kicsi barna vörös kék', 'szeret kutyakölykökkel játszani', 1, 0, '2022-12-24 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/167.jpg'),
(117, 'Bajnok', '2018-10-09', 5, 'kan', 'Göndörszőrű retriever', 'egészséges', 0, 22, 'fogszuvas', 'közepes', 'közepes fekete sötétbarna zöld', 'szeret játszani', 1, 0, '2023-12-28 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/37.jpg'),
(118, 'Terry', '2020-12-23', 3, 'szuka', 'Ónémet juhászkutya', 'rossz', 1, 20, 'foghiányos', 'közepes', 'nagy vörös sötétbarna zöld', 'szeret úszni', 1, 0, '2023-07-28 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/132.jpg'),
(119, 'Apolló', '2017-06-17', 6, 'szuka', 'Vörös-fehér ír szetter', 'egészséges', 0, 2, 'fogszuvas', 'közepes', 'közepes sárga barna zöld', 'imád aludni', 1, 0, '2021-06-11 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/64.jpg'),
(120, 'Szeszi', '2016-06-03', 7, 'szuka', 'Szlovák kopó', 'egészséges', 0, 6, 'foghiányos', 'közepes', 'nagy arany vörös kék', 'kedveli a sétákat', 1, 0, '2022-03-09 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/193.jpg'),
(121, 'Melák', '2017-04-12', 6, 'szuka', 'Kanni', 'egészséges', 0, 16, 'foghiányos', 'rossz', 'kicsi foltos fekete barna', 'szeret úszni', 1, 0, '2022-11-22 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/66.jpg'),
(122, 'Maggie', '2016-07-04', 7, 'kan', 'Olasz kopó', 'egészséges', 0, 23, 'fogszuvas', 'közepes', 'közepes arany sötétbarna kék', 'be van gyulladva a füle', 1, 0, '2021-10-17 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/194.jpg'),
(123, 'Iván', '2015-09-18', 8, 'szuka', 'Vendée-i griffon basset', 'egészséges', 0, 18, 'foghiányos', 'közepes', 'nagy szürke barna zöld', 'szeret sétálni a parkban', 1, 0, '2023-02-12 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/126.jpg'),
(124, 'Vénusz', '2017-10-24', 6, 'szuka', 'Vizsla', 'közepes', 0, 10, 'egészséges', 'közepes', 'nagy tigriscsíkos vörös barna', 'bélférges', 1, 0, '2021-03-19 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/55.jpg'),
(125, 'Glédis', '2015-05-10', 8, 'szuka', 'Olasz volpino', 'egészséges', 0, 15, 'egészséges', 'közepes', 'közepes foltos sötétbarna zöld', 'szeret nyugodtan pihenni', 1, 0, '2022-11-26 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/74.jpg'),
(126, 'Nimród', '2017-09-23', 6, 'kan', 'Brie-i juhászkutya', 'rossz', 0, 10, 'egészséges', 'rossz', 'kicsi fehér rózsaszín kék', 'kedves és barátságos', 1, 0, '2023-02-13 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/152.jpg'),
(127, 'Bogáncs', '2016-09-02', 7, 'kan', 'Brie-i juhászkutya', 'rossz', 1, 6, 'fogszuvas', 'rossz', 'kicsi arany fekete zöld', 'több mozgást igényel', 1, 0, '2021-07-14 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/14.jpg'),
(128, 'Bohém', '2017-10-02', 6, 'szuka', 'Armant', 'egészséges', 0, 13, 'fogszuvas', 'egészséges', 'kicsi foltos fekete barna', 'szeret az ablakban ülni', 1, 0, '2021-05-11 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/96.jpg'),
(129, 'Zafír', '2019-07-08', 4, 'szuka', 'Flandriai pásztorkutya', 'közepes', 1, 26, 'fogszuvas', 'közepes', 'közepes vörös barna zöld', 'köröm vágást igényel', 1, 0, '2023-05-10 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/203.jpg'),
(130, 'Vitéz', '2020-01-13', 3, 'szuka', 'Kishu ken', 'rossz', 0, 24, 'foghiányos', 'rossz', 'közepes barna fekete kék', 'kedveli a sétákat', 1, 0, '2023-01-01 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/19.jpg'),
(131, 'Jasper', '2018-04-26', 5, 'szuka', 'Lengyel alföldi juhászkutya', 'egészséges', 1, 29, 'fogszuvas', 'egészséges', 'kicsi arany sötétbarna barna', 'kedves és barátságos', 1, 0, '2022-09-22 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/200.jpg'),
(132, 'Neutron', '2017-01-21', 6, 'kan', 'Whippet', 'egészséges', 1, 8, 'egészséges', 'egészséges', 'nagy fehér rózsaszín kék', 'köröm vágást igényel', 1, 0, '2022-06-17 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/45.jpg'),
(133, 'Vénusz', '2020-04-26', 3, 'szuka', 'Kanári-szigeteki kutya', 'egészséges', 1, 25, 'egészséges', 'egészséges', 'kicsi vörös sötétbarna kék', 'szeret labdázni', 1, 0, '2021-08-14 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/162.jpg'),
(134, 'Pandúr', '2019-12-26', 4, 'szuka', 'Moszkvai hosszú szőrű toy terrier', 'közepes', 1, 21, 'fogszuvas', 'közepes', 'nagy foltos barna barna', 'szeret játszani a labdával', 1, 0, '2022-08-24 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/106.jpg'),
(135, 'Nyikita', '2020-05-01', 3, 'szuka', 'Boston terrier', 'egészséges', 1, 7, 'fogszuvas', 'egészséges', 'közepes fekete sötétbarna barna', 'szeret játszani a labdával', 1, 0, '2021-05-19 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/207.jpg'),
(136, 'Gigi', '2015-11-15', 8, 'szuka', 'Bullmasztiff', 'közepes', 1, 22, 'foghiányos', 'közepes', 'közepes arany sötétbarna barna', 'szeret játszani', 1, 0, '2021-06-05 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/57.jpg'),
(137, 'Bessz', '2016-12-25', 7, 'szuka', 'Kis angol agár', 'egészséges', 1, 6, 'egészséges', 'rossz', 'közepes foltos rózsaszín kék', 'több mozgást igényel', 1, 0, '2021-11-07 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/26.jpg'),
(138, 'Bogáncs', '2017-08-02', 6, 'kan', 'Vesztfáliai tacskókopó', 'egészséges', 1, 4, 'egészséges', 'rossz', 'nagy tigriscsíkos fekete kék', 'köröm vágást igényel', 1, 0, '2023-09-09 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/202.jpg'),
(139, 'Cherie', '2018-08-08', 5, 'szuka', 'Portugál vízikutya', 'egészséges', 1, 4, 'foghiányos', 'közepes', 'nagy foltos barna zöld', 'szeret futkosni a kertben', 1, 0, '2022-06-06 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/208.jpg'),
(140, 'Stuki', '2020-07-24', 3, 'szuka', 'Francia bulldog', 'egészséges', 1, 18, 'foghiányos', 'egészséges', 'nagy barna barna kék', 'szeret futkosni a kertben', 1, 0, '2021-12-20 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/30.jpg'),
(141, 'Cadbury', '2015-04-06', 8, 'kan', 'Beagle', 'rossz', 1, 13, 'fogszuvas', 'rossz', 'közepes fehér fekete barna', 'szeret ölelni', 1, 0, '2023-06-14 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/191.jpg'),
(142, 'Shiva', '2017-04-22', 6, 'kan', 'Tibeti terrier', 'rossz', 0, 26, 'egészséges', 'közepes', 'kicsi szürke vörös barna', 'szeret játszani a labdával', 1, 0, '2021-02-24 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/89.jpg'),
(143, 'Ursula', '2016-05-10', 7, 'szuka', 'Rouilers-i pászorkutya', 'egészséges', 1, 20, 'foghiányos', 'egészséges', 'közepes tigriscsíkos fekete kék', 'szeret úszni', 1, 0, '2023-04-21 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/158.jpg'),
(144, 'Léda', '2017-06-24', 6, 'kan', 'Német kopó', 'rossz', 1, 26, 'egészséges', 'közepes', 'kicsi szürke rózsaszín barna', 'több mozgást igényel', 1, 0, '2022-10-19 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/116.jpg'),
(145, 'Napóleon', '2020-11-24', 3, 'kan', 'Halden kopó', 'rossz', 0, 7, 'fogszuvas', 'rossz', 'kicsi foltos vörös zöld', 'szeret úszni', 1, 0, '2023-01-26 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/72.jpg'),
(146, 'Kefir', '2015-03-20', 8, 'kan', 'Gascogne-i kék griffon', 'rossz', 0, 11, 'foghiányos', 'közepes', 'nagy szürke vörös zöld', 'szeret labdázni', 1, 0, '2023-01-04 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/95.jpg'),
(147, 'Szeszi', '2019-12-11', 4, 'kan', 'Wolfspitz', 'egészséges', 0, 2, 'egészséges', 'rossz', 'közepes barna barna barna', 'kedves és barátságos', 1, 0, '2022-06-23 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/146.jpg'),
(148, 'Elíz', '2018-03-07', 5, 'szuka', 'Olasz kopó', 'közepes', 1, 25, 'egészséges', 'rossz', 'kicsi fekete vörös zöld', 'szeret úszni', 1, 0, '2022-12-22 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/6.jpg'),
(149, 'Narancs', '2020-03-03', 3, 'kan', 'Nagyspitz', 'egészséges', 1, 8, 'foghiányos', 'egészséges', 'nagy tigriscsíkos vörös kék', 'szeret ölelni', 1, 0, '2022-12-27 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/150.jpg'),
(150, 'Zeusz', '2016-11-03', 7, 'kan', 'Vörös ír szetter', 'közepes', 1, 1, 'foghiányos', 'közepes', 'nagy szürke rózsaszín zöld', 'szeret kutyakölykökkel játszani', 1, 0, '2022-12-19 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/196.jpg'),
(151, 'Wolf', '2017-09-26', 6, 'szuka', 'Angol rókakopó', 'egészséges', 1, 28, 'egészséges', 'egészséges', 'nagy barna rózsaszín zöld', 'szeret labdázni', 1, 0, '2022-03-27 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/145.jpg'),
(152, 'Suzy', '2015-04-11', 8, 'szuka', 'Pikárdiai kék spániel', 'közepes', 1, 29, 'foghiányos', 'rossz', 'nagy fehér sötétbarna zöld', 'szeret úszni', 1, 0, '2021-04-24 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/32.jpg'),
(153, 'Bűvész', '2018-09-21', 5, 'kan', 'Francia spániel', 'rossz', 0, 21, 'foghiányos', 'közepes', 'kicsi tigriscsíkos fekete zöld', 'szeret labdázni', 1, 0, '2023-12-18 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/204.jpg'),
(154, 'Fabula', '2018-10-19', 5, 'kan', 'Savoye-i pásztorkutya', 'közepes', 1, 24, 'egészséges', 'rossz', 'nagy tigriscsíkos rózsaszín barna', 'szeret játszani', 1, 0, '2023-02-26 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/152.jpg'),
(155, 'Pandúr', '2016-11-17', 7, 'szuka', 'Dán-svéd őrkutya', 'közepes', 1, 11, 'egészséges', 'rossz', 'nagy arany vörös kék', 'szeret ölelni', 1, 0, '2021-04-17 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/16.jpg'),
(156, 'Leila', '2017-12-16', 6, 'kan', 'Kooikerhondje', 'rossz', 0, 24, 'fogszuvas', 'közepes', 'közepes vörös vörös barna', 'szeret kutyakölykökkel játszani', 1, 0, '2021-03-13 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/0.jpg'),
(157, 'Bajnok', '2016-10-04', 7, 'szuka', 'Kis oroszlánkutya', 'egészséges', 0, 15, 'foghiányos', 'közepes', 'nagy sárga fekete barna', 'bélférges', 1, 0, '2021-03-02 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/42.jpg'),
(158, 'Panka', '2018-06-25', 5, 'kan', 'King Charles spániel', 'egészséges', 1, 6, 'foghiányos', 'egészséges', 'kicsi arany barna zöld', 'szeret úszni', 1, 0, '2023-02-27 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/79.jpg'),
(159, 'Grész', '2018-02-17', 5, 'kan', 'Belga griffon', 'rossz', 1, 4, 'fogszuvas', 'egészséges', 'kicsi sárga barna barna', 'szeret kutyakölykökkel játszani', 1, 0, '2021-02-17 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/167.jpg'),
(160, 'Lulu', '2019-06-09', 4, 'szuka', 'Bedlington terrier', 'egészséges', 1, 2, 'egészséges', 'közepes', 'nagy foltos fekete kék', 'több mozgást igényel', 1, 0, '2022-10-15 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/205.jpg'),
(161, 'Ofra', '2017-12-20', 6, 'kan', 'Brie-i juhászkutya', 'közepes', 0, 30, 'foghiányos', 'rossz', 'kicsi foltos fekete barna', 'köröm vágást igényel', 1, 0, '2022-12-10 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/152.jpg'),
(162, 'Hobbit', '2017-11-03', 6, 'kan', 'Yorkshire terrier', 'egészséges', 1, 21, 'egészséges', 'közepes', 'nagy tigriscsíkos barna barna', 'szeret úszni', 1, 0, '2023-05-04 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/176.jpg'),
(163, 'Keksz', '2017-09-10', 6, 'szuka', 'Ausztrál terrier', 'közepes', 1, 22, 'fogszuvas', 'rossz', 'kicsi tigriscsíkos rózsaszín kék', 'szeret sétálni a parkban', 1, 0, '2021-08-05 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/147.jpg'),
(164, 'Pufók', '2015-05-05', 8, 'szuka', 'Bergamói juhászkutya', 'közepes', 0, 3, 'foghiányos', 'egészséges', 'kicsi szürke barna kék', 'kedveli a sétákat', 1, 0, '2022-07-10 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/1.jpg'),
(165, 'Piszok', '2020-11-09', 3, 'kan', 'Silken Windhound', 'egészséges', 1, 28, 'fogszuvas', 'közepes', 'kicsi barna barna zöld', 'szeret labdázni', 1, 0, '2021-05-06 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/106.jpg'),
(166, 'Bonnie', '2016-01-19', 7, 'kan', 'Hygen kopó', 'rossz', 1, 19, 'egészséges', 'egészséges', 'nagy barna rózsaszín kék', 'szeret úszni', 1, 0, '2023-10-11 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/193.jpg'),
(167, 'Beethoven', '2017-01-23', 6, 'kan', 'Hosszúszőrű német vizsla', 'rossz', 0, 7, 'foghiányos', 'rossz', 'nagy tigriscsíkos fekete zöld', 'kedveli a sétákat', 1, 0, '2023-02-04 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/57.jpg'),
(168, 'Frida', '2019-09-26', 4, 'kan', 'Óriás schnauzer', 'rossz', 1, 11, 'egészséges', 'rossz', 'nagy szürke barna zöld', 'több mozgást igényel', 1, 0, '2021-04-24 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/140.jpg'),
(169, 'Rex', '2019-08-03', 4, 'kan', 'Osztrák pinscher', 'egészséges', 0, 14, 'foghiányos', 'egészséges', 'közepes szürke vörös barna', 'szeret úszni', 1, 0, '2023-08-12 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/113.jpg'),
(170, 'Úrfi', '2016-04-18', 7, 'kan', 'Pekingi palotakutya', 'rossz', 0, 27, 'fogszuvas', 'rossz', 'közepes foltos barna barna', 'köröm vágást igényel', 1, 0, '2021-11-14 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/122.jpg'),
(171, 'Glédis', '2018-02-06', 5, 'kan', 'Nagyspitz', 'közepes', 1, 30, 'fogszuvas', 'egészséges', 'kicsi foltos fekete zöld', 'szeret játszani a labdával', 1, 0, '2022-08-16 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/81.jpg'),
(172, 'Szeti', '2017-05-12', 6, 'szuka', 'Welsh springer spániel', 'közepes', 1, 3, 'foghiányos', 'rossz', 'kicsi vörös rózsaszín zöld', 'kedves és barátságos', 1, 0, '2022-02-22 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/56.jpg'),
(173, 'Vitéz', '2018-08-25', 5, 'szuka', 'Orosz agár', 'egészséges', 0, 13, 'fogszuvas', 'egészséges', 'kicsi fehér vörös barna', 'köröm vágást igényel', 1, 0, '2023-04-15 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/108.jpg'),
(174, 'Pepe', '2017-12-14', 6, 'kan', 'Francia kopó', 'rossz', 0, 29, 'foghiányos', 'egészséges', 'kicsi szürke sötétbarna barna', 'szeret futkosni a kertben', 1, 0, '2023-02-24 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/162.jpg'),
(175, 'Jonathan', '2019-08-24', 4, 'kan', 'Finn spicc', 'közepes', 0, 30, 'foghiányos', 'rossz', 'közepes tigriscsíkos fekete zöld', 'imád aludni', 1, 0, '2023-09-25 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/79.jpg'),
(176, 'Jade', '2018-07-28', 5, 'kan', 'Berni kopó', 'rossz', 1, 19, 'egészséges', 'közepes', 'kicsi sárga rózsaszín kék', 'kedveli a sétákat', 1, 0, '2022-01-11 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/22.jpg'),
(177, 'Elíz', '2015-10-09', 8, 'kan', 'Kis jurai kopó', 'egészséges', 1, 13, 'fogszuvas', 'rossz', 'kicsi szürke vörös barna', 'bélférges', 1, 0, '2023-09-09 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/1.jpg'),
(178, 'Shiva', '2020-10-26', 3, 'szuka', 'Spanyol kopó', 'közepes', 1, 2, 'foghiányos', 'rossz', 'kicsi vörös rózsaszín barna', 'több mozgást igényel', 1, 0, '2022-12-18 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/142.jpg'),
(179, 'Parádé', '2018-10-27', 5, 'kan', 'Angol szetter', 'rossz', 0, 12, 'egészséges', 'rossz', 'kicsi foltos barna kék', 'szeret játszani', 1, 0, '2022-09-08 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/93.jpg'),
(180, 'Lolka', '2017-02-13', 6, 'szuka', 'Black mouth cur', 'rossz', 0, 28, 'egészséges', 'rossz', 'nagy tigriscsíkos rózsaszín zöld', 'szeret fürdeni a tóban', 1, 0, '2021-07-15 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/87.jpg'),
(181, 'Rolf', '2015-12-23', 8, 'szuka', 'Japán spicc', 'közepes', 1, 8, 'fogszuvas', 'rossz', 'közepes foltos fekete zöld', 'szeret az ablakban ülni', 1, 0, '2021-10-01 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/70.jpg'),
(182, 'Plutó', '2020-06-06', 3, 'szuka', 'Fríz vizsla', 'rossz', 1, 18, 'fogszuvas', 'egészséges', 'nagy arany fekete barna', 'szeret sétálni a parkban', 1, 0, '2021-02-02 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/28.jpg'),
(183, 'Wolf', '2018-09-15', 5, 'szuka', 'Angol juhászkutya', 'egészséges', 0, 22, 'foghiányos', 'közepes', 'kicsi barna fekete barna', 'köröm vágást igényel', 1, 0, '2021-11-21 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/71.jpg'),
(184, 'Boomer', '2020-05-24', 3, 'kan', 'Skye terrier', 'rossz', 0, 10, 'egészséges', 'közepes', 'kicsi fekete vörös zöld', 'bélférges', 1, 0, '2022-02-28 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/77.jpg'),
(185, 'Pufók', '2020-02-18', 3, 'kan', 'Ariége-i kopó', 'egészséges', 1, 6, 'foghiányos', 'közepes', 'kicsi foltos barna barna', 'szeret fürdeni a tóban', 1, 0, '2021-03-18 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/119.jpg'),
(186, 'Nyikita', '2016-09-21', 7, 'kan', 'Cseh szálkás szakállú vizsla', 'közepes', 1, 25, 'foghiányos', 'egészséges', 'kicsi barna barna barna', 'szeret nyugodtan pihenni', 1, 0, '2023-03-09 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/46.jpg'),
(187, 'Tofi', '2020-11-01', 3, 'szuka', 'Ausztrál juhászkutya', 'egészséges', 1, 25, 'foghiányos', 'egészséges', 'közepes tigriscsíkos rózsaszín zöld', 'bélférges', 1, 0, '2021-03-28 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/12.jpg'),
(188, 'Jonathan', '2018-11-24', 5, 'szuka', 'Osztrák kopó', 'rossz', 1, 10, 'foghiányos', 'közepes', 'nagy foltos rózsaszín barna', 'szeret labdázni', 1, 0, '2022-11-24 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/208.jpg'),
(189, 'Dorel', '2020-08-17', 3, 'kan', 'Welsh terrier', 'közepes', 1, 10, 'fogszuvas', 'rossz', 'kicsi fehér fekete barna', 'szeret úszni', 1, 0, '2022-05-11 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/207.jpg'),
(190, 'Keksz', '2016-09-27', 7, 'szuka', 'Weimari vizsla', 'közepes', 1, 3, 'foghiányos', 'rossz', 'nagy foltos sötétbarna zöld', 'be van gyulladva a füle', 1, 0, '2021-11-09 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/141.jpg'),
(191, 'Nudli', '2017-11-14', 6, 'kan', 'Angol bulldog', 'egészséges', 1, 27, 'egészséges', 'közepes', 'nagy foltos barna kék', 'köröm vágást igényel', 1, 0, '2021-04-02 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/50.jpg'),
(192, 'Gróf', '2020-10-10', 3, 'szuka', 'Atlaszi hegyikutya', 'közepes', 1, 25, 'foghiányos', 'egészséges', 'közepes vörös sötétbarna barna', 'kedveli a sétákat', 1, 0, '2022-07-13 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/27.jpg'),
(193, 'Vitéz', '2019-01-13', 4, 'szuka', 'Drótszőrű isztriai kopó', 'rossz', 1, 30, 'foghiányos', 'rossz', 'nagy foltos fekete kék', 'kedves és barátságos', 1, 0, '2021-02-15 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/162.jpg'),
(194, 'Pajtás', '2018-04-23', 5, 'kan', 'Holland juhászkutya', 'közepes', 0, 18, 'foghiányos', 'rossz', 'nagy vörös barna zöld', 'bélférges', 1, 0, '2021-01-26 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/209.jpg'),
(195, 'Jágó', '2019-11-15', 4, 'szuka', 'Cardigan welsh corgi', 'egészséges', 1, 3, 'egészséges', 'rossz', 'közepes tigriscsíkos rózsaszín kék', 'imád aludni', 1, 0, '2022-06-22 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/104.jpg'),
(196, 'Stella', '2018-09-06', 5, 'szuka', 'Orosz fekete terrier', 'közepes', 1, 21, 'foghiányos', 'közepes', 'kicsi barna vörös kék', 'kedveli a sétákat', 1, 0, '2023-06-07 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/66.jpg'),
(197, 'Bonnie', '2020-02-08', 3, 'szuka', 'Brüsszeli griffon', 'egészséges', 1, 27, 'egészséges', 'egészséges', 'nagy barna rózsaszín zöld', 'szeret ölelni', 1, 0, '2022-01-08 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/88.jpg'),
(198, 'Parádé', '2018-03-02', 5, 'kan', 'Ausztrál pásztorkutya', 'közepes', 0, 30, 'fogszuvas', 'közepes', 'kicsi fekete vörös kék', 'több mozgást igényel', 1, 0, '2023-06-07 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/198.jpg'),
(199, 'Vacak', '2018-12-28', 5, 'szuka', 'Kanári-szigeteki kopó', 'közepes', 1, 20, 'foghiányos', 'rossz', 'nagy sárga vörös kék', 'szeret fürdeni a tóban', 1, 0, '2021-03-06 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/65.jpg'),
(200, 'Hobbit', '2020-07-14', 3, 'kan', 'Fekete norvég elghund', 'rossz', 1, 12, 'fogszuvas', 'rossz', 'kicsi sárga fekete zöld', 'szeret ölelni', 1, 0, '2022-09-08 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/63.jpg'),
(201, 'Tekergő', '2020-04-14', 3, 'kan', 'Spanyol agár', 'közepes', 0, 17, 'foghiányos', 'egészséges', 'kicsi fehér rózsaszín zöld', 'kedveli a sétákat', 1, 0, '2022-08-20 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/126.jpg'),
(202, 'Jet', '2019-02-28', 4, 'szuka', 'Thai ridgeback', 'rossz', 0, 28, 'fogszuvas', 'közepes', 'közepes fekete fekete zöld', 'több mozgást igényel', 1, 0, '2023-01-06 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/130.jpg'),
(203, 'Molly', '2016-03-01', 7, 'kan', 'Tasi (Kelet-ázsiai barzoj)', 'rossz', 1, 16, 'egészséges', 'közepes', 'kicsi vörös barna kék', 'szeret játszani', 1, 0, '2021-01-20 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/200.jpg'),
(204, 'Keksz', '2020-10-26', 3, 'szuka', 'Brazil terrier', 'egészséges', 0, 3, 'foghiányos', 'rossz', 'nagy fehér vörös kék', 'szeret úszni', 1, 0, '2023-10-17 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/180.jpg'),
(205, 'Lasszó', '2017-01-12', 6, 'szuka', 'Kanári-szigeteki kopó', 'közepes', 1, 8, 'fogszuvas', 'közepes', 'közepes barna sötétbarna zöld', 'kedves és barátságos', 1, 0, '2021-04-22 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/106.jpg'),
(206, 'Gingy', '2015-06-11', 8, 'kan', 'Spanyol vízikutya', 'egészséges', 0, 10, 'foghiányos', 'rossz', 'nagy arany fekete barna', 'szeret játszani', 1, 0, '2021-06-16 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/6.jpg'),
(207, 'Zsozsó', '2018-07-16', 5, 'kan', 'Ausztrál juhászkutya', 'rossz', 1, 16, 'foghiányos', 'egészséges', 'kicsi arany barna barna', 'be van gyulladva a füle', 1, 0, '2022-08-20 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/106.jpg'),
(208, 'Lulu', '2019-01-23', 4, 'kan', 'Phalène', 'közepes', 1, 3, 'foghiányos', 'egészséges', 'közepes fekete sötétbarna kék', 'köröm vágást igényel', 1, 0, '2022-05-01 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/164.jpg'),
(209, 'Pénzecske', '2016-08-15', 7, 'kan', 'Tasi (Kelet-ázsiai barzoj)', 'rossz', 1, 14, 'foghiányos', 'közepes', 'nagy vörös rózsaszín barna', 'szeret labdázni', 1, 0, '2021-01-08 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/52.jpg'),
(210, 'Pongó', '2016-02-04', 7, 'szuka', 'Flandriai pásztorkutya', 'rossz', 1, 10, 'egészséges', 'közepes', 'kicsi barna vörös kék', 'szeret ölelni', 1, 0, '2021-01-05 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/95.jpg');
INSERT INTO `allatok` (`allat_id`, `allat_nev`, `szul_ev`, `becsult_kor`, `neme`, `fajta`, `eu_allapot`, `ivar_ivartalanitot`, `suly`, `fogazatt`, `testi_allapott`, `ismertetojegyek`, `megjegyzes`, `chip`, `orokbeadas`, `befogadas_datuma`, `img`) VALUES
(211, 'Gandhi', '2016-07-16', 7, 'szuka', 'Kis angol agár', 'rossz', 1, 23, 'egészséges', 'közepes', 'közepes arany vörös barna', 'szeret ölelni', 1, 0, '2021-12-22 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/128.jpg'),
(212, 'Jade', '2017-11-19', 6, 'kan', 'Mexikói meztelen kutya', 'közepes', 0, 22, 'fogszuvas', 'közepes', 'kicsi vörös vörös zöld', 'szeret játszani a labdával', 1, 0, '2023-10-11 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/185.jpg'),
(213, 'Adonisz', '2019-11-05', 4, 'kan', 'Újfundlandi', 'egészséges', 0, 26, 'fogszuvas', 'egészséges', 'közepes arany fekete zöld', 'szeret nyugodtan pihenni', 1, 0, '2023-01-25 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/52.jpg'),
(214, 'Vacak', '2017-02-05', 6, 'szuka', 'Kis münsterlandi vizsla', 'közepes', 0, 20, 'fogszuvas', 'közepes', 'kicsi fekete rózsaszín zöld', 'kedves és barátságos', 1, 0, '2022-02-21 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/40.jpg'),
(215, 'Vénusz', '2017-03-19', 6, 'kan', 'Angol cocker spániel', 'közepes', 1, 20, 'foghiányos', 'egészséges', 'közepes tigriscsíkos rózsaszín barna', 'köröm vágást igényel', 1, 0, '2021-03-17 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/39.jpg'),
(216, 'Ajax', '2020-07-09', 3, 'szuka', 'Drótszőrű isztriai kopó', 'rossz', 1, 6, 'egészséges', 'egészséges', 'közepes arany fekete zöld', 'köröm vágást igényel', 1, 0, '2023-11-03 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/127.jpg'),
(217, 'Teo', '2018-04-28', 5, 'kan', 'Si-cu', 'rossz', 1, 12, 'egészséges', 'rossz', 'nagy szürke sötétbarna kék', 'bélférges', 1, 0, '2022-10-08 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/184.jpg'),
(218, 'Gandhi', '2020-07-08', 3, 'szuka', 'Drótszőrű portugál kopó', 'közepes', 0, 19, 'egészséges', 'közepes', 'kicsi tigriscsíkos vörös kék', 'szeret sétálni a parkban', 1, 0, '2021-10-07 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/154.jpg'),
(219, 'Zsüti', '2019-04-17', 4, 'kan', 'Beagle', 'rossz', 0, 19, 'foghiányos', 'egészséges', 'nagy vörös barna kék', 'szeret futkosni a kertben', 1, 0, '2022-08-08 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/170.jpg'),
(220, 'Vacak', '2016-10-13', 7, 'kan', 'Brazil masztiff', 'közepes', 1, 18, 'fogszuvas', 'egészséges', 'közepes sárga vörös barna', 'szeret az ablakban ülni', 1, 0, '2022-11-07 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/197.jpg'),
(221, 'Jade', '2015-08-04', 8, 'kan', 'Patterdale terrier', 'egészséges', 0, 1, 'foghiányos', 'egészséges', 'nagy fehér sötétbarna barna', 'több mozgást igényel', 1, 0, '2023-02-16 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/82.jpg'),
(222, 'Mancs', '2016-11-25', 7, 'szuka', 'Belga griffon', 'egészséges', 1, 2, 'egészséges', 'közepes', 'közepes szürke fekete kék', 'szeret sétálni a parkban', 1, 0, '2021-05-13 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/90.jpg'),
(223, 'Rézi', '2019-09-20', 4, 'szuka', 'Kangaroo Dog', 'rossz', 1, 5, 'fogszuvas', 'egészséges', 'közepes barna vörös barna', 'kedveli a sétákat', 1, 0, '2023-03-01 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/206.jpg'),
(224, 'Espresso', '2018-04-26', 5, 'szuka', 'Shetlandi juhászkutya', 'közepes', 1, 23, 'egészséges', 'egészséges', 'nagy fehér barna zöld', 'imád aludni', 1, 0, '2021-10-05 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/178.jpg'),
(225, 'Espresso', '2019-12-20', 4, 'szuka', 'Fehér-fekete nagy angol-francia kopó', 'egészséges', 0, 30, 'egészséges', 'közepes', 'nagy fekete fekete barna', 'szeret az ablakban ülni', 1, 0, '2021-05-21 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/133.jpg'),
(226, 'Jasper', '2015-07-20', 8, 'kan', 'Óriás uszkár', 'közepes', 1, 6, 'fogszuvas', 'egészséges', 'közepes barna rózsaszín barna', 'szeret sétálni a parkban', 1, 0, '2021-05-10 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/113.jpg'),
(227, 'Hektor', '2020-07-03', 3, 'szuka', 'Saage kochee', 'egészséges', 1, 6, 'foghiányos', 'egészséges', 'kicsi vörös vörös zöld', 'szeret labdázni', 1, 0, '2021-08-10 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/184.jpg'),
(228, 'Pedró', '2019-01-26', 4, 'kan', 'Savoye-i pásztorkutya', 'közepes', 0, 5, 'foghiányos', 'rossz', 'nagy szürke barna kék', 'szeret úszni', 1, 0, '2021-09-23 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/53.jpg'),
(229, 'Jasper', '2018-07-07', 5, 'kan', 'Saint-germaini vizsla', 'közepes', 0, 28, 'egészséges', 'rossz', 'kicsi sárga sötétbarna barna', 'köröm vágást igényel', 1, 0, '2021-01-26 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/156.jpg'),
(230, 'Espresso', '2015-02-15', 8, 'szuka', 'Szálkásszőrű német vizsla', 'rossz', 1, 20, 'fogszuvas', 'közepes', 'nagy fekete rózsaszín zöld', 'kedveli a sétákat', 1, 0, '2022-07-10 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/14.jpg'),
(231, 'Leila', '2015-11-04', 8, 'szuka', 'Malinois', 'közepes', 0, 1, 'foghiányos', 'közepes', 'kicsi barna vörös zöld', 'szeret kutyakölykökkel játszani', 1, 0, '2023-12-28 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/93.jpg'),
(232, 'Lady', '2019-01-05', 4, 'szuka', 'Brabançon', 'közepes', 1, 7, 'egészséges', 'közepes', 'nagy foltos barna zöld', 'szeret futkosni a kertben', 1, 0, '2022-10-14 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/182.jpg'),
(233, 'Killer', '2016-08-01', 7, 'kan', 'Kras-medencei juhászkutya', 'rossz', 1, 28, 'egészséges', 'rossz', 'kicsi tigriscsíkos sötétbarna kék', 'imád aludni', 1, 0, '2022-06-06 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/180.jpg'),
(234, 'Gerry', '2020-10-28', 3, 'szuka', 'Nagy angol-francia kopó', 'egészséges', 0, 22, 'egészséges', 'közepes', 'közepes sárga rózsaszín kék', 'szeret sétálni a parkban', 1, 0, '2021-08-13 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/163.jpg'),
(235, 'Ibis', '2019-09-05', 4, 'kan', 'Svéd juhászspitz', 'közepes', 1, 13, 'fogszuvas', 'közepes', 'kicsi szürke vörös zöld', 'több mozgást igényel', 1, 0, '2021-10-17 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/79.jpg'),
(236, 'Pötyi', '2015-05-13', 8, 'szuka', 'Moszkvai hosszú szőrű toy terrier', 'közepes', 0, 20, 'fogszuvas', 'egészséges', 'nagy vörös barna zöld', 'szeret labdázni', 1, 0, '2022-07-05 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/22.jpg'),
(237, 'Pisze', '2015-02-27', 8, 'kan', 'Kis münsterlandi vizsla', 'közepes', 1, 18, 'foghiányos', 'egészséges', 'közepes vörös rózsaszín barna', 'szeret az ablakban ülni', 1, 0, '2021-08-12 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/105.jpg'),
(238, 'Azték', '2017-02-06', 6, 'szuka', 'Breton spániel', 'egészséges', 0, 22, 'fogszuvas', 'egészséges', 'közepes vörös sötétbarna barna', 'szeret futkosni a kertben', 1, 0, '2022-10-13 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/165.jpg'),
(239, 'Stella', '2018-10-09', 5, 'kan', 'Skót juhászkutya', 'egészséges', 0, 30, 'fogszuvas', 'közepes', 'kicsi tigriscsíkos barna kék', 'köröm vágást igényel', 1, 0, '2021-02-02 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/176.jpg'),
(240, 'Müzli', '2018-01-17', 5, 'kan', 'Estrelai hegyikutya', 'rossz', 1, 24, 'egészséges', 'egészséges', 'közepes barna barna barna', 'szeret fürdeni a tóban', 1, 0, '2023-03-25 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/209.jpg'),
(241, 'Destiny', '2020-10-07', 3, 'szuka', 'Nyugat-szibériai lajka', 'közepes', 1, 11, 'foghiányos', 'közepes', 'nagy fehér rózsaszín barna', 'szeret kutyakölykökkel játszani', 1, 0, '2021-12-12 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/207.jpg'),
(242, 'Pajtás', '2016-01-21', 7, 'szuka', 'Halden kopó', 'egészséges', 0, 30, 'fogszuvas', 'közepes', 'nagy sárga barna zöld', 'szeret futkosni a kertben', 1, 0, '2021-06-21 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/150.jpg'),
(243, 'Mimi', '2018-01-03', 5, 'kan', 'Kalag Tazi', 'rossz', 1, 4, 'fogszuvas', 'egészséges', 'kicsi tigriscsíkos vörös barna', 'szeret nyugodtan pihenni', 1, 0, '2022-08-05 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/68.jpg'),
(244, 'Rejtély', '2016-05-11', 7, 'szuka', 'Catahoulai leopárdkutya', 'rossz', 1, 21, 'egészséges', 'rossz', 'kicsi sárga vörös zöld', 'szeret labdázni', 1, 0, '2023-07-18 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/142.jpg'),
(245, 'Suhanc', '2018-07-06', 5, 'kan', 'Yorkshire terrier', 'egészséges', 1, 9, 'foghiányos', 'rossz', 'közepes vörös sötétbarna zöld', 'szeret futkosni a kertben', 1, 0, '2022-11-01 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/148.jpg'),
(246, 'Terry', '2020-07-24', 3, 'szuka', 'Boykin spániel', 'közepes', 0, 21, 'fogszuvas', 'rossz', 'közepes barna sötétbarna zöld', 'kedves és barátságos', 1, 0, '2023-11-15 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/70.jpg'),
(247, 'Keiko', '2018-03-27', 5, 'szuka', 'Bolognai pincs', 'közepes', 0, 16, 'fogszuvas', 'rossz', 'közepes tigriscsíkos fekete zöld', 'szeret labdázni', 1, 0, '2022-11-02 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/84.jpg'),
(248, 'Anasztázia', '2018-02-20', 5, 'kan', 'Brie-i juhászkutya', 'közepes', 1, 6, 'fogszuvas', 'rossz', 'kicsi szürke barna barna', 'szeret úszni', 1, 0, '2023-01-26 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/183.jpg'),
(249, 'Nina', '2017-04-24', 6, 'szuka', 'Artois-i kopó', 'egészséges', 0, 7, 'fogszuvas', 'rossz', 'nagy sárga barna zöld', 'kedves és barátságos', 1, 0, '2022-12-14 00:00:00', 'http://localhost/FKNmenhely/www_tappancs_hu/72.jpg'),
(251, 'Picur', '2022-01-16', 2, 'szuka', 'Golden retriever', 'egészséges', 1, 15, 'egészséges', 'egészséges', 'Szereti a vízet.', 'Nyáron sok szőrt hullaljt ezt figyelembe kell venni nála.', 1, 0, '2023-04-16 14:27:54', 'http://localhost/FKNmenhely/www_tappancs_hu/Isti.jpg'),
(252, 'Lili', '2021-01-02', 3, 'szuka', 'Husky', 'közepes', 0, 30, 'egészséges', 'egészséges', 'Szereti a hideget.', 'Sok futtást és nagy kertett igényel.', 1, 0, '2023-04-16 14:30:56', 'http://localhost/FKNmenhely/www_tappancs_hu/Isti.jpg'),
(253, 'Jimmy', '2022-01-20', 2, 'kan', 'Mudi', 'egészséges', 1, 30, 'egészséges', 'egészséges', 'Szőrzete fekete színű ,szeme barnás árnyalatú.Szereti a gyerekeket.', 'Sok mozgást igényel.', 1, 0, '2023-04-16 16:16:28', 'http://localhost/FKNmenhely/www_tappancs_hu/Jimmy.jpg'),
(254, 'Isti', '2023-04-14', 1, 'kan', 'Golden retriever', 'közepes', 0, 30, 'egészséges', 'egészséges', 'nincs', 'nincs', 1, 0, '2023-04-16 16:26:18', 'http://localhost/FKNmenhely/www_tappancs_hu/Isti.jpg');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `orokbeadott_allatok`
--

CREATE TABLE `orokbeadott_allatok` (
  `id` int(11) NOT NULL,
  `user_id` int(255) NOT NULL,
  `allat_id` int(255) NOT NULL,
  `be_datum` datetime NOT NULL DEFAULT current_timestamp(),
  `ki_datum` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `orokbeadott_allatok`
--

INSERT INTO `orokbeadott_allatok` (`id`, `user_id`, `allat_id`, `be_datum`, `ki_datum`, `status`) VALUES
(43, 1, 1, '2023-04-14 23:30:30', NULL, 1),
(56, 3, 6, '2023-04-16 14:37:49', NULL, 1),
(57, 3, 4, '2023-04-16 14:39:17', NULL, 1);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `kert_van` varchar(10) NOT NULL,
  `add_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `bizalom_v` tinyint(1) NOT NULL DEFAULT 1,
  `admin_e` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password_hash`, `kert_van`, `add_date`, `bizalom_v`, `admin_e`) VALUES
(1, 'Szász Gergő', 'szaszgergo005@gmail.com', '$2y$10$eSEZoPSsAp14WLSl94TrAOJnC33SSuvOZJZJScWeCBYdXPSFg/S12', 'kert', '2023-04-12 16:36:30', 1, 0),
(2, 'nincskert', 'nincskert@gmail.com', '$2y$10$cmDAQ/eX9ZmbBzwzDZIgquGjFYQD.K8t4TqSWWRmYx7erhGN5dB26', 'panel', '2023-04-12 16:37:02', 1, 0),
(3, 'kert1', 'kert1@gmail.com', '$2y$10$H9za3Y3kBMQHmgmjzMUKeONLZopGUsb6u8uuUckHdJV1YIWbjye6C', 'kert', '2023-04-13 18:22:56', 1, 0),
(4, 'kert2', 'kert2@gmail.com', '$2y$10$EMKF.5gsyscqXyBG2o3DuOfyIDq1McY8wMvWDAvRIfJUghKWXn0Pa', 'kert', '2023-04-13 18:23:06', 1, 0),
(5, 'admin', 'admin@gmail.com', '$2y$10$qVgFO3VuaDuy5mWc.tqJUumt.PK3OF1X3HesZHEU6T6J.0o2tb7.S', 'kert', '2023-04-16 08:20:03', 1, 1);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `allatok`
--
ALTER TABLE `allatok`
  ADD PRIMARY KEY (`allat_id`);

--
-- A tábla indexei `orokbeadott_allatok`
--
ALTER TABLE `orokbeadott_allatok`
  ADD PRIMARY KEY (`id`),
  ADD KEY `allat_id` (`allat_id`),
  ADD KEY `user_id` (`user_id`);

--
-- A tábla indexei `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `allatok`
--
ALTER TABLE `allatok`
  MODIFY `allat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=255;

--
-- AUTO_INCREMENT a táblához `orokbeadott_allatok`
--
ALTER TABLE `orokbeadott_allatok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT a táblához `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `orokbeadott_allatok`
--
ALTER TABLE `orokbeadott_allatok`
  ADD CONSTRAINT `orokbeadott_allatok_ibfk_1` FOREIGN KEY (`allat_id`) REFERENCES `allatok` (`allat_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orokbeadott_user_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
