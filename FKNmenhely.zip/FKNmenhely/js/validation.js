const validation = new JustValidate("#signup");


validation


.addField("#name", [
    {
        rule: "required",
        
        errorMessage: "A felhasználónév mező kitöltése kötelező",
      
    },
    {
        validator: (value, fields) => {
            const regex = /^[a-zA-Z0-9_]+$/; // regex, ami elfogadja az angol betűket, számokat és az alsóvonást
            return regex.test(value); // a regex tesztelése a felhasználónév értékével
        },
        errorMessage: "A felhasználónév nem tartalmazhat speciális karaktert"
    }
])
//



.addField("#email", [
    {
        rule: "required",
        errorMessage: "Az email mező kitöltése kötelező"
    },
    {
        rule: "email",
        errorMessage: "Kérjük, adjon meg egy érvényes email címet"
    },
    {
        validator: (value) => {
            return fetch("validate-email.php?email=" + encodeURIComponent(value))
            .then(function(response) {
                return response.json();
            })
            .then(function(json) {
                if (!json.available) {
                    throw new Error("Az e-mail már foglalt");
                }
            });
        },
        errorMessage: "Az e-mail már foglalt"
    }
])
    .addField("#password", [
        {
            rule: "required",
            errorMessage: "A jelszó mező kitöltése kötelező"
        },
        {
            validator: (value, fields) => {
                const regex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/; // jelszó validációs szabályok
                return regex.test(value); // teszteljük a jelszó érvényességét
            },
            errorMessage: "A jelszónak legalább 8 karakter hosszúnak kell lennie, legalább egy betűt és egy számot kell tartalmaznia" // új szöveg, amely akkor jelenik meg, ha a felhasználó nem felel meg a jelszóval kapcsolatos követelményeknek
        },
      
        {
            rule: "password"
        }
    ])
    .addField("#password_confirmation", [
        {
            validator: (value, fields) => {
                return value === fields["#password"].elem.value;
            },
            errorMessage: "A jelszavak nem egyeznek"
        }
    ])
    .onSuccess((event) => {
        document.getElementById("signup").submit();
});