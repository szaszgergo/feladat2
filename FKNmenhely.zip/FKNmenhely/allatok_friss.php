<?php
session_start();
$conn = mysqli_connect("localhost","root","","fknmenhely");




if(isset($_POST['save_date']))
{
 ///allat id
 $db = new mysqli("localhost", "root", "", "fknmenhely");
 $db_amount = $db->query("SELECT COUNT(*) FROM allatok");
 $totalItem = $db_amount->fetch_row()[0];
 $url_allat_id = $_GET['id'];
 if ($url_allat_id <= $totalItem) {
     $allat = $db->query("SELECT * FROM `allatok` WHERE `allat_id` = \"$url_allat_id\"");
     
  
     $mezo = $allat -> fetch_row();
     $allat_id = $mezo[0];
     $allat_orokebadas = $mezo[14];
    
 }
////////

    $name = $_POST['name'];
    $dob = date('Y-m-d', strtotime($_POST['dateofbirth']));
   
//becsultkor helye

$becsultkor = $_POST['becsultkor'];

//neme
$neme = $_POST['neme'];  
if ($neme == "kan") {          
    $neme_van= $_POST['neme'];     
}
if ($neme == "szuka") {          
    $neme_van= $_POST['neme'];     
}

//
$faja_van = $_POST['faja'];

//eu
$eu_allapot_van =$_POST["eu_allapot"];
//ivar

$ivar = $_POST['ivar'];  
if ($ivar == "1") {          
    $ivar_van= $_POST['ivar'];     
}
if ($ivar == "0") {          
    $ivar_van= $_POST['ivar'];     
}

//
//suly
$suly_van = $_POST['suly'];
//
//fog
$fogazatt_allapot_van =$_POST["fogazatt_allapot"];
//
//testi
$testi_allapot_van =$_POST["testi_allapot"];

//ismerteto
$ismertetojegyek_van =$_POST["ismertetojegyek"];
//
//megjegyzes
$megjegyzes_van =$_POST["megjegyzes"];
//
//chippelt-e

$chip = $_POST['chip'];  
if ($chip == "1") {          
    $chip_van= $_POST['chip'];     
}
if ($chip == "0") {          
    $chip_van= $_POST['chip'];     
}



 
   // $query = "UPDATE allatok SET allat_nev = '$name', szul_ev = '$dob', becsult_kor = $becsultkor , neme = $neme_van ,fajta = $faja_van , eu_allapot = $eu_allapot_van, ivar_ivartalanitot = $ivar_van, suly = $suly_van, fogazatt = $fogazatt_allapot_van, testi_allapott = $testi_allapot_van,  ismertetojegyek = $ismertetojegyek_van, megjegyzes = $megjegyzes_van,  chip = $chip_van, img = $kutyakep WHERE id = $allat_id";
    ////////////////////////////////////
    $query = "UPDATE allatok SET allat_nev = '$name', szul_ev = '$dob', becsult_kor = '$becsultkor' , neme = '$neme_van' ,fajta = '$faja_van' , eu_allapot = '$eu_allapot_van', ivar_ivartalanitot = '$ivar_van', suly = '$suly_van', fogazatt = '$fogazatt_allapot_van', testi_allapott = '$testi_allapot_van',  ismertetojegyek = '$ismertetojegyek_van', megjegyzes = '$megjegyzes_van',  chip = '$chip_van'  WHERE allat_id = \"$url_allat_id\"";

    echo($query);







    
//////////////////////////////////////////////
$query_run = mysqli_query($conn, $query);

if($query_run)
{
    $_SESSION['status'] = "Sikeresen feltöltöted az állatot.";
    header("Location: index.html");
}
else
{
    $_SESSION['status'] = "Nem sikerült feltöltened az állatot.";
    
 //   echo("nem jó");
}
}
?>