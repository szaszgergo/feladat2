-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2023 at 05:52 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fknmenhely`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_allatok` ()   SELECT * FROM allatok$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `allatok`
--

CREATE TABLE `allatok` (
  `allat_id` int(11) NOT NULL,
  `allat_nev` varchar(50) NOT NULL,
  `szul_ev` date NOT NULL,
  `becsult_kor` int(11) NOT NULL,
  `neme` varchar(255) NOT NULL DEFAULT 'kan',
  `fajta` varchar(255) NOT NULL,
  `eu_allapot` varchar(255) NOT NULL,
  `ivar_ivartalanitot` tinyint(1) NOT NULL,
  `suly` float NOT NULL,
  `fogazatt` varchar(255) NOT NULL,
  `testi_allapott` varchar(255) NOT NULL,
  `ismertetojegyek` varchar(255) NOT NULL,
  `megjegyzes` varchar(255) NOT NULL,
  `chip` tinyint(1) NOT NULL,
  `orokbeadas` tinyint(1) NOT NULL DEFAULT 0,
  `befogadas_datuma` datetime NOT NULL DEFAULT current_timestamp(),
  `img` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `allatok`
--

INSERT INTO `allatok` (`allat_id`, `allat_nev`, `szul_ev`, `becsult_kor`, `neme`, `fajta`, `eu_allapot`, `ivar_ivartalanitot`, `suly`, `fogazatt`, `testi_allapott`, `ismertetojegyek`, `megjegyzes`, `chip`, `orokbeadas`, `befogadas_datuma`, `img`) VALUES
(1, 'Bütyök', '2015-09-13', 8, 'kan', 'Újfundlandi', 'egészséges', 0, 18, 'fogszuvas', 'egészséges', 'közepes tigriscsíkos barna kék', 'szeret játszani', 1, 0, '2021-06-23 00:00:00', '/www_tappancs_hu/104.jpg'),
(2, 'Oszkár', '2020-05-13', 3, 'kan', 'Pireneusi juhászkutya', 'közepes', 1, 9, 'foghiányos', 'rossz', 'kicsi fehér rózsaszín kék', 'bélférges', 1, 1, '2023-11-14 00:00:00', '/www_tappancs_hu/52.jpg'),
(3, 'Askim', '2015-11-13', 8, 'szuka', 'Cseh szálkás szakállú vizsla', 'rossz', 0, 20, 'egészséges', 'egészséges', 'közepes tigriscsíkos sötétbarna barna', 'szeret ölelni', 1, 0, '2023-10-19 00:00:00', '/www_tappancs_hu/136.jpg'),
(4, 'Rinó', '2019-10-11', 4, 'szuka', 'Középspitz', 'egészséges', 1, 28, 'fogszuvas', 'közepes', 'közepes foltos barna zöld', 'több mozgást igényel', 1, 1, '2023-05-21 00:00:00', '/www_tappancs_hu/155.jpg'),
(5, 'Pongó', '2018-04-07', 5, 'szuka', 'Groenendael', 'egészséges', 0, 12, 'fogszuvas', 'rossz', 'kicsi barna sötétbarna barna', 'szeret az ablakban ülni', 1, 0, '2023-02-16 00:00:00', '/www_tappancs_hu/110.jpg'),
(6, 'Bűvész', '2018-08-03', 5, 'kan', 'Japán csin', 'rossz', 1, 25, 'egészséges', 'közepes', 'kicsi foltos barna kék', 'szeret nyugodtan pihenni', 1, 1, '2021-08-13 00:00:00', '/www_tappancs_hu/205.jpg'),
(7, 'Pötyi', '2020-05-16', 3, 'kan', 'Vörös ír szetter', 'közepes', 1, 7, 'foghiányos', 'rossz', 'közepes barna rózsaszín barna', 'szeret nyugodtan pihenni', 1, 0, '2021-11-26 00:00:00', '/www_tappancs_hu/51.jpg'),
(8, 'Adonisz', '2016-02-16', 7, 'kan', 'Hosszúszőrű német vizsla', 'közepes', 1, 8, 'foghiányos', 'rossz', 'közepes fehér sötétbarna zöld', 'szeret úszni', 1, 1, '2021-12-19 00:00:00', '/www_tappancs_hu/122.jpg'),
(9, 'Tekergő', '2019-04-21', 4, 'kan', 'Finn spicc', 'közepes', 1, 29, 'egészséges', 'egészséges', 'közepes arany vörös zöld', 'szeret kutyakölykökkel játszani', 1, 1, '2022-10-15 00:00:00', '/www_tappancs_hu/43.jpg'),
(10, 'Edward', '2020-03-04', 3, 'szuka', 'Pumi', 'egészséges', 1, 14, 'egészséges', 'közepes', 'nagy tigriscsíkos barna barna', 'kedveli a sétákat', 1, 0, '2022-12-26 00:00:00', '/www_tappancs_hu/111.jpg'),
(11, 'Apolló', '2017-11-17', 6, 'kan', 'Göndörszőrű retriever', 'közepes', 0, 20, 'fogszuvas', 'közepes', 'közepes fekete vörös barna', 'szeret kutyakölykökkel játszani', 1, 0, '2023-04-26 00:00:00', '/www_tappancs_hu/157.jpg'),
(12, 'Maya', '2020-08-02', 3, 'szuka', 'Holland juhászkutya', 'rossz', 1, 7, 'fogszuvas', 'egészséges', 'nagy barna fekete barna', 'szeret sétálni a parkban', 1, 0, '2022-01-05 00:00:00', '/www_tappancs_hu/63.jpg'),
(13, 'Magnipuss', '2016-09-15', 7, 'kan', 'Angol mosómedvekopó', 'egészséges', 0, 6, 'egészséges', 'rossz', 'közepes szürke fekete barna', 'szeret futkosni a kertben', 1, 0, '2023-10-07 00:00:00', '/www_tappancs_hu/36.jpg'),
(14, 'Keksz', '2020-12-09', 3, 'szuka', 'Brüsszeli griffon', 'egészséges', 1, 27, 'fogszuvas', 'rossz', 'közepes fehér rózsaszín kék', 'köröm vágást igényel', 1, 0, '2021-03-13 00:00:00', '/www_tappancs_hu/102.jpg'),
(15, 'Destiny', '2019-10-05', 4, 'szuka', 'Wolfspitz', 'egészséges', 0, 30, 'fogszuvas', 'egészséges', 'kicsi fehér barna kék', 'szeret ölelni', 1, 0, '2023-07-24 00:00:00', '/www_tappancs_hu/109.jpg'),
(16, 'Adél', '2017-01-26', 6, 'kan', 'Amerikai staffordshire terrier', 'rossz', 0, 7, 'fogszuvas', 'rossz', 'közepes tigriscsíkos rózsaszín kék', 'szeret ölelni', 1, 0, '2021-04-14 00:00:00', '/www_tappancs_hu/114.jpg'),
(17, 'Frakk', '2017-03-25', 6, 'kan', 'Saarloosi farkaskutya', 'rossz', 1, 30, 'fogszuvas', 'közepes', 'kicsi sárga rózsaszín kék', 'szeret nyugodtan pihenni', 1, 0, '2023-12-24 00:00:00', '/www_tappancs_hu/41.jpg'),
(18, 'Polli', '2020-02-19', 3, 'kan', 'Nivernais-i griffon', 'rossz', 1, 7, 'foghiányos', 'rossz', 'nagy arany barna zöld', 'szeret ölelni', 1, 0, '2023-08-06 00:00:00', '/www_tappancs_hu/25.jpg'),
(19, 'Mancs', '2019-04-27', 4, 'kan', 'Glen of Imaal terrier', 'közepes', 0, 22, 'foghiányos', 'közepes', 'kicsi fehér sötétbarna kék', 'imád aludni', 1, 0, '2021-11-25 00:00:00', '/www_tappancs_hu/62.jpg'),
(20, 'Desiré', '2018-12-15', 5, 'szuka', 'Bolognai pincs', 'egészséges', 0, 7, 'egészséges', 'rossz', 'közepes szürke barna kék', 'szeret labdázni', 1, 0, '2023-12-06 00:00:00', '/www_tappancs_hu/74.jpg'),
(21, 'Adonisz', '2017-12-22', 6, 'kan', 'Boszniai kopó', 'rossz', 1, 15, 'egészséges', 'egészséges', 'kicsi sárga sötétbarna zöld', 'több mozgást igényel', 1, 0, '2022-09-16 00:00:00', '/www_tappancs_hu/122.jpg'),
(22, 'Szeti', '2018-06-12', 5, 'szuka', 'Manchester terrier', 'egészséges', 0, 19, 'fogszuvas', 'egészséges', 'kicsi fehér barna barna', 'szeret nyugodtan pihenni', 1, 0, '2022-09-15 00:00:00', '/www_tappancs_hu/150.jpg'),
(23, 'Elvis', '2016-08-01', 7, 'szuka', 'Francia vizsla', 'rossz', 1, 20, 'egészséges', 'rossz', 'kicsi sárga barna zöld', 'szeret játszani', 1, 0, '2022-11-23 00:00:00', '/www_tappancs_hu/170.jpg'),
(24, 'Maya', '2015-01-04', 8, 'kan', 'Gascogne-i kék basset', 'közepes', 1, 26, 'fogszuvas', 'egészséges', 'nagy foltos vörös zöld', 'szeret az ablakban ülni', 1, 0, '2021-09-24 00:00:00', '/www_tappancs_hu/39.jpg'),
(25, 'Sámson', '2018-04-11', 5, 'kan', 'Isztriai kopó', 'közepes', 1, 9, 'foghiányos', 'rossz', 'közepes vörös barna kék', 'imád aludni', 1, 0, '2021-02-15 00:00:00', '/www_tappancs_hu/66.jpg'),
(26, 'Horka', '2015-10-24', 8, 'kan', 'Yorkshire terrier', 'közepes', 0, 24, 'fogszuvas', 'egészséges', 'kicsi foltos rózsaszín barna', 'szeret ölelni', 1, 0, '2023-05-25 00:00:00', '/www_tappancs_hu/26.jpg'),
(27, 'Boomer', '2018-08-01', 5, 'szuka', 'Közép uszkár', 'rossz', 0, 28, 'egészséges', 'rossz', 'közepes foltos sötétbarna kék', 'szeret sétálni a parkban', 1, 0, '2022-08-14 00:00:00', '/www_tappancs_hu/39.jpg'),
(28, 'Maya', '2019-09-25', 4, 'kan', 'Saarloosi farkaskutya', 'rossz', 0, 19, 'foghiányos', 'rossz', 'nagy foltos rózsaszín kék', 'kedves és barátságos', 1, 0, '2022-12-10 00:00:00', '/www_tappancs_hu/132.jpg'),
(29, 'Darling', '2017-12-28', 6, 'szuka', 'Kelet-szibériai lajka', 'egészséges', 1, 19, 'egészséges', 'egészséges', 'közepes tigriscsíkos barna barna', 'szeret ölelni', 1, 0, '2022-06-25 00:00:00', '/www_tappancs_hu/12.jpg'),
(30, 'Rolf', '2016-01-27', 7, 'szuka', 'Saage kochee', 'rossz', 0, 13, 'foghiányos', 'rossz', 'nagy fehér sötétbarna kék', 'szeret játszani', 1, 0, '2022-07-15 00:00:00', '/www_tappancs_hu/71.jpg'),
(31, 'Sakál', '2017-05-04', 6, 'kan', 'Norvég lundehund', 'rossz', 1, 7, 'egészséges', 'egészséges', 'kicsi barna sötétbarna zöld', 'szeret játszani', 1, 0, '2021-07-08 00:00:00', '/www_tappancs_hu/0.jpg'),
(32, 'Leó', '2019-10-16', 4, 'szuka', 'Wetterhoun', 'egészséges', 1, 30, 'egészséges', 'rossz', 'nagy sárga barna kék', 'szeret fürdeni a tóban', 1, 0, '2021-07-16 00:00:00', '/www_tappancs_hu/134.jpg'),
(33, 'Chilli', '2019-06-14', 4, 'kan', 'Beagle harrier', 'rossz', 1, 20, 'egészséges', 'egészséges', 'nagy szürke barna zöld', 'szeret az ablakban ülni', 1, 0, '2022-01-15 00:00:00', '/www_tappancs_hu/168.jpg'),
(34, 'Melák', '2017-09-25', 6, 'szuka', 'Drenti vizsla', 'rossz', 0, 22, 'egészséges', 'közepes', 'kicsi tigriscsíkos vörös kék', 'be van gyulladva a füle', 1, 0, '2022-08-15 00:00:00', '/www_tappancs_hu/1.jpg'),
(35, 'Gingy', '2020-08-18', 3, 'kan', 'Skót terrier', 'egészséges', 0, 24, 'foghiányos', 'közepes', 'kicsi tigriscsíkos barna barna', 'szeret úszni', 1, 0, '2022-02-22 00:00:00', '/www_tappancs_hu/150.jpg'),
(36, 'Zsüti', '2015-05-12', 8, 'kan', 'bolonka cvetna', 'rossz', 0, 15, 'fogszuvas', 'egészséges', 'nagy arany barna barna', 'bélférges', 1, 0, '2021-10-19 00:00:00', '/www_tappancs_hu/101.jpg'),
(37, 'Jimmy', '2019-12-04', 4, 'szuka', 'Eszkimó kutya', 'egészséges', 1, 11, 'fogszuvas', 'közepes', 'nagy fekete fekete kék', 'imád aludni', 1, 0, '2022-11-20 00:00:00', '/www_tappancs_hu/113.jpg'),
(38, 'Suzy', '2018-12-23', 5, 'kan', 'Kínai kopasz kutya', 'rossz', 0, 12, 'foghiányos', 'közepes', 'közepes fekete rózsaszín barna', 'szeret labdázni', 1, 0, '2022-04-20 00:00:00', '/www_tappancs_hu/33.jpg'),
(39, 'Lucy', '2018-09-04', 5, 'szuka', 'Német fürjészeb', 'rossz', 1, 27, 'egészséges', 'rossz', 'közepes arany barna barna', 'szeret játszani', 1, 0, '2022-05-25 00:00:00', '/www_tappancs_hu/135.jpg'),
(40, 'Sámson', '2017-03-21', 6, 'kan', 'Hortaye Borzaya (Chortaj)', 'egészséges', 1, 13, 'egészséges', 'közepes', 'nagy barna rózsaszín zöld', 'szeret játszani', 1, 0, '2021-10-20 00:00:00', '/www_tappancs_hu/11.jpg'),
(41, 'Inzy', '2018-12-05', 5, 'kan', 'Máltai selyemkutya', 'egészséges', 1, 3, 'foghiányos', 'rossz', 'nagy szürke vörös zöld', 'szeret játszani a labdával', 1, 0, '2021-11-08 00:00:00', '/www_tappancs_hu/115.jpg'),
(42, 'Gadget', '2016-03-21', 7, 'szuka', 'Trikolor francia kopó', 'közepes', 1, 10, 'foghiányos', 'egészséges', 'kicsi fekete fekete kék', 'szeret az ablakban ülni', 1, 0, '2021-11-23 00:00:00', '/www_tappancs_hu/6.jpg'),
(43, 'Mazsola', '2015-10-05', 8, 'kan', 'Nagy angol-francia kopó', 'közepes', 1, 22, 'egészséges', 'rossz', 'kicsi arany vörös barna', 'szeret úszni', 1, 0, '2021-10-07 00:00:00', '/www_tappancs_hu/79.jpg'),
(44, 'Adél', '2017-10-04', 6, 'szuka', 'Kromfohrlandi', 'egészséges', 1, 21, 'foghiányos', 'egészséges', 'kicsi fekete rózsaszín barna', 'szeret kutyakölykökkel játszani', 1, 0, '2021-04-11 00:00:00', '/www_tappancs_hu/86.jpg'),
(45, 'Alfonz', '2017-12-25', 6, 'szuka', 'Estrelai hegyikutya', 'egészséges', 1, 1, 'egészséges', 'egészséges', 'nagy sárga vörös zöld', 'szeret az ablakban ülni', 1, 0, '2022-06-18 00:00:00', '/www_tappancs_hu/191.jpg'),
(46, 'Rejtély', '2018-09-16', 5, 'szuka', 'Bukovinai pásztorkutya', 'rossz', 0, 30, 'foghiányos', 'rossz', 'kicsi barna fekete kék', 'szeret fürdeni a tóban', 1, 0, '2023-08-10 00:00:00', '/www_tappancs_hu/22.jpg'),
(47, 'Suhanc', '2018-04-04', 5, 'szuka', 'Dobermann', 'közepes', 1, 25, 'fogszuvas', 'rossz', 'nagy vörös rózsaszín zöld', 'szeret kutyakölykökkel játszani', 1, 0, '2021-06-27 00:00:00', '/www_tappancs_hu/7.jpg'),
(48, 'Jumbó', '2017-08-01', 6, 'szuka', 'Vidrakopó', 'közepes', 1, 7, 'foghiányos', 'egészséges', 'kicsi sárga sötétbarna barna', 'be van gyulladva a füle', 1, 0, '2022-10-09 00:00:00', '/www_tappancs_hu/21.jpg'),
(49, 'Polli', '2020-10-22', 3, 'szuka', 'Jämthund', 'rossz', 0, 9, 'fogszuvas', 'egészséges', 'nagy tigriscsíkos barna kék', 'szeret játszani', 1, 0, '2021-05-19 00:00:00', '/www_tappancs_hu/57.jpg'),
(50, 'Ádáz', '2015-09-11', 8, 'kan', 'Nápolyi masztiff', 'rossz', 1, 3, 'fogszuvas', 'közepes', 'nagy szürke sötétbarna kék', 'több mozgást igényel', 1, 0, '2021-08-17 00:00:00', '/www_tappancs_hu/46.jpg'),
(51, 'Askim', '2016-04-14', 7, 'szuka', 'Kánaán kutya', 'közepes', 1, 26, 'fogszuvas', 'egészséges', 'közepes arany vörös kék', 'szeret nyugodtan pihenni', 1, 0, '2022-06-13 00:00:00', '/www_tappancs_hu/38.jpg'),
(52, 'Bogáncs', '2018-01-11', 5, 'szuka', 'Alaszkai malamut', 'közepes', 0, 28, 'egészséges', 'rossz', 'nagy fekete vörös barna', 'bélférges', 1, 0, '2023-02-03 00:00:00', '/www_tappancs_hu/152.jpg'),
(53, 'Nyikita', '2017-05-08', 6, 'kan', 'Leonbergi', 'egészséges', 0, 9, 'fogszuvas', 'rossz', 'nagy barna vörös zöld', 'köröm vágást igényel', 1, 0, '2022-05-23 00:00:00', '/www_tappancs_hu/146.jpg'),
(54, 'Kevin', '2015-02-16', 8, 'szuka', 'Cavalier King Charles spániel', 'egészséges', 0, 2, 'fogszuvas', 'közepes', 'nagy fehér rózsaszín barna', 'szeret az ablakban ülni', 1, 0, '2021-07-19 00:00:00', '/www_tappancs_hu/122.jpg'),
(55, 'Jágó', '2016-11-11', 7, 'szuka', 'Törpe uszkár', 'közepes', 1, 24, 'fogszuvas', 'közepes', 'közepes fekete barna kék', 'bélférges', 1, 0, '2022-09-23 00:00:00', '/www_tappancs_hu/14.jpg'),
(56, 'Szeszi', '2015-06-22', 8, 'kan', 'Törpe pinscher', 'közepes', 1, 6, 'foghiányos', 'egészséges', 'közepes arany barna zöld', 'bélférges', 1, 0, '2021-01-20 00:00:00', '/www_tappancs_hu/139.jpg'),
(57, 'Lexi', '2018-07-09', 5, 'szuka', 'Halden kopó', 'rossz', 0, 25, 'egészséges', 'egészséges', 'kicsi arany barna zöld', 'kedveli a sétákat', 1, 0, '2021-04-13 00:00:00', '/www_tappancs_hu/47.jpg'),
(58, 'Bohém', '2017-05-03', 6, 'szuka', 'Kánaán kutya', 'rossz', 1, 16, 'fogszuvas', 'rossz', 'közepes tigriscsíkos vörös zöld', 'köröm vágást igényel', 1, 0, '2021-08-01 00:00:00', '/www_tappancs_hu/195.jpg'),
(59, 'Pongó', '2016-09-24', 7, 'szuka', 'Nagy angol-francia kopó', 'közepes', 0, 3, 'fogszuvas', 'rossz', 'kicsi sárga vörös barna', 'szeret játszani', 1, 0, '2021-09-08 00:00:00', '/www_tappancs_hu/1.jpg'),
(60, 'Nessy', '2019-06-07', 4, 'kan', 'Halden kopó', 'közepes', 0, 2, 'fogszuvas', 'egészséges', 'nagy szürke sötétbarna kék', 'szeret játszani', 1, 0, '2023-09-11 00:00:00', '/www_tappancs_hu/57.jpg'),
(61, 'Adolf', '2016-04-25', 7, 'szuka', 'Drótszőrű griffon', 'egészséges', 1, 12, 'egészséges', 'közepes', 'nagy arany sötétbarna kék', 'szeret az ablakban ülni', 1, 0, '2023-04-17 00:00:00', '/www_tappancs_hu/83.jpg'),
(62, 'Maya', '2018-02-01', 5, 'kan', 'Kromfohrlandi', 'egészséges', 1, 14, 'fogszuvas', 'rossz', 'nagy foltos barna kék', 'köröm vágást igényel', 1, 0, '2023-01-22 00:00:00', '/www_tappancs_hu/156.jpg'),
(63, 'Pamacs', '2020-03-02', 3, 'kan', 'Shar pei', 'egészséges', 1, 15, 'egészséges', 'rossz', 'közepes fehér sötétbarna zöld', 'szeret futkosni a kertben', 1, 0, '2022-01-13 00:00:00', '/www_tappancs_hu/136.jpg'),
(64, 'Oszkár', '2018-09-25', 5, 'szuka', 'Izlandi juhászkutya', 'közepes', 0, 6, 'foghiányos', 'egészséges', 'közepes szürke fekete kék', 'szeret kutyakölykökkel játszani', 1, 0, '2022-03-04 00:00:00', '/www_tappancs_hu/95.jpg'),
(65, 'Melák', '2017-05-14', 6, 'szuka', 'Mioritic pásztorkutya', 'rossz', 0, 5, 'foghiányos', 'rossz', 'nagy fehér rózsaszín zöld', 'szeret játszani', 1, 0, '2023-10-09 00:00:00', '/www_tappancs_hu/80.jpg'),
(66, 'Jázmina', '2020-10-02', 3, 'kan', 'Amerikai akita inu', 'egészséges', 1, 5, 'foghiányos', 'közepes', 'közepes barna fekete kék', 'imád aludni', 1, 0, '2022-04-16 00:00:00', '/www_tappancs_hu/8.jpg'),
(67, 'Lilla', '2019-04-08', 4, 'kan', 'Kis berni kopó', 'egészséges', 0, 3, 'foghiányos', 'egészséges', 'nagy sárga rózsaszín barna', 'köröm vágást igényel', 1, 0, '2023-09-15 00:00:00', '/www_tappancs_hu/181.jpg'),
(68, 'Keksz', '2018-07-16', 5, 'kan', 'Szerb trikolor kopó', 'rossz', 0, 10, 'egészséges', 'közepes', 'közepes fekete sötétbarna zöld', 'szeret labdázni', 1, 0, '2021-04-12 00:00:00', '/www_tappancs_hu/56.jpg'),
(69, 'Jimmy', '2018-04-07', 5, 'kan', 'Nagy münsterlandi vizsla', 'rossz', 0, 29, 'egészséges', 'közepes', 'kicsi fekete fekete zöld', 'szeret úszni', 1, 0, '2023-01-05 00:00:00', '/www_tappancs_hu/55.jpg'),
(70, 'Milli', '2019-07-28', 4, 'kan', 'Mallorcai pásztorkutya', 'rossz', 1, 10, 'fogszuvas', 'egészséges', 'kicsi szürke vörös zöld', 'szeret sétálni a parkban', 1, 0, '2021-05-04 00:00:00', '/www_tappancs_hu/0.jpg'),
(71, 'Mackó', '2016-11-05', 7, 'kan', 'Gascogne-i kék basset', 'egészséges', 1, 10, 'egészséges', 'rossz', 'nagy sárga sötétbarna zöld', 'szeret úszni', 1, 0, '2023-01-17 00:00:00', '/www_tappancs_hu/106.jpg'),
(72, 'Afton', '2016-08-22', 7, 'kan', 'Szlovák kopó', 'közepes', 0, 27, 'egészséges', 'közepes', 'közepes szürke rózsaszín zöld', 'szeret labdázni', 1, 0, '2022-01-19 00:00:00', '/www_tappancs_hu/128.jpg'),
(73, 'Rea', '2018-12-08', 5, 'szuka', 'Magyar agár', 'közepes', 1, 19, 'foghiányos', 'rossz', 'nagy szürke rózsaszín zöld', 'szeret játszani a labdával', 1, 0, '2023-02-01 00:00:00', '/www_tappancs_hu/126.jpg'),
(74, 'Adonisz', '2016-09-01', 7, 'szuka', 'Halden kopó', 'közepes', 0, 7, 'egészséges', 'közepes', 'közepes sárga rózsaszín barna', 'imád aludni', 1, 0, '2021-03-01 00:00:00', '/www_tappancs_hu/88.jpg'),
(75, 'Plutó', '2015-05-05', 8, 'szuka', 'Field spániel', 'egészséges', 1, 29, 'fogszuvas', 'egészséges', 'nagy sárga sötétbarna kék', 'szeret kutyakölykökkel játszani', 1, 0, '2021-12-28 00:00:00', '/www_tappancs_hu/59.jpg'),
(76, 'Jázmina', '2015-08-26', 8, 'szuka', 'Kánaán kutya', 'rossz', 0, 28, 'foghiányos', 'rossz', 'közepes foltos fekete kék', 'imád aludni', 1, 0, '2022-02-08 00:00:00', '/www_tappancs_hu/175.jpg'),
(77, 'Pénzecske', '2018-09-03', 5, 'szuka', 'Fekete-cser mosómedvekopó', 'egészséges', 1, 28, 'egészséges', 'rossz', 'kicsi barna fekete kék', 'szeret úszni', 1, 0, '2021-01-02 00:00:00', '/www_tappancs_hu/24.jpg'),
(78, 'Piszok', '2020-02-17', 3, 'kan', 'Skót terrier', 'egészséges', 1, 8, 'egészséges', 'közepes', 'kicsi arany vörös kék', 'szeret fürdeni a tóban', 1, 0, '2023-11-24 00:00:00', '/www_tappancs_hu/14.jpg'),
(79, 'Kelly', '2017-05-05', 6, 'szuka', 'Portugál kopó', 'közepes', 0, 21, 'egészséges', 'egészséges', 'nagy szürke barna kék', 'szeret kutyakölykökkel játszani', 1, 0, '2021-03-22 00:00:00', '/www_tappancs_hu/92.jpg'),
(80, 'Pongó', '2015-05-23', 8, 'szuka', 'Spanyol masztiff', 'rossz', 0, 8, 'egészséges', 'közepes', 'nagy fehér sötétbarna kék', 'szeret kutyakölykökkel játszani', 1, 0, '2023-03-17 00:00:00', '/www_tappancs_hu/100.jpg'),
(81, 'Adonisz', '2016-06-19', 7, 'szuka', 'Német vizsla', 'rossz', 1, 21, 'foghiányos', 'egészséges', 'közepes szürke vörös zöld', 'köröm vágást igényel', 1, 0, '2021-03-04 00:00:00', '/www_tappancs_hu/23.jpg'),
(82, 'Ollé', '2016-11-27', 7, 'szuka', 'Norvég lundehund', 'egészséges', 1, 14, 'egészséges', 'közepes', 'közepes tigriscsíkos rózsaszín kék', 'több mozgást igényel', 1, 0, '2022-04-18 00:00:00', '/www_tappancs_hu/162.jpg'),
(83, 'Anasztázia', '2020-05-03', 3, 'kan', 'Törpe schnauzer', 'közepes', 0, 12, 'egészséges', 'egészséges', 'közepes sárga rózsaszín kék', 'kedves és barátságos', 1, 0, '2023-07-09 00:00:00', '/www_tappancs_hu/85.jpg'),
(84, 'Adonisz', '2020-07-23', 3, 'kan', 'Spániel', 'közepes', 1, 3, 'egészséges', 'egészséges', 'nagy barna sötétbarna zöld', 'több mozgást igényel', 1, 0, '2021-10-07 00:00:00', '/www_tappancs_hu/156.jpg'),
(85, 'Zizi', '2019-04-05', 4, 'szuka', 'Hokkaido inu', 'közepes', 0, 20, 'egészséges', 'rossz', 'nagy szürke fekete zöld', 'szeret labdázni', 1, 0, '2023-09-01 00:00:00', '/www_tappancs_hu/182.jpg'),
(86, 'Pitti', '2019-11-05', 4, 'kan', 'Cirneco dell’Etna', 'egészséges', 0, 3, 'egészséges', 'egészséges', 'nagy vörös rózsaszín kék', 'több mozgást igényel', 1, 0, '2023-05-06 00:00:00', '/www_tappancs_hu/67.jpg'),
(87, 'Espresso', '2016-10-04', 7, 'kan', 'Nyugat-szibériai lajka', 'egészséges', 1, 17, 'fogszuvas', 'egészséges', 'kicsi arany vörös kék', 'kedveli a sétákat', 1, 0, '2021-11-17 00:00:00', '/www_tappancs_hu/71.jpg'),
(88, 'Magnipuss', '2018-08-06', 5, 'kan', 'Ariége-i vizsla', 'közepes', 0, 27, 'foghiányos', 'rossz', 'nagy sárga fekete kék', 'be van gyulladva a füle', 1, 0, '2022-03-13 00:00:00', '/www_tappancs_hu/37.jpg'),
(89, 'Wolf', '2019-11-05', 4, 'szuka', 'Breton spániel', 'rossz', 0, 13, 'egészséges', 'közepes', 'nagy sárga fekete zöld', 'szeret nyugodtan pihenni', 1, 0, '2022-03-28 00:00:00', '/www_tappancs_hu/98.jpg'),
(90, 'Pongó', '2018-05-05', 5, 'kan', 'Olasz kopó', 'közepes', 1, 7, 'egészséges', 'rossz', 'kicsi foltos vörös kék', 'szeret labdázni', 1, 0, '2022-11-23 00:00:00', '/www_tappancs_hu/152.jpg'),
(91, 'Kuku', '2019-08-22', 4, 'szuka', 'Hosszúszőrű német vizsla', 'közepes', 0, 6, 'foghiányos', 'rossz', 'nagy fehér vörös zöld', 'kedves és barátságos', 1, 0, '2021-10-13 00:00:00', '/www_tappancs_hu/56.jpg'),
(92, 'Kefir', '2015-08-03', 8, 'szuka', 'Cardigan welsh corgi', 'egészséges', 0, 13, 'egészséges', 'közepes', 'kicsi tigriscsíkos barna barna', 'kedves és barátságos', 1, 0, '2023-03-22 00:00:00', '/www_tappancs_hu/17.jpg'),
(93, 'Ádáz', '2018-07-04', 5, 'szuka', 'Tátrai juhászkutya', 'közepes', 0, 29, 'foghiányos', 'közepes', 'közepes fekete barna barna', 'szeret ölelni', 1, 0, '2022-02-12 00:00:00', '/www_tappancs_hu/204.jpg'),
(94, 'Ollé', '2018-05-11', 5, 'kan', 'Kuvasz  Magyarország', 'rossz', 0, 2, 'fogszuvas', 'egészséges', 'közepes sárga vörös zöld', 'imád aludni', 1, 0, '2021-12-10 00:00:00', '/www_tappancs_hu/124.jpg'),
(95, 'Csülök', '2019-07-25', 4, 'kan', 'Angol juhászkutya', 'rossz', 0, 25, 'egészséges', 'egészséges', 'nagy tigriscsíkos barna barna', 'szeret labdázni', 1, 0, '2023-07-22 00:00:00', '/www_tappancs_hu/206.jpg'),
(96, 'Pedró', '2019-08-06', 4, 'szuka', 'Közép schnauzer', 'egészséges', 1, 14, 'egészséges', 'rossz', 'nagy tigriscsíkos sötétbarna barna', 'szeret az ablakban ülni', 1, 0, '2021-02-24 00:00:00', '/www_tappancs_hu/15.jpg'),
(97, 'Nyikita', '2017-12-10', 6, 'kan', 'Lagotto romagnolo', 'rossz', 1, 11, 'fogszuvas', 'rossz', 'kicsi fekete sötétbarna barna', 'szeret fürdeni a tóban', 1, 0, '2022-09-08 00:00:00', '/www_tappancs_hu/23.jpg'),
(98, 'Jet', '2015-10-19', 8, 'szuka', 'Német pinscher', 'egészséges', 0, 25, 'fogszuvas', 'egészséges', 'kicsi szürke fekete kék', 'több mozgást igényel', 1, 0, '2022-05-19 00:00:00', '/www_tappancs_hu/208.jpg'),
(99, 'Oblix', '2016-09-20', 7, 'szuka', 'Holland juhászkutya', 'rossz', 1, 11, 'egészséges', 'közepes', 'kicsi barna vörös zöld', 'szeret sétálni a parkban', 1, 0, '2022-02-22 00:00:00', '/www_tappancs_hu/37.jpg'),
(100, 'Jockey', '2020-11-27', 3, 'kan', 'Porcelánkopó', 'közepes', 0, 25, 'egészséges', 'közepes', 'kicsi sárga barna barna', 'bélférges', 1, 0, '2022-12-20 00:00:00', '/www_tappancs_hu/66.jpg'),
(101, 'Kenny', '2015-01-27', 8, 'szuka', 'Airedale terrier', 'rossz', 1, 16, 'egészséges', 'egészséges', 'kicsi barna vörös barna', 'kedves és barátságos', 1, 0, '2021-03-17 00:00:00', '/www_tappancs_hu/57.jpg'),
(102, 'Kai', '2016-11-09', 7, 'szuka', 'Black mouth cur', 'rossz', 1, 11, 'egészséges', 'közepes', 'nagy vörös sötétbarna zöld', 'szeret játszani', 1, 0, '2021-12-26 00:00:00', '/www_tappancs_hu/123.jpg'),
(103, 'Fló', '2016-11-15', 7, 'kan', 'Amerikai vízispániel', 'közepes', 0, 19, 'egészséges', 'rossz', 'kicsi szürke fekete zöld', 'kedves és barátságos', 1, 0, '2022-10-26 00:00:00', '/www_tappancs_hu/29.jpg'),
(104, 'Károly', '2016-10-26', 7, 'szuka', 'Nagy svájci havasi kutya', 'közepes', 0, 4, 'fogszuvas', 'rossz', 'nagy arany rózsaszín kék', 'szeret nyugodtan pihenni', 1, 0, '2022-09-05 00:00:00', '/www_tappancs_hu/39.jpg'),
(105, 'Fló', '2020-08-07', 3, 'kan', 'Drótszőrű német vizsla', 'egészséges', 1, 25, 'fogszuvas', 'rossz', 'nagy fehér barna kék', 'szeret játszani', 1, 0, '2021-05-08 00:00:00', '/www_tappancs_hu/132.jpg'),
(106, 'Rüszi', '2017-06-19', 6, 'szuka', 'Brabançon', 'rossz', 1, 10, 'foghiányos', 'egészséges', 'közepes barna barna barna', 'szeret labdázni', 1, 0, '2021-02-11 00:00:00', '/www_tappancs_hu/105.jpg'),
(107, 'Sonny', '2015-03-01', 8, 'kan', 'Mallorcai masztiff', 'egészséges', 0, 30, 'fogszuvas', 'egészséges', 'kicsi fehér sötétbarna kék', 'kedves és barátságos', 1, 0, '2022-09-23 00:00:00', '/www_tappancs_hu/6.jpg'),
(108, 'Izabell', '2018-05-17', 5, 'kan', 'Welsh springer spániel', 'rossz', 0, 1, 'fogszuvas', 'egészséges', 'kicsi arany sötétbarna barna', 'bélférges', 1, 0, '2021-09-24 00:00:00', '/www_tappancs_hu/204.jpg'),
(109, 'Elza', '2017-01-27', 6, 'kan', 'Afgán agár', 'rossz', 0, 19, 'egészséges', 'egészséges', 'közepes barna rózsaszín kék', 'kedveli a sétákat', 1, 0, '2023-06-16 00:00:00', '/www_tappancs_hu/55.jpg'),
(110, 'Behemót', '2017-11-25', 6, 'szuka', 'Brie-i juhászkutya', 'rossz', 0, 30, 'fogszuvas', 'rossz', 'kicsi barna barna kék', 'szeret játszani a labdával', 1, 0, '2021-09-08 00:00:00', '/www_tappancs_hu/189.jpg'),
(111, 'Gerry', '2015-10-11', 8, 'kan', 'Nagy svájci havasi kutya', 'egészséges', 1, 11, 'fogszuvas', 'egészséges', 'kicsi foltos rózsaszín barna', 'szeret futkosni a kertben', 1, 0, '2023-01-05 00:00:00', '/www_tappancs_hu/90.jpg'),
(112, 'Téra', '2017-03-03', 6, 'kan', 'Alentejo masztiff', 'egészséges', 1, 6, 'egészséges', 'rossz', 'nagy tigriscsíkos sötétbarna zöld', 'szeret kutyakölykökkel játszani', 1, 0, '2021-03-27 00:00:00', '/www_tappancs_hu/156.jpg'),
(113, 'Morti', '2015-07-06', 8, 'kan', 'Nagy svájci havasi kutya', 'egészséges', 1, 7, 'foghiányos', 'közepes', 'kicsi szürke fekete zöld', 'köröm vágást igényel', 1, 0, '2022-07-12 00:00:00', '/www_tappancs_hu/124.jpg'),
(114, 'Inzy', '2020-08-22', 3, 'kan', 'Brie-i juhászkutya', 'közepes', 0, 23, 'fogszuvas', 'egészséges', 'kicsi foltos sötétbarna barna', 'több mozgást igényel', 1, 0, '2022-05-25 00:00:00', '/www_tappancs_hu/148.jpg'),
(115, 'Cézár', '2015-07-24', 8, 'kan', 'Szlovák kopó', 'egészséges', 0, 26, 'foghiányos', 'közepes', 'közepes fekete fekete zöld', 'szeret ölelni', 1, 0, '2023-02-09 00:00:00', '/www_tappancs_hu/107.jpg'),
(116, 'Fáraó', '2018-11-19', 5, 'kan', 'Hosszúszőrű német vizsla', 'rossz', 0, 28, 'egészséges', 'egészséges', 'kicsi tigriscsíkos sötétbarna zöld', 'szeret sétálni a parkban', 1, 0, '2022-08-14 00:00:00', '/www_tappancs_hu/167.jpg'),
(117, 'Anasztázia', '2020-06-20', 3, 'kan', 'Szlovák kopó', 'rossz', 0, 6, 'fogszuvas', 'közepes', 'közepes szürke vörös barna', 'szeret nyugodtan pihenni', 1, 0, '2021-02-22 00:00:00', '/www_tappancs_hu/146.jpg'),
(118, 'Melák', '2016-03-10', 7, 'kan', 'Tosza inu', 'rossz', 1, 23, 'egészséges', 'egészséges', 'közepes szürke barna kék', 'be van gyulladva a füle', 1, 0, '2021-05-07 00:00:00', '/www_tappancs_hu/138.jpg'),
(119, 'Rénó', '2020-12-04', 3, 'kan', 'Kaliba kutya', 'rossz', 1, 28, 'foghiányos', 'közepes', 'kicsi szürke vörös barna', 'kedves és barátságos', 1, 0, '2022-04-28 00:00:00', '/www_tappancs_hu/193.jpg'),
(120, 'Mézeske', '2016-02-12', 7, 'kan', 'Rövidszőrű magyar vizsla', 'rossz', 0, 1, 'egészséges', 'egészséges', 'kicsi fekete vörös barna', 'szeret nyugodtan pihenni', 1, 0, '2021-01-21 00:00:00', '/www_tappancs_hu/48.jpg'),
(121, 'Lulu', '2017-06-23', 6, 'szuka', 'Halden kopó', 'rossz', 1, 22, 'foghiányos', 'egészséges', 'kicsi szürke rózsaszín kék', 'be van gyulladva a füle', 1, 0, '2023-09-12 00:00:00', '/www_tappancs_hu/34.jpg'),
(122, 'Kelly', '2015-05-19', 8, 'kan', 'Phu-quoc kutya', 'közepes', 0, 16, 'egészséges', 'egészséges', 'közepes szürke fekete barna', 'szeret nyugodtan pihenni', 1, 0, '2021-08-25 00:00:00', '/www_tappancs_hu/64.jpg'),
(123, 'Scott', '2018-08-15', 5, 'kan', 'Közép schnauzer', 'közepes', 0, 19, 'fogszuvas', 'rossz', 'nagy vörös vörös barna', 'imád aludni', 1, 0, '2023-10-01 00:00:00', '/www_tappancs_hu/55.jpg'),
(124, 'Orlando', '2018-04-17', 5, 'kan', 'Longdog', 'egészséges', 1, 30, 'fogszuvas', 'rossz', 'nagy fekete rózsaszín zöld', 'szeret labdázni', 1, 0, '2021-03-09 00:00:00', '/www_tappancs_hu/172.jpg'),
(125, 'Chilli', '2015-03-04', 8, 'kan', 'Harlekin pincser', 'rossz', 0, 9, 'foghiányos', 'rossz', 'kicsi arany rózsaszín kék', 'szeret játszani', 1, 0, '2021-04-23 00:00:00', '/www_tappancs_hu/10.jpg'),
(126, 'Bajnok', '2017-03-10', 6, 'kan', 'Portugál vizsla', 'egészséges', 1, 7, 'egészséges', 'rossz', 'közepes fehér rózsaszín barna', 'több mozgást igényel', 1, 0, '2021-12-17 00:00:00', '/www_tappancs_hu/44.jpg'),
(127, 'Lili', '2016-03-14', 7, 'szuka', 'Angol rókakopó', 'egészséges', 0, 25, 'fogszuvas', 'közepes', 'közepes szürke fekete zöld', 'több mozgást igényel', 1, 0, '2021-08-08 00:00:00', '/www_tappancs_hu/197.jpg'),
(128, 'Vacak', '2017-02-08', 6, 'kan', 'Katalán pásztorkutya', 'közepes', 1, 29, 'fogszuvas', 'rossz', 'nagy vörös vörös barna', 'szeret az ablakban ülni', 1, 0, '2023-06-25 00:00:00', '/www_tappancs_hu/107.jpg'),
(129, 'Adolf', '2018-05-27', 5, 'szuka', 'Vörös ír szetter', 'rossz', 0, 19, 'egészséges', 'egészséges', 'kicsi vörös rózsaszín zöld', 'szeret nyugodtan pihenni', 1, 0, '2021-05-02 00:00:00', '/www_tappancs_hu/74.jpg'),
(130, 'Téra', '2018-10-24', 5, 'szuka', 'Csau csau', 'közepes', 1, 1, 'fogszuvas', 'rossz', 'kicsi arany fekete barna', 'szeret labdázni', 1, 0, '2023-05-19 00:00:00', '/www_tappancs_hu/89.jpg'),
(131, 'Iván', '2015-12-11', 8, 'szuka', 'Montenegrói hegyikopó', 'egészséges', 0, 2, 'egészséges', 'rossz', 'közepes fekete barna barna', 'szeret ölelni', 1, 0, '2022-10-18 00:00:00', '/www_tappancs_hu/164.jpg'),
(132, 'Pamacs', '2018-11-18', 5, 'kan', 'Staffordshire bullterrier', 'közepes', 1, 24, 'foghiányos', 'közepes', 'közepes arany barna barna', 'szeret futkosni a kertben', 1, 0, '2023-06-21 00:00:00', '/www_tappancs_hu/27.jpg'),
(133, 'Zafír', '2020-06-15', 3, 'szuka', 'Kerry blue terrier', 'közepes', 0, 22, 'egészséges', 'közepes', 'nagy fekete vörös barna', 'több mozgást igényel', 1, 0, '2023-08-16 00:00:00', '/www_tappancs_hu/120.jpg'),
(134, 'Gerry', '2016-01-25', 7, 'szuka', 'Montenegrói hegyikopó', 'egészséges', 1, 4, 'fogszuvas', 'egészséges', 'kicsi fekete sötétbarna barna', 'szeret játszani a labdával', 1, 0, '2021-11-06 00:00:00', '/www_tappancs_hu/181.jpg'),
(135, 'Fifi', '2019-09-22', 4, 'szuka', 'Holland juhászkutya', 'egészséges', 0, 12, 'foghiányos', 'közepes', 'kicsi arany fekete zöld', 'bélférges', 1, 0, '2021-01-07 00:00:00', '/www_tappancs_hu/185.jpg'),
(136, 'Ollé', '2019-03-22', 4, 'szuka', 'Lancashire heeler', 'közepes', 1, 24, 'fogszuvas', 'egészséges', 'nagy fehér fekete barna', 'szeret játszani', 1, 0, '2021-10-12 00:00:00', '/www_tappancs_hu/79.jpg'),
(137, 'Mazsola', '2016-10-27', 7, 'szuka', 'Kromfohrlandi', 'rossz', 1, 11, 'egészséges', 'rossz', 'kicsi tigriscsíkos barna zöld', 'szeret az ablakban ülni', 1, 0, '2022-02-09 00:00:00', '/www_tappancs_hu/34.jpg'),
(138, 'Szofi', '2016-08-02', 7, 'szuka', 'Broholmer', 'közepes', 0, 30, 'egészséges', 'közepes', 'közepes arany barna kék', 'szeret úszni', 1, 0, '2022-08-19 00:00:00', '/www_tappancs_hu/205.jpg'),
(139, 'Jabba', '2020-04-25', 3, 'szuka', 'Katalán pásztorkutya', 'egészséges', 1, 10, 'egészséges', 'közepes', 'közepes tigriscsíkos sötétbarna barna', 'bélférges', 1, 0, '2022-02-13 00:00:00', '/www_tappancs_hu/125.jpg'),
(140, 'Terry', '2015-02-14', 8, 'szuka', 'Kínai kopasz kutya', 'közepes', 1, 9, 'fogszuvas', 'közepes', 'nagy sárga fekete kék', 'szeret ölelni', 1, 0, '2023-07-18 00:00:00', '/www_tappancs_hu/157.jpg'),
(141, 'Téra', '2020-01-13', 3, 'szuka', 'Patterdale terrier', 'közepes', 0, 11, 'foghiányos', 'egészséges', 'nagy szürke barna barna', 'több mozgást igényel', 1, 0, '2022-11-05 00:00:00', '/www_tappancs_hu/54.jpg'),
(142, 'Edith', '2017-10-26', 6, 'kan', 'Boerboel', 'egészséges', 1, 8, 'fogszuvas', 'egészséges', 'közepes foltos fekete barna', 'szeret fürdeni a tóban', 1, 0, '2022-10-03 00:00:00', '/www_tappancs_hu/156.jpg'),
(143, 'Bajnok', '2020-01-18', 3, 'kan', 'Ausztrál pásztorkutya', 'egészséges', 1, 13, 'egészséges', 'rossz', 'közepes arany rózsaszín kék', 'kedveli a sétákat', 1, 0, '2023-07-04 00:00:00', '/www_tappancs_hu/9.jpg'),
(144, 'Kleó', '2020-02-07', 3, 'kan', 'Vendée-i griffonkopó', 'rossz', 0, 26, 'fogszuvas', 'rossz', 'közepes tigriscsíkos sötétbarna barna', 'szeret futkosni a kertben', 1, 0, '2022-11-08 00:00:00', '/www_tappancs_hu/43.jpg'),
(145, 'Szerecsendió', '2019-09-23', 4, 'kan', 'Rövidszőrű skót juhászkutya', 'rossz', 0, 28, 'fogszuvas', 'közepes', 'nagy arany rózsaszín zöld', 'szeret játszani', 1, 0, '2023-05-16 00:00:00', '/www_tappancs_hu/141.jpg'),
(146, 'Nina', '2019-08-09', 4, 'kan', 'Jack Russell terrier', 'egészséges', 0, 22, 'fogszuvas', 'közepes', 'kicsi foltos barna zöld', 'kedveli a sétákat', 1, 0, '2021-04-05 00:00:00', '/www_tappancs_hu/155.jpg'),
(147, 'Dean', '2015-12-11', 8, 'szuka', 'Berni pásztorkutya', 'rossz', 0, 20, 'fogszuvas', 'közepes', 'kicsi tigriscsíkos sötétbarna barna', 'szeret az ablakban ülni', 1, 0, '2022-10-23 00:00:00', '/www_tappancs_hu/189.jpg'),
(148, 'Igric', '2017-08-13', 6, 'kan', 'Svéd lapphund', 'egészséges', 1, 11, 'egészséges', 'közepes', 'közepes fekete barna kék', 'imád aludni', 1, 0, '2023-07-19 00:00:00', '/www_tappancs_hu/10.jpg'),
(149, 'Jasper', '2016-08-20', 7, 'szuka', 'Schapendoes', 'egészséges', 1, 16, 'egészséges', 'egészséges', 'kicsi tigriscsíkos barna kék', 'be van gyulladva a füle', 1, 0, '2021-10-28 00:00:00', '/www_tappancs_hu/83.jpg'),
(150, 'Pufók', '2019-08-23', 4, 'szuka', 'Félhosszúszőrű pireneusi juhászkutya', 'közepes', 1, 20, 'egészséges', 'közepes', 'közepes fekete rózsaszín kék', 'szeret labdázni', 1, 0, '2021-08-13 00:00:00', '/www_tappancs_hu/19.jpg'),
(151, 'Orchidea', '2015-12-20', 8, 'szuka', 'Tibeti terrier', 'rossz', 0, 13, 'foghiányos', 'egészséges', 'kicsi vörös sötétbarna kék', 'kedveli a sétákat', 1, 0, '2021-03-26 00:00:00', '/www_tappancs_hu/18.jpg'),
(152, 'Jázmin', '2018-07-02', 5, 'szuka', 'Chippiparai', 'egészséges', 1, 24, 'fogszuvas', 'rossz', 'közepes fehér fekete zöld', 'szeret úszni', 1, 0, '2021-12-21 00:00:00', '/www_tappancs_hu/163.jpg'),
(153, 'Fifi', '2016-09-01', 7, 'szuka', 'Amerikai eszkimó kutya', 'egészséges', 1, 21, 'egészséges', 'rossz', 'nagy szürke rózsaszín barna', 'szeret úszni', 1, 0, '2022-12-23 00:00:00', '/www_tappancs_hu/201.jpg'),
(154, 'Ballu', '2018-07-12', 5, 'kan', 'Appenzelli havasi kutya', 'rossz', 0, 8, 'foghiányos', 'közepes', 'nagy barna rózsaszín barna', 'szeret kutyakölykökkel játszani', 1, 0, '2023-08-02 00:00:00', '/www_tappancs_hu/41.jpg'),
(155, 'Amaya', '2019-04-10', 4, 'szuka', 'Cardigan welsh corgi', 'egészséges', 1, 2, 'fogszuvas', 'egészséges', 'közepes fehér vörös kék', 'kedves és barátságos', 1, 0, '2021-09-07 00:00:00', '/www_tappancs_hu/206.jpg'),
(156, 'Lili', '2016-10-11', 7, 'kan', 'Mallorcai masztiff', 'közepes', 0, 20, 'foghiányos', 'közepes', 'kicsi foltos rózsaszín zöld', 'szeret sétálni a parkban', 1, 0, '2021-08-08 00:00:00', '/www_tappancs_hu/71.jpg'),
(157, 'Tekergő', '2015-03-26', 8, 'kan', 'Szlovák kopó', 'közepes', 1, 14, 'foghiányos', 'egészséges', 'nagy arany sötétbarna kék', 'szeret labdázni', 1, 0, '2021-12-09 00:00:00', '/www_tappancs_hu/200.jpg'),
(158, 'Polli', '2016-08-05', 7, 'szuka', 'Dunker', 'egészséges', 0, 28, 'egészséges', 'egészséges', 'közepes sárga rózsaszín kék', 'szeret játszani a labdával', 1, 0, '2023-10-08 00:00:00', '/www_tappancs_hu/132.jpg'),
(159, 'Jabba', '2016-02-07', 7, 'kan', 'Isztriai kopó', 'egészséges', 1, 18, 'fogszuvas', 'rossz', 'kicsi szürke rózsaszín zöld', 'szeret futkosni a kertben', 1, 0, '2021-03-15 00:00:00', '/www_tappancs_hu/104.jpg'),
(160, 'Keiko', '2020-01-19', 3, 'kan', 'Nyugat-szibériai lajka', 'rossz', 0, 28, 'egészséges', 'rossz', 'nagy fehér rózsaszín barna', 'szeret játszani', 1, 0, '2023-10-27 00:00:00', '/www_tappancs_hu/148.jpg'),
(161, 'Jasper', '2019-10-24', 4, 'kan', 'Mexikói meztelen kutya', 'közepes', 1, 10, 'fogszuvas', 'egészséges', 'nagy foltos barna barna', 'szeret fürdeni a tóban', 1, 0, '2021-03-25 00:00:00', '/www_tappancs_hu/1.jpg'),
(162, 'Chilli', '2019-02-15', 4, 'kan', 'Stájeri drótszőrű kopó', 'közepes', 1, 3, 'foghiányos', 'rossz', 'közepes tigriscsíkos rózsaszín barna', 'szeret az ablakban ülni', 1, 0, '2022-11-24 00:00:00', '/www_tappancs_hu/53.jpg'),
(163, 'Jázmin', '2020-02-01', 3, 'szuka', 'Appenzelli havasi kutya', 'rossz', 0, 21, 'egészséges', 'rossz', 'közepes arany rózsaszín kék', 'szeret kutyakölykökkel játszani', 1, 0, '2021-07-03 00:00:00', '/www_tappancs_hu/192.jpg'),
(164, 'Behemót', '2020-03-28', 3, 'szuka', 'Szerb kopó', 'egészséges', 0, 29, 'foghiányos', 'rossz', 'nagy arany barna zöld', 'szeret játszani a labdával', 1, 0, '2022-04-16 00:00:00', '/www_tappancs_hu/107.jpg'),
(165, 'Peggi', '2016-08-09', 7, 'szuka', 'Angol juhászkutya', 'rossz', 1, 8, 'foghiányos', 'közepes', 'nagy fekete rózsaszín kék', 'szeret az ablakban ülni', 1, 0, '2022-03-03 00:00:00', '/www_tappancs_hu/176.jpg'),
(166, 'Lehár', '2017-10-18', 6, 'kan', 'Spániel', 'rossz', 1, 16, 'egészséges', 'egészséges', 'nagy barna barna zöld', 'szeret sétálni a parkban', 1, 0, '2023-01-08 00:00:00', '/www_tappancs_hu/130.jpg'),
(167, 'Jimmy', '2015-10-25', 8, 'szuka', 'Trikolor nagy angol-francia kopó', 'közepes', 1, 20, 'foghiányos', 'egészséges', 'nagy arany fekete barna', 'szeret úszni', 1, 0, '2021-02-11 00:00:00', '/www_tappancs_hu/23.jpg'),
(168, 'Neutron', '2020-11-17', 3, 'szuka', 'Kánaán kutya', 'rossz', 0, 25, 'fogszuvas', 'közepes', 'nagy sárga barna barna', 'szeret nyugodtan pihenni', 1, 0, '2022-08-23 00:00:00', '/www_tappancs_hu/33.jpg'),
(169, 'Milli', '2017-07-26', 6, 'kan', 'Patterdale terrier', 'rossz', 1, 15, 'fogszuvas', 'közepes', 'közepes fehér barna barna', 'szeret az ablakban ülni', 1, 0, '2021-11-21 00:00:00', '/www_tappancs_hu/28.jpg'),
(170, 'Orlando', '2016-01-28', 7, 'szuka', 'Francia spániel', 'egészséges', 0, 27, 'fogszuvas', 'rossz', 'közepes barna rózsaszín barna', 'kedveli a sétákat', 1, 0, '2021-06-27 00:00:00', '/www_tappancs_hu/163.jpg'),
(171, 'Szetti', '2020-01-13', 3, 'kan', 'Arab agár', 'rossz', 0, 15, 'fogszuvas', 'közepes', 'kicsi vörös fekete zöld', 'kedves és barátságos', 1, 0, '2023-02-05 00:00:00', '/www_tappancs_hu/172.jpg'),
(172, 'Bella', '2020-02-01', 3, 'szuka', 'Brabanti kis griffon', 'egészséges', 1, 30, 'fogszuvas', 'egészséges', 'nagy foltos sötétbarna kék', 'be van gyulladva a füle', 1, 0, '2023-12-14 00:00:00', '/www_tappancs_hu/90.jpg'),
(173, 'Kuku', '2020-12-17', 3, 'szuka', 'Nagy vendée-i griffon basset', 'közepes', 1, 29, 'fogszuvas', 'közepes', 'közepes vörös vörös zöld', 'be van gyulladva a füle', 1, 0, '2021-09-19 00:00:00', '/www_tappancs_hu/163.jpg'),
(174, 'Gombi', '2017-11-13', 6, 'szuka', 'Lancashire heeler', 'egészséges', 1, 11, 'foghiányos', 'egészséges', 'kicsi fehér vörös barna', 'több mozgást igényel', 1, 0, '2021-01-07 00:00:00', '/www_tappancs_hu/8.jpg'),
(175, 'Meggi', '2020-07-05', 3, 'kan', 'Skót juhászkutya', 'rossz', 1, 3, 'foghiányos', 'közepes', 'közepes vörös vörös kék', 'szeret sétálni a parkban', 1, 0, '2022-11-05 00:00:00', '/www_tappancs_hu/127.jpg'),
(176, 'Goldy', '2015-06-09', 8, 'szuka', 'Csehszlovák farkaskutya', 'közepes', 0, 4, 'fogszuvas', 'rossz', 'kicsi vörös rózsaszín barna', 'szeret ölelni', 1, 0, '2022-12-08 00:00:00', '/www_tappancs_hu/165.jpg'),
(177, 'Szofi', '2015-11-14', 8, 'szuka', 'Erdélyi kopó  Magyarország', 'egészséges', 0, 15, 'egészséges', 'rossz', 'nagy arany sötétbarna kék', 'köröm vágást igényel', 1, 0, '2023-11-20 00:00:00', '/www_tappancs_hu/19.jpg'),
(178, 'Pitti', '2018-05-19', 5, 'kan', 'Moszkvai hosszú szőrű toy terrier', 'egészséges', 1, 27, 'foghiányos', 'közepes', 'közepes fekete barna kék', 'köröm vágást igényel', 1, 0, '2023-04-25 00:00:00', '/www_tappancs_hu/115.jpg'),
(179, 'Héra', '2015-05-02', 8, 'szuka', 'Magyar vizsla', 'közepes', 1, 2, 'egészséges', 'egészséges', 'közepes fekete barna barna', 'szeret nyugodtan pihenni', 1, 0, '2023-01-21 00:00:00', '/www_tappancs_hu/82.jpg'),
(180, 'Bajnok', '2015-09-21', 8, 'szuka', 'Husky', 'rossz', 1, 8, 'fogszuvas', 'rossz', 'közepes foltos vörös kék', 'imád aludni', 1, 0, '2021-09-14 00:00:00', '/www_tappancs_hu/14.jpg'),
(181, 'Zola', '2019-07-26', 4, 'kan', 'Simaszőrű retriever', 'rossz', 1, 17, 'egészséges', 'rossz', 'nagy arany rózsaszín barna', 'szeret sétálni a parkban', 1, 0, '2023-07-01 00:00:00', '/www_tappancs_hu/119.jpg'),
(182, 'Darling', '2020-06-06', 3, 'kan', 'Sussexi spániel', 'rossz', 0, 6, 'fogszuvas', 'közepes', 'közepes fekete rózsaszín kék', 'szeret fürdeni a tóban', 1, 0, '2021-05-25 00:00:00', '/www_tappancs_hu/150.jpg'),
(183, 'Dorel', '2019-01-17', 4, 'kan', 'Hertha pointer', 'közepes', 1, 14, 'egészséges', 'egészséges', 'nagy fekete rózsaszín zöld', 'szeret játszani a labdával', 1, 0, '2021-01-19 00:00:00', '/www_tappancs_hu/169.jpg'),
(184, 'Szerecsendió', '2018-03-20', 5, 'szuka', 'Bichon frisé', 'egészséges', 0, 8, 'fogszuvas', 'rossz', 'nagy fekete barna kék', 'szeret játszani a labdával', 1, 0, '2023-12-08 00:00:00', '/www_tappancs_hu/203.jpg'),
(185, 'Pitti', '2019-06-22', 4, 'kan', 'Norvég lundehund', 'egészséges', 0, 1, 'egészséges', 'egészséges', 'kicsi tigriscsíkos barna kék', 'szeret fürdeni a tóban', 1, 0, '2023-04-20 00:00:00', '/www_tappancs_hu/128.jpg'),
(186, 'Lili', '2017-05-02', 6, 'kan', 'Ír szetter', 'egészséges', 0, 26, 'fogszuvas', 'közepes', 'nagy fehér barna kék', 'szeret játszani a labdával', 1, 0, '2022-04-16 00:00:00', '/www_tappancs_hu/138.jpg'),
(187, 'Igloo', '2015-06-01', 8, 'szuka', 'Welsh springer spániel', 'közepes', 1, 6, 'egészséges', 'közepes', 'nagy sárga sötétbarna barna', 'kedves és barátságos', 1, 0, '2022-10-14 00:00:00', '/www_tappancs_hu/0.jpg'),
(188, 'Éva', '2018-09-09', 5, 'szuka', 'Japán csin', 'közepes', 0, 22, 'foghiányos', 'egészséges', 'közepes barna fekete kék', 'szeret futkosni a kertben', 1, 0, '2023-05-09 00:00:00', '/www_tappancs_hu/5.jpg'),
(189, 'Bonnie', '2018-04-19', 5, 'kan', 'Mexikói meztelen kutya', 'közepes', 1, 27, 'foghiányos', 'közepes', 'nagy barna fekete zöld', 'szeret játszani a labdával', 1, 0, '2021-07-09 00:00:00', '/www_tappancs_hu/16.jpg'),
(190, 'Téra', '2015-07-23', 8, 'kan', 'Shetlandi juhászkutya', 'közepes', 1, 20, 'egészséges', 'egészséges', 'kicsi fekete vörös kék', 'köröm vágást igényel', 1, 0, '2022-12-16 00:00:00', '/www_tappancs_hu/1.jpg'),
(191, 'Zsüti', '2016-03-16', 7, 'kan', 'Cseh szálkás szakállú vizsla', 'rossz', 0, 29, 'fogszuvas', 'rossz', 'nagy fehér vörös zöld', 'be van gyulladva a füle', 1, 0, '2022-03-03 00:00:00', '/www_tappancs_hu/112.jpg'),
(192, 'Pamacs', '2015-08-05', 8, 'kan', 'Pembroke welsh corgi', 'rossz', 1, 14, 'egészséges', 'közepes', 'kicsi fekete sötétbarna barna', 'szeret kutyakölykökkel játszani', 1, 0, '2023-10-10 00:00:00', '/www_tappancs_hu/173.jpg'),
(193, 'Boomer', '2020-01-04', 3, 'szuka', 'Flandriai pásztorkutya', 'rossz', 1, 3, 'fogszuvas', 'egészséges', 'közepes vörös sötétbarna kék', 'bélférges', 1, 0, '2023-08-24 00:00:00', '/www_tappancs_hu/162.jpg'),
(194, 'Stella', '2015-10-27', 8, 'kan', 'Laekenois', 'közepes', 1, 1, 'foghiányos', 'egészséges', 'nagy fehér barna barna', 'szeret úszni', 1, 0, '2021-04-22 00:00:00', '/www_tappancs_hu/126.jpg'),
(195, 'Rénó', '2016-07-25', 7, 'kan', 'Bichon frisé', 'közepes', 0, 4, 'foghiányos', 'egészséges', 'közepes foltos vörös kék', 'imád aludni', 1, 0, '2022-01-05 00:00:00', '/www_tappancs_hu/150.jpg'),
(196, 'Terry', '2020-06-26', 3, 'szuka', 'Csivava', 'egészséges', 0, 22, 'fogszuvas', 'egészséges', 'nagy sárga fekete zöld', 'szeret ölelni', 1, 0, '2022-04-21 00:00:00', '/www_tappancs_hu/4.jpg'),
(197, 'Neutron', '2020-07-17', 3, 'szuka', 'Tornjak', 'közepes', 0, 2, 'fogszuvas', 'közepes', 'nagy vörös barna kék', 'szeret labdázni', 1, 0, '2023-05-04 00:00:00', '/www_tappancs_hu/170.jpg'),
(198, 'Shiva', '2016-01-06', 7, 'kan', 'Malinois', 'egészséges', 0, 27, 'foghiányos', 'rossz', 'közepes fehér vörös kék', 'köröm vágást igényel', 1, 0, '2023-05-15 00:00:00', '/www_tappancs_hu/177.jpg'),
(199, 'Illés', '2018-11-16', 5, 'kan', 'Akbash', 'közepes', 0, 14, 'foghiányos', 'közepes', 'nagy fehér sötétbarna zöld', 'kedveli a sétákat', 1, 0, '2021-05-16 00:00:00', '/www_tappancs_hu/95.jpg'),
(200, 'Mazsola', '2015-04-28', 8, 'szuka', 'Harlekin pincser', 'egészséges', 1, 26, 'egészséges', 'egészséges', 'kicsi fehér fekete zöld', 'szeret ölelni', 1, 0, '2021-01-01 00:00:00', '/www_tappancs_hu/178.jpg'),
(201, 'Jasper', '2015-05-09', 8, 'szuka', 'Szetter', 'közepes', 0, 23, 'foghiányos', 'rossz', 'közepes fehér barna barna', 'szeret nyugodtan pihenni', 1, 0, '2022-07-03 00:00:00', '/www_tappancs_hu/73.jpg'),
(202, 'Shiva', '2015-03-11', 8, 'szuka', 'Finn spicc', 'rossz', 0, 7, 'egészséges', 'egészséges', 'kicsi fekete vörös zöld', 'be van gyulladva a füle', 1, 0, '2021-08-18 00:00:00', '/www_tappancs_hu/100.jpg'),
(203, 'Azték', '2016-05-23', 7, 'kan', 'Utonagan', 'egészséges', 0, 21, 'egészséges', 'közepes', 'kicsi fekete rózsaszín kék', 'be van gyulladva a füle', 1, 0, '2023-05-02 00:00:00', '/www_tappancs_hu/84.jpg'),
(204, 'Éva', '2020-12-22', 3, 'kan', 'Afrikai oroszlánkutya', 'egészséges', 0, 27, 'fogszuvas', 'egészséges', 'kicsi barna fekete kék', 'szeret sétálni a parkban', 1, 0, '2021-06-11 00:00:00', '/www_tappancs_hu/210.jpg'),
(205, 'Jet', '2015-08-28', 8, 'kan', 'Portugál vízikutya', 'közepes', 1, 22, 'egészséges', 'rossz', 'nagy fekete fekete zöld', 'imád aludni', 1, 0, '2022-05-25 00:00:00', '/www_tappancs_hu/157.jpg'),
(206, 'Szerecsendió', '2017-02-05', 6, 'kan', 'Közép schnauzer', 'egészséges', 0, 24, 'foghiányos', 'egészséges', 'nagy foltos sötétbarna kék', 'szeret kutyakölykökkel játszani', 1, 0, '2021-07-10 00:00:00', '/www_tappancs_hu/114.jpg'),
(207, 'Orlando', '2017-12-23', 6, 'szuka', 'Nyugat-szibériai lajka', 'egészséges', 1, 10, 'fogszuvas', 'egészséges', 'nagy fehér barna zöld', 'be van gyulladva a füle', 1, 0, '2021-11-20 00:00:00', '/www_tappancs_hu/187.jpg'),
(208, 'Nimród', '2019-05-15', 4, 'kan', 'Lengyel kopó', 'rossz', 1, 24, 'fogszuvas', 'egészséges', 'kicsi barna vörös kék', 'bélférges', 1, 0, '2022-04-12 00:00:00', '/www_tappancs_hu/76.jpg'),
(209, 'Illés', '2019-08-26', 4, 'kan', 'Thai ridgeback', 'egészséges', 1, 11, 'fogszuvas', 'közepes', 'kicsi barna sötétbarna zöld', 'szeret sétálni a parkban', 1, 0, '2021-10-11 00:00:00', '/www_tappancs_hu/54.jpg'),
(210, 'Smokie', '2015-06-23', 8, 'kan', 'Német spicc', 'egészséges', 1, 3, 'egészséges', 'rossz', 'kicsi szürke rózsaszín zöld', 'szeret játszani', 1, 0, '2022-12-22 00:00:00', '/www_tappancs_hu/93.jpg'),
(211, 'Inzy', '2016-02-13', 7, 'kan', 'Broholmer', 'közepes', 1, 13, 'fogszuvas', 'rossz', 'kicsi vörös fekete zöld', 'szeret nyugodtan pihenni', 1, 0, '2021-10-25 00:00:00', '/www_tappancs_hu/39.jpg'),
(212, 'Milli', '2016-11-12', 7, 'kan', 'Pikárdiai kék spániel', 'közepes', 1, 20, 'egészséges', 'egészséges', 'közepes szürke barna zöld', 'szeret az ablakban ülni', 1, 0, '2021-10-14 00:00:00', '/www_tappancs_hu/15.jpg'),
(213, 'Teo', '2019-04-18', 4, 'kan', 'Longdog', 'egészséges', 0, 30, 'fogszuvas', 'rossz', 'közepes vörös rózsaszín kék', 'köröm vágást igényel', 1, 0, '2021-11-17 00:00:00', '/www_tappancs_hu/12.jpg'),
(214, 'Lilla', '2018-01-02', 5, 'szuka', 'Fehér-fekete francia kopó', 'egészséges', 0, 11, 'fogszuvas', 'egészséges', 'kicsi barna barna barna', 'szeret kutyakölykökkel játszani', 1, 0, '2023-04-20 00:00:00', '/www_tappancs_hu/71.jpg'),
(215, 'Keksz', '2016-05-20', 7, 'kan', 'Ibizai kopó', 'közepes', 0, 19, 'foghiányos', 'rossz', 'nagy sárga barna kék', 'szeret úszni', 1, 0, '2022-05-18 00:00:00', '/www_tappancs_hu/58.jpg'),
(216, 'Pajtás', '2015-10-08', 8, 'kan', 'Welsh springer spániel', 'közepes', 0, 17, 'foghiányos', 'rossz', 'nagy szürke fekete kék', 'szeret kutyakölykökkel játszani', 1, 0, '2022-03-03 00:00:00', '/www_tappancs_hu/183.jpg'),
(217, 'Szerecsendió', '2015-01-21', 8, 'szuka', 'Görög kopó', 'közepes', 1, 13, 'fogszuvas', 'egészséges', 'nagy barna sötétbarna kék', 'szeret játszani a labdával', 1, 0, '2023-07-10 00:00:00', '/www_tappancs_hu/93.jpg'),
(218, 'Zorró', '2020-10-26', 3, 'szuka', 'Ónémet juhászkutya', 'rossz', 1, 8, 'foghiányos', 'közepes', 'közepes barna fekete barna', 'be van gyulladva a füle', 1, 0, '2022-06-21 00:00:00', '/www_tappancs_hu/137.jpg'),
(219, 'Chilli', '2016-09-20', 7, 'szuka', 'Középspitz', 'rossz', 0, 21, 'egészséges', 'közepes', 'nagy arany barna kék', 'imád aludni', 1, 0, '2021-08-10 00:00:00', '/www_tappancs_hu/46.jpg'),
(220, 'Éva', '2016-06-14', 7, 'kan', 'Pikárdiai spániel', 'közepes', 0, 1, 'fogszuvas', 'rossz', 'közepes vörös vörös zöld', 'szeret labdázni', 1, 0, '2023-07-10 00:00:00', '/www_tappancs_hu/57.jpg'),
(221, 'Leó', '2017-10-18', 6, 'kan', 'Dobermann', 'egészséges', 0, 14, 'foghiányos', 'rossz', 'kicsi szürke vörös zöld', 'kedves és barátságos', 1, 0, '2023-05-04 00:00:00', '/www_tappancs_hu/2.jpg'),
(222, 'Jabba', '2020-05-15', 3, 'szuka', 'Norfolk terrier', 'egészséges', 1, 14, 'foghiányos', 'rossz', 'közepes barna fekete kék', 'szeret nyugodtan pihenni', 1, 0, '2023-08-06 00:00:00', '/www_tappancs_hu/151.jpg'),
(223, 'Sziszi', '2017-03-01', 6, 'szuka', 'Félhosszúszőrű pireneusi juhászkutya', 'rossz', 0, 18, 'egészséges', 'rossz', 'nagy fehér sötétbarna kék', 'szeret sétálni a parkban', 1, 0, '2021-10-16 00:00:00', '/www_tappancs_hu/28.jpg'),
(224, 'Bözsi', '2015-12-14', 8, 'kan', 'Coton de tuléar', 'rossz', 1, 16, 'foghiányos', 'közepes', 'nagy szürke fekete kék', 'kedveli a sétákat', 1, 0, '2021-07-21 00:00:00', '/www_tappancs_hu/165.jpg'),
(225, 'Bonnie', '2019-06-12', 4, 'szuka', 'Francia bulldog', 'egészséges', 0, 14, 'egészséges', 'közepes', 'kicsi fekete sötétbarna zöld', 'szeret játszani', 1, 0, '2023-11-18 00:00:00', '/www_tappancs_hu/139.jpg'),
(226, 'Chilli', '2017-08-24', 6, 'kan', 'Münsterlandi vizsla', 'rossz', 1, 14, 'fogszuvas', 'rossz', 'közepes vörös vörös barna', 'szeret nyugodtan pihenni', 1, 0, '2023-05-04 00:00:00', '/www_tappancs_hu/158.jpg'),
(227, 'Plutó', '2018-02-04', 5, 'kan', 'Wolfspitz', 'rossz', 0, 5, 'egészséges', 'rossz', 'kicsi vörös rózsaszín zöld', 'több mozgást igényel', 1, 0, '2021-07-14 00:00:00', '/www_tappancs_hu/48.jpg'),
(228, 'Jázmina', '2016-06-04', 7, 'kan', 'Nyugat-szibériai lajka', 'közepes', 0, 3, 'foghiányos', 'rossz', 'kicsi vörös vörös zöld', 'be van gyulladva a füle', 1, 0, '2022-03-18 00:00:00', '/www_tappancs_hu/18.jpg'),
(229, 'Killer', '2018-02-13', 5, 'szuka', 'Óriás schnauzer', 'közepes', 1, 7, 'fogszuvas', 'egészséges', 'közepes sárga fekete kék', 'bélférges', 1, 0, '2021-09-05 00:00:00', '/www_tappancs_hu/163.jpg'),
(230, 'Sámson', '2016-04-01', 7, 'kan', 'Spanyol kopó', 'egészséges', 0, 25, 'fogszuvas', 'rossz', 'közepes fekete rózsaszín zöld', 'több mozgást igényel', 1, 0, '2023-07-18 00:00:00', '/www_tappancs_hu/67.jpg'),
(231, 'Ádáz', '2019-09-22', 4, 'kan', 'Csivava', 'rossz', 0, 3, 'foghiányos', 'rossz', 'kicsi tigriscsíkos sötétbarna barna', 'szeret az ablakban ülni', 1, 0, '2021-11-14 00:00:00', '/www_tappancs_hu/9.jpg'),
(232, 'Bajnok', '2016-10-11', 7, 'kan', 'Appenzelli havasi kutya', 'közepes', 0, 22, 'fogszuvas', 'rossz', 'kicsi foltos vörös zöld', 'szeret futkosni a kertben', 1, 0, '2022-10-16 00:00:00', '/www_tappancs_hu/159.jpg'),
(233, 'Tekergő', '2016-07-25', 7, 'szuka', 'Szerb trikolor kopó', 'egészséges', 1, 30, 'egészséges', 'közepes', 'nagy sárga sötétbarna zöld', 'kedveli a sétákat', 1, 0, '2022-12-15 00:00:00', '/www_tappancs_hu/167.jpg'),
(234, 'Pisze', '2020-07-08', 3, 'szuka', 'Orosz-európai lajka', 'rossz', 0, 5, 'foghiányos', 'egészséges', 'közepes szürke sötétbarna barna', 'kedves és barátságos', 1, 0, '2022-04-04 00:00:00', '/www_tappancs_hu/86.jpg'),
(235, 'Jázmin', '2020-12-05', 3, 'kan', 'Tacskó', 'egészséges', 1, 11, 'foghiányos', 'közepes', 'kicsi barna rózsaszín zöld', 'szeret az ablakban ülni', 1, 0, '2022-09-22 00:00:00', '/www_tappancs_hu/167.jpg');
INSERT INTO `allatok` (`allat_id`, `allat_nev`, `szul_ev`, `becsult_kor`, `neme`, `fajta`, `eu_allapot`, `ivar_ivartalanitot`, `suly`, `fogazatt`, `testi_allapott`, `ismertetojegyek`, `megjegyzes`, `chip`, `orokbeadas`, `befogadas_datuma`, `img`) VALUES
(236, 'Jimmy', '2015-09-16', 8, 'szuka', 'Padilokoon', 'rossz', 1, 30, 'foghiányos', 'közepes', 'kicsi arany rózsaszín barna', 'imád aludni', 1, 0, '2022-12-14 00:00:00', '/www_tappancs_hu/85.jpg'),
(237, 'Karcsi', '2015-12-03', 8, 'kan', 'Kis luzerni kopó', 'rossz', 0, 3, 'egészséges', 'közepes', 'nagy fekete fekete kék', 'szeret nyugodtan pihenni', 1, 0, '2023-07-03 00:00:00', '/www_tappancs_hu/46.jpg'),
(238, 'Neutron', '2017-12-13', 6, 'szuka', 'Fekete norvég elghund', 'rossz', 0, 13, 'foghiányos', 'egészséges', 'kicsi fekete vörös barna', 'szeret az ablakban ülni', 1, 0, '2023-02-25 00:00:00', '/www_tappancs_hu/138.jpg'),
(239, 'Okonor', '2016-07-13', 7, 'kan', 'Uszkár', 'rossz', 1, 15, 'egészséges', 'rossz', 'kicsi barna barna barna', 'kedveli a sétákat', 1, 0, '2021-05-03 00:00:00', '/www_tappancs_hu/71.jpg'),
(240, 'Vacak', '2019-10-17', 4, 'kan', 'Lengyel hegyi juhászkutya', 'közepes', 0, 30, 'fogszuvas', 'egészséges', 'kicsi fehér fekete zöld', 'több mozgást igényel', 1, 0, '2022-02-26 00:00:00', '/www_tappancs_hu/3.jpg'),
(241, 'Karcsi', '2016-10-04', 7, 'szuka', 'Shikoku inu', 'rossz', 0, 17, 'fogszuvas', 'rossz', 'nagy vörös barna zöld', 'kedveli a sétákat', 1, 0, '2022-01-22 00:00:00', '/www_tappancs_hu/91.jpg'),
(242, 'Rea', '2017-11-14', 6, 'kan', 'Román pásztor kutya', 'egészséges', 1, 1, 'foghiányos', 'egészséges', 'közepes fekete sötétbarna barna', 'köröm vágást igényel', 1, 0, '2022-06-16 00:00:00', '/www_tappancs_hu/10.jpg'),
(243, 'Polli', '2019-04-12', 4, 'kan', 'Osztrák pinscher', 'közepes', 0, 13, 'egészséges', 'közepes', 'kicsi foltos fekete zöld', 'több mozgást igényel', 1, 0, '2023-08-07 00:00:00', '/www_tappancs_hu/208.jpg'),
(244, 'Vacak', '2019-01-06', 4, 'szuka', 'Auvergne-i vizsla', 'közepes', 0, 21, 'egészséges', 'rossz', 'közepes sárga barna barna', 'szeret úszni', 1, 0, '2022-08-09 00:00:00', '/www_tappancs_hu/118.jpg'),
(245, 'Goldy', '2015-09-16', 8, 'szuka', 'Norvég buhund', 'rossz', 1, 27, 'foghiányos', 'közepes', 'közepes fekete barna barna', 'szeret ölelni', 1, 0, '2022-08-24 00:00:00', '/www_tappancs_hu/204.jpg'),
(246, 'Killer', '2019-07-09', 4, 'kan', 'Lhasa apso', 'közepes', 0, 17, 'egészséges', 'egészséges', 'közepes fekete barna zöld', 'bélférges', 1, 0, '2021-01-18 00:00:00', '/www_tappancs_hu/126.jpg'),
(247, 'Stuki', '2015-04-18', 8, 'szuka', 'Kelet-szibériai lajka', 'rossz', 0, 8, 'foghiányos', 'egészséges', 'nagy fehér sötétbarna kék', 'szeret úszni', 1, 0, '2023-03-27 00:00:00', '/www_tappancs_hu/199.jpg'),
(248, 'Ofra', '2016-10-21', 7, 'kan', 'Berni kopó', 'egészséges', 1, 19, 'fogszuvas', 'rossz', 'nagy szürke rózsaszín barna', 'szeret ölelni', 1, 0, '2021-05-09 00:00:00', '/www_tappancs_hu/190.jpg'),
(249, 'Polli', '2019-12-12', 4, 'szuka', 'Hygen kopó', 'rossz', 0, 1, 'egészséges', 'közepes', 'nagy vörös sötétbarna barna', 'szeret kutyakölykökkel játszani', 1, 0, '2023-01-20 00:00:00', '/www_tappancs_hu/69.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `orokbeadott_allatok`
--

CREATE TABLE `orokbeadott_allatok` (
  `id` int(11) NOT NULL,
  `user_id` int(255) NOT NULL,
  `allat_id` int(255) NOT NULL,
  `be_datum` datetime NOT NULL DEFAULT current_timestamp(),
  `ki_datum` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `orokbeadott_allatok`
--

INSERT INTO `orokbeadott_allatok` (`id`, `user_id`, `allat_id`, `be_datum`, `ki_datum`, `status`) VALUES
(1, 1, 2, '2023-04-18 15:38:14', NULL, 1),
(2, 1, 4, '2023-04-18 15:38:25', NULL, 1),
(3, 1, 6, '2023-04-18 15:38:35', NULL, 1),
(4, 5, 8, '2023-04-18 15:39:24', NULL, 1),
(5, 3, 9, '2023-04-18 15:39:44', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `kert_van` varchar(10) NOT NULL,
  `add_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `bizalom_v` tinyint(1) NOT NULL DEFAULT 1,
  `admin_e` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password_hash`, `kert_van`, `add_date`, `bizalom_v`, `admin_e`) VALUES
(1, 'Szász Gergő', 'szaszgergo005@gmail.com', '$2y$10$eSEZoPSsAp14WLSl94TrAOJnC33SSuvOZJZJScWeCBYdXPSFg/S12', 'kert', '2023-04-12 16:36:30', 1, 0),
(2, 'nincskert', 'nincskert@gmail.com', '$2y$10$cmDAQ/eX9ZmbBzwzDZIgquGjFYQD.K8t4TqSWWRmYx7erhGN5dB26', 'panel', '2023-04-12 16:37:02', 1, 0),
(3, 'kert1', 'kert1@gmail.com', '$2y$10$H9za3Y3kBMQHmgmjzMUKeONLZopGUsb6u8uuUckHdJV1YIWbjye6C', 'kert', '2023-04-13 18:22:56', 0, 0),
(4, 'kert2', 'kert2@gmail.com', '$2y$10$EMKF.5gsyscqXyBG2o3DuOfyIDq1McY8wMvWDAvRIfJUghKWXn0Pa', 'kert', '2023-04-13 18:23:06', 1, 0),
(5, 'admin', 'admin@gmail.com', '$2y$10$qVgFO3VuaDuy5mWc.tqJUumt.PK3OF1X3HesZHEU6T6J.0o2tb7.S', 'kert', '2023-04-16 08:20:03', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `allatok`
--
ALTER TABLE `allatok`
  ADD PRIMARY KEY (`allat_id`);

--
-- Indexes for table `orokbeadott_allatok`
--
ALTER TABLE `orokbeadott_allatok`
  ADD PRIMARY KEY (`id`),
  ADD KEY `allat_id` (`allat_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `allatok`
--
ALTER TABLE `allatok`
  MODIFY `allat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=250;

--
-- AUTO_INCREMENT for table `orokbeadott_allatok`
--
ALTER TABLE `orokbeadott_allatok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orokbeadott_allatok`
--
ALTER TABLE `orokbeadott_allatok`
  ADD CONSTRAINT `orokbeadott_allatok_ibfk_1` FOREIGN KEY (`allat_id`) REFERENCES `allatok` (`allat_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orokbeadott_user_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
