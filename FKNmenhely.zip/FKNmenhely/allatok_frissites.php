<?php 


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fknmenhely";

// Adatbázis kapcsolat létrehozása
$conn = mysqli_connect($servername, $username, $password, $dbname);


if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

session_start();


if (isset($_SESSION["user_id"])) {
    
    $mysqli = require __DIR__ . "/database.php";
    
    $sql = "SELECT * FROM user
            WHERE id = {$_SESSION["user_id"]}";
            
    $result = $mysqli->query($sql);
    
    $user = $result->fetch_assoc();
}

//allat adatai meghivas
$db = new mysqli("localhost", "root", "", "fknmenhely");
$db_amount = $db->query("SELECT COUNT(*) FROM allatok");
$totalItem = $db_amount->fetch_row()[0];
$url_allat_id = $_GET['id'];
if ($url_allat_id <= $totalItem+1) {
    $allat = $db->query("SELECT * FROM `allatok` WHERE `allat_id` = \"$url_allat_id\"");
   
 // 
  //
    $mezo = $allat -> fetch_row();

    $allat_id = $mezo[0];
    $allat_nev = $mezo[1]; //
    $szuletett = substr($mezo[2], 0, 10); //
    $becsult_kor = $mezo[3]; //
    $neme = $mezo[4]; //
    $fajta = $mezo[5]; //
    $eu_allapot = $mezo[6]; //
    $IS_IVARTALAN = $mezo[7]; //
    $ivaros = '';
    if ($IS_IVARTALAN == 1) {
        $ivaros = "ivartalanított";
    }else{
        $ivaros = "nincs ivartalanítva";
    }
    $suly = $mezo[8]; //
    $fogazatt = $mezo[9]; //
    $testi_allapot = $mezo[10]; //
    $ismertetojegyek = $mezo[11];//
    $megjegyzes = $mezo[12];//
    $IS_CHIP = $mezo[13];//
    $chipes = '';
    if ($IS_CHIP == 1) {
        $chipes = "Igen";
    }else{
        $chipes = "Nem";
    }
    $IS_OROKBEADAS = $mezo[14];
    $befogadas_datuma = substr($mezo[15], 0, 10);
    $img_src = $mezo[16];//
}
//allat adatai meghivas

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Állat frissitése</title>
    <link rel="stylesheet" href="stilus/allatok_add.css?v=<?php echo time(); ?>">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="header">
          <!------------------------fej-eleje------------------------------------------>
  <header class="bg-light" id="fej1">
    <div class="container">
      
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <a class="navbar-brand" href="#">
            <img src="kepek/logo2.png" width="50" height="50" alt="">
          </a>
            <a class="navbar-brand" href="#">Menü</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                  <a class="nav-link" href="index.html">Főoldal </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="allatok.php">Állatok</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php">Saját oldalam</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="loginadmin.php">Állatok örökbeadása</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php"> Felhasználó:
                  <?php
                  if (isset($user)): ?><?= htmlspecialchars($user["name"]) ?> 
                  <?php else: ?> 
                    Bejelentkezés
                  <?php endif; ?></a>
                </li>
                     
              </ul>
            </div>
          </nav>
    </div>
</header> 

<!---------------------fej-vége----------------->   
        </div>

<!----------------->

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php 
                    if(isset($_SESSION['status']))
                    {
                        ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <strong>Hey!</strong> <?php echo $_SESSION['status']; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php
                        unset($_SESSION['status']);
                    }
                ?>

                <div class="card mt-5">
                    <div class="card-header">
                        <h1>Állat frissitése</h1>
                        
                    </div>
                    <div class="card-body">
                    
                    <form action="allatok_friss.php?id=<?php echo urlencode($allat_id); ?>" method="POST" enctype="multipart/form-data">

                       
                            <div class="form-group mb-3">
                                <label for="name">Állat neve: </label>
                                <input type="text" name="name" id="name" value="<?php echo($allat_nev); ?>" class="form-control" />
                            </div>
                            <div class="form-group mb-3">
                                <label for="dateofbirth">Születési éve: </label>
                                <input type="date" name="dateofbirth"  id="dateofbirth" value="<?php echo($szuletett); ?>" class="form-control" />
                            </div>

                            <div class="form-group mb-3">
                                <label for="becsultkor">(Becsült) kora: </label>
                                <input type="number" name="becsultkor" min="1" max="30" id="becsultkor"  value="<?php echo($becsult_kor); ?>" class="form-control" />
                            </div>
                                        <!--NINCS becsültkor-->
                                        <div class="form-group mb-3">
                                    <fieldset>
                                        <legend><label for="neme">Neme: </label></legend>
                                        <label for="neme">
                                            <input type="radio" name="neme" id="neme_kan"  value="kan" <?php if ($neme == 'kan') echo 'checked'; ?> selected>
                                            Kan
                                        </label>
                                        <br>
                                        <label for="neme">
                                            <input type="radio" name="neme" id="neme_szuka" value="szuka" <?php if ($neme == 'szuka') echo 'checked'; ?>>
                                            Szuka
                                        </label>
                                    </fieldset>               
                                    </div>

                            <div class="form-group mb-3">
                                <label for="faja">Faja: </label>
                                <input type="text" name="faja" id="faja" value="<?php echo($fajta); ?>" class="form-control" />
                            </div>
                            

                            <div class="form-group mb-3">
    <label for="eu_allapot">Egészségi Állapot: </label>
    <br>
    <select name="eu_allapot" id="eu_allapot">
        <option value="egészséges" <?php if ($eu_allapot == 'egészséges') echo 'selected'; ?>>egészséges</option>
        <option value="közepes" <?php if ($eu_allapot == 'közepes') echo 'selected'; ?>>közepes</option>
        <option value="rossz" <?php if ($eu_allapot == 'rossz') echo 'selected'; ?>>rossz</option>
    </select>
</div>

                            
                            <div class="form-group mb-3">
    <fieldset>
        <legend><label for="ivar_ivartalanitot">Ivartalanitott-e? : </label></legend>
        <label for="">
            <input type="radio" name="ivar" id="ivar_igen" value="1" <?php if ($IS_IVARTALAN == 1) echo 'checked'; ?>>
            Igen
        </label>
        <br>
        <label for="">
            <input type="radio" name="ivar" id="ivar_nem" value="0" <?php if ($IS_IVARTALAN == 0) echo 'checked'; ?>>
            Nem
        </label>
    </fieldset>
</div>
                            <!---->

                            <div class="form-group mb-3">
                                <label for="suly">Súlya: </label>
                                <input type="number" name="suly" id="suly" max="150" min="1"  value="<?php echo($suly); ?>" class="form-control" />
                            </div>


                            <div class="form-group mb-3">
                                <label for="fogazatt_allapot">Fogazatt állapota: </label>
                                <br>
                                <select name="fogazatt_allapot" id="fogazatt_allapot">
                                    <option value="egészséges" <?php if ($fogazatt == 'egészséges') echo 'selected'; ?> >egészséges</option>
                                    <option value="fogszuvas" <?php if ($fogazatt == 'fogszuvas') echo 'selected'; ?> >fogszuvas</option>
                                    <option value="foghiányos" <?php if ($fogazatt == 'foghiányos') echo 'selected'; ?>>foghiányos</option>
                                </select>
                            </div>


                            <div class="form-group mb-3">
                                <label for="testi_allapot">Testi állapot: </label>
                                <br>
                                <select name="testi_allapot" id="testi_allapot">
                                    <option value="egészséges" <?php if ($testi_allapot == 'egészséges') echo 'selected'; ?>>egészséges</option>
                                    <option value="közepes"  <?php if ($testi_allapot == 'közepes') echo 'selected'; ?>>közepes</option>
                                    <option value="rossz"  <?php if ($testi_allapot == 'rossz') echo 'selected'; ?>>rossz</option>
                                </select>
                            </div>

                            <div class="form-group mb-3">
                                <label for="ismertetojegyek">Ismertető jegyek: "Maximum 200 karakter." </label>
                                <br>
                              <textarea name="ismertetojegyek" id="ismertetojegyek" cols="54" rows="5"   maxlength="200"><?php echo($ismertetojegyek); ?></textarea>
                            </div>

                            <div class="form-group mb-3">
                                <label for="megjegyzes">Megjegyzés: "Maximum 200 karakter." </label>
                                <br>
                              <textarea name="megjegyzes" id="megjegyzes" cols="54" rows="5"  maxlength="200"><?php echo($megjegyzes); ?></textarea>
                            </div>

                                
                            <div class="form-group mb-3">
    <fieldset>
        <legend><label for="chip">Chippelt-e? : </label></legend>
        <label for="chip_igen">
            <input type="radio" name="chip" id="chip_igen" value="1" <?php if ($IS_CHIP == 1) echo 'checked'; ?>>
            Igen
        </label>
        <br>
        <label for="chip_nem">
            <input type="radio" name="chip" id="chip_nem" value="0" <?php if ($IS_CHIP == 0) echo 'checked'; ?>>
            Nem
        </label>
    </fieldset>
</div>

                         
                          

                            <div class="form-group mb-3">
                                <button type="submit" name="save_date" value="UPLOAD" class="btn btn-primary">Frissités</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--ha van admin vége-->
    <!--ha nincs admin eleje-->


    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<!--
    becsult_kor kell
    img
php
-->