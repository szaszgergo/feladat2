<?php

if (empty($_POST["name"])) {
    die("Név megadása szükséges!");
}

if ( ! filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
    die("Valós e-mail szükséges !");
}

if (strlen($_POST["password"]) < 8) {
    die("A jelszónak minimum 8 karakter hosszúságunak kell lennie");
}

if ( ! preg_match("/[a-z]/i", $_POST["password"])) {
    die("A jelszónak legalább egy betűt tartalmaznia kell ");
}

if ( ! preg_match("/[0-9]/", $_POST["password"])) {
    die("A jelszónak legalább egy számot tartalmaznia kell ");
}

if ($_POST["password"] !== $_POST["password_confirmation"]) {
    die("A jelszóknak egyeznie kell");
}

$answer = $_POST['ans'];  
if ($answer == "kert") {          
    $kert_van= $_POST['ans'];     
}
if ($answer == "panel") {          
    $kert_van= $_POST['ans'];     
}
//hiba kód


$password_hash = password_hash($_POST["password"], PASSWORD_DEFAULT);

$mysqli = require __DIR__ . "/database.php";

$sql = "INSERT INTO felhasznalok (name, email, password_hash,kert_van)
        VALUES (?, ?, ?, ?)";
        
$stmt = $mysqli->stmt_init();

if ( ! $stmt->prepare($sql)) {
    die("SQL error: " . $mysqli->error);
}

$stmt->bind_param("ssss",
                  $_POST["name"],
                  $_POST["email"],
                  $password_hash,
                  $kert_van);

if ($stmt->execute()) {

    header("Location: signup-success.html");
    exit;
    
} else {
    
    if ($mysqli->errno === 1062) {
        die("email already taken");
    } else {
        die($mysqli->error . " " . $mysqli->errno);
    }
}