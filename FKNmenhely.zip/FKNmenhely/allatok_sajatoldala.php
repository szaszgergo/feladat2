<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fknmenhely";

// Adatbázis kapcsolat létrehozása
$conn = mysqli_connect($servername, $username, $password, $dbname);


if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}




session_start();


// Check do the person logged in


if (isset($_SESSION["user_id"])) {
    
  $mysqli = require __DIR__ . "/database.php";
  
  $sql = "SELECT * FROM user
          WHERE id = {$_SESSION["user_id"]}";
          
  $result = $mysqli->query($sql);
  
  $user = $result->fetch_assoc();
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Állatok sajátoldala</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
    
    
    <link rel="stylesheet" href="stilus/style_allatok.css?v=<?php echo time(); ?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://unpkg.com/just-validate@latest/dist/just-validate.production.min.js" defer></script>
    <script src="js/validation.js" defer></script>
    
</head>
<body>
<div class="site-container">
        <div class="header">
          <!------------------------fej-eleje------------------------------------------>
  <header class="bg-light" id="fej1">
    <div class="container">
      
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <a class="navbar-brand" href="#">
            <img src="kepek/logo2.png" width="50" height="50" alt="">
          </a>
            <a class="navbar-brand" href="#">Menü</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                  <a class="nav-link" href="index.html">Főoldal</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="allatok.php">Állatok</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php">Saját oldalam</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="loginadmin.php">Állatok örökbeadása</a>
                </li>

                <li class="nav-item">
                  <a class="nav-link" href="index.php"> Felhasználó:
                  <?php
                  if (isset($user)): ?><?= htmlspecialchars($user["name"]) ?> 
                  <?php else: 
                    $user['id']='0'; // 1000. id nem lehet
                    ?> 
                    Bejelentkezés
                  <?php endif; ?></a>
                </li>

               
              </ul>
            </div>
          </nav>
    </div>
</header> 

<!---------------------fej-vége----------------->   
        </div>

     

   


 

        
        <div class="main">
            <div class="container">
                <div class="">
                  
                <?php            
//user adatai meghivas
$db = new mysqli("localhost", "root", "", "fknmenhely");
$url_user_id = $user["id"];
if ($result = $db->query("SELECT * FROM user WHERE id = $url_user_id")) {
if ($row = $result->fetch_assoc()) {
$user_id = $row["id"];
$user_name = $row["name"];
$kert = ($row["kert_van"] == 'kert') ? 1 : 0;
$bizalom = $row["bizalom_v"];
}
$result->free();
}
//user adatai meghivas eddig

//kutyaörökbevaneadva
$db = new mysqli("localhost", "root", "", "fknmenhely");
$url_allat_id = $_GET['id'];
if ($result = $db->query("SELECT orokbeadott_allatok.status, allatok.allat_nev FROM orokbeadott_allatok, allatok WHERE allatok.allat_id = '$url_allat_id' AND orokbeadott_allatok.allat_id='$url_allat_id'")) {
if ($result->num_rows > 0) {
$row = $result->fetch_assoc();
$status = $row["status"];
$statuS = $status == '1' ? 'Örökbe van adva már.' : 'Nincs még örökbe adva.';
$allatneve = $row["allat_nev"];
}
$result->free();
}
//kutyaörökbevaneadva eddig

//allat adatai meghivas
$db = new mysqli("localhost", "root", "", "fknmenhely");
$db_amount = $db->query("SELECT COUNT(*) FROM allatok");
$totalItem = $db_amount->fetch_row()[0];
$url_allat_id = $_GET['id'];
if ($url_allat_id <= $totalItem+1) {
    $allat = $db->query("SELECT * FROM `allatok` WHERE `allat_id` = \"$url_allat_id\"");
   
 // 
  //
    $mezo = $allat -> fetch_row();
//allat adatai meghivas



                        //karanten
                        $karantenlejart=substr($mezo[15], 0, 10);
                  
                        $sql = "SELECT DATEDIFF(CURRENT_TIMESTAMP(), befogadas_datuma) as maradek_nap FROM `allatok` WHERE `allat_id` = \"$url_allat_id\"";
                        $result = mysqli_query($conn, $sql);
                        
                        // Eredmény feldolgozása
                        if (mysqli_num_rows($result) > 0) {
                          // Adatok kiírása
                          while($row = mysqli_fetch_assoc($result)) {
                             $hanynap = $row["maradek_nap"]-14;
                             $hanynapint =intval($hanynap);
                          }
                        } else {
                          $hanynapint= "Nincs eredmény.";
                        }
                        
                        if(abs($hanynapint) >14){
                          
                          $hanynapint= 'Nincs több nap a karanténból.';
                        }
                       
                        ////karanten eddig
  
                        $allat_id = $mezo[0];
                        $allat_nev = $mezo[1];
                        $szuletett = substr($mezo[2], 0, 10);
                        $becsult_kor = $mezo[3];
                        $neme = $mezo[4];
                        $fajta = $mezo[5];
                        $eu_allapot = $mezo[6];
                        $IS_IVARTALAN = $mezo[7];
                        $ivaros = '';
                        if ($IS_IVARTALAN == 1) {
                            $ivaros = "ivartalanított";
                        }else{
                            $ivaros = "nincs ivartalanítva";
                        }
                        $suly = $mezo[8];
                        $fogazatt = $mezo[9];
                        $testi_allapot = $mezo[10];
                        $ismertetojegyek = $mezo[11];
                        $megjegyzes = $mezo[12];
                        $IS_CHIP = $mezo[13];
                        $chipes = '';
                        if ($IS_CHIP == 1) {
                            $chipes = "Igen";
                        }else{
                            $chipes = "Nem";
                        }
                        $IS_OROKBEADAS = $mezo[14];
                        $befogadas_datuma = substr($mezo[15], 0, 10);
                        $img_src = $mezo[16];

                  
                    
                        $html = '';

                        $html .= '<div class="allatadatok">
                                   <form action="orokbeadas.php?id=' . $allat_id.'&'.'userid='.$user["id"] . '" method="POST">
                                     <div class="container">
                                       <div class="row">
                                         <div class="col">
                                           <div class="kep">
                                             <img src="' . $img_src . '" alt="' . $allat_nev . '">
                                          
                                           </div>';
                                           
                                           if(isset($_SESSION["user_id"])==NULL){
                                             // Haven't log in
                                             $html .= '<h1 id="nemtudsz">Nem tudsz örökbe fogadni, mert nem vagy bejelentkezve.</h1>';
                                          
                                           } elseif($IS_IVARTALAN == 1 And $IS_CHIP == 1 And abs($hanynap)>14 And $IS_OROKBEADAS==0 And $bizalom==1 ){ //még nincs kész; 
                                             // Logged in
                                                if($suly>5 And  $kert==1 ){
                                                  $html .= '<button type="submit" name="save_date" value="UPLOAD" class="btn2">Örökbeadás</button>';
                                                }
                                             
                                               elseif($suly<5 ){
                                            $html .= '<h1 id="nemtudsz">Nem tudsz öröbe fogadni, mert az állat több mint 5kg és nincs megfelelő kerted.</h1>';

                                               }
                                            }
                                         
                                          else{
                                            $html .= '<h1 id="nemtudsz">Nem tudsz öröbe fogadni, mert az állat örökbevaló fogadás feltételei nem teljesültek vagy mert nincs bizalmi kapcsolatod.</h1>';
                                           }
                                      
                                           $html .= ' <u id="feltetelek">Fő feltételei az örökbefogadásnak: Ivartalanitott legyen,be legyen chippelve,a karanténja le legyen járva,ne legyen még örökbeadva,és a  felhasználónak bizalmi kapcsolata legyen.</u>';


                                         
                                          $html .= '</div>
                                           <div class="col">
                                             <h2>' . $allat_nev . '<br></h2>
                                             <p>Állat azonositója adatbázisunkban: ' . $allat_id . '</p>
                                             <p>Született: ' . $szuletett . '<br></p>
                                             <p>Becsült kor: ' . $becsult_kor . '<br></p>
                                             <p>Neme: ' . $neme . '<br></p>
                                             <p>Fajta: ' . $fajta . '<br></p>
                                             <p>Súlya: ' . $suly . '<br></p>
                                             <p>Egészségügyi állapota: ' . $eu_allapot . '<br></p>
                                             <p>Testi állapota: ' . $testi_allapot . '<br></p>
                                             <p>Fogazatt állapota: ' . $fogazatt . '<br></p>
                                             <p>Ivartalanított-e?: ' . $ivaros . '<br></p>
                                             <p>Chippelt: ' . $chipes . '<br></p>
                                             <p>Befogadás dátuma: ' . $befogadas_datuma . '<br></p>
                                             <p>Megjegyzés: ' . $megjegyzes . '<br></p>
                                             <p>Karantén kezdete: ' . $karantenlejart . '<br></p>
                                             <p>
                                               <img src="kepek/Question_mark.png" title="A karantén 14 napig tart." alt="segítség" id="Question_mark">
                                               Hány nap van még a karanténból?: ' . 
                                               ($hanynapint == 'Nincs több nap a karanténból.' ? $hanynapint : abs($hanynapint) . ' nap') . 
                                               ' <br>
                                             </p>
                                           </div>
                                         </div>
                                         </div>
                                         </form>
                                         </div>'; 
                        
                        echo $html;
                        
                        echo '</div>


                        
                        ';
                        
                    }else {
                        echo '<h1 style="padding:5pt;">Ez a kutya nem létezik</h1>';
                    }
                  /*
                    if(isset($_SESSION["user_id"])==NULL){
                      // Haven't log in
                      echo "You haven't log in";
                    }else{
                      // Logged in
                      echo "Successfully logged in!";
                    }
*/


               
                    
                    mysqli_close($conn);
                   
                
                 

                ?>


            </div>


        </div>

        

       

    </div>
</body>
</html>