<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fknmenhely";

// Adatbázis kapcsolat létrehozása
$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
  }
  session_start();
if(isset($_POST['save_date']))
{
 

    ///allat id
    $db = new mysqli("localhost", "root", "", "fknmenhely");
    $db_amount = $db->query("SELECT COUNT(*) FROM allatok");
    $totalItem = $db_amount->fetch_row()[0];
    $url_allat_id = $_GET['id'];

    if (preg_match('/^[0-9]+$/', $url_allat_id)) {
      // Az "id" értéke csak számokat tartalmaz
      // folytathatjuk a kódot
    } else {
      // Az "id" értéke nem csak számokat tartalmaz
      die( "Hiba: Az id értéke csak számokat tartalmazhat!");
    }
   

    if ($url_allat_id <= $totalItem) {
        $allat = $db->query("SELECT * FROM `allatok` WHERE `allat_id` = \"$url_allat_id\"");
        
     
        $mezo = $allat -> fetch_row();
        $allat_id = $mezo[0];
        $allat_orokebadas = $mezo[14];
    }

//userid
$db = new mysqli("localhost", "root", "", "fknmenhely");
$db_amount = $db->query("SELECT COUNT(*) FROM felhasznalok");
$totalItem = $db_amount->fetch_row()[0];
$url_user_id = $_GET['userid'];


 if (preg_match('/^[0-9]+$/', $url_user_id)) {
   // Az "id" értéke csak számokat tartalmaz
   // folytathatjuk a kódot
 } else {
   // Az "id" értéke nem csak számokat tartalmaz
   die( "Hiba: Az id értéke csak számokat tartalmazhat!");
 }


if ($url_user_id <= $totalItem) {
    $userek = $db->query("SELECT * FROM `felhasznalok` WHERE `id` = \"$url_user_id\"");
   
 // 
  //
    $mezo_user = $userek -> fetch_row();}
    $user_id = $mezo_user[0];

////////



   $query = "INSERT INTO orokbeadott_allatok (user_id,allat_id) VALUES ('$user_id','$allat_id')";
   $query2 = "UPDATE allatok SET orokbeadas = '0', orokbeadas = '1' WHERE   `allat_id` = \"$url_allat_id\"";
   
 

//////////////////////////////////////////////
$query_run = mysqli_query($conn, $query);

$query_run2 = mysqli_query($conn, $query2);

if($query_run)
{
    $_SESSION['status'] = "Sikeresen örökbefogadtad az állatot.";
    header("Location: index.html");
}
else
{
    $_SESSION['status'] = "Nem sikerült örökbefogadnod az állatot.";
    header("Location: index.html");
   
}

if($query_run2)
{
    $_SESSION['status'] = "Sikeresen örökbefogadtad az állatot.";
    header("Location: index.html");
  
}
else
{
    $_SESSION['status'] = "Nem sikerült örökbefogadnod az állatot.";
    header("Location: index.html");
   
}
}
mysqli_close($conn);
?>