<?php session_start();


if (isset($_SESSION["user_id"])) {
    
    $mysqli = require __DIR__ . "/database.php";
    
    $sql = "SELECT * FROM user
            WHERE id = {$_SESSION["user_id"]}";
            
    $result = $mysqli->query($sql);
    
    $user = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Állatok keresés</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
    
    
    <link rel="stylesheet" href="stilus/style_allatok.css?v=<?php echo time(); ?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://unpkg.com/just-validate@latest/dist/just-validate.production.min.js" defer></script>
    <script src="js/validation.js" defer></script>
    
</head>
<body>
<div class="site-container">
        <div class="header">
          <!------------------------fej-eleje------------------------------------------>
  <header class="bg-light" id="fej1">
    <div class="container">
      
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <a class="navbar-brand" href="#">
            <img src="kepek/logo2.png" width="50" height="50" alt="">
          </a>
            <a class="navbar-brand" href="#">Menü</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                  <a class="nav-link" href="index.html">Főoldal </a>
                </li>
                <li class="nav-item">
               
                  <a class="nav-link" href="allatok.php">Állatok</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php">Saját oldalam</a>
                </li>
                     
                <li class="nav-item">
                <a class="nav-link" href="loginadmin.php">Állatok örökbeadása</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php"> Felhasználó:
                  <?php
                  if (isset($user)): ?><?= htmlspecialchars($user["name"]) ?> 
                  <?php else: ?> 
                    Bejelentkezés
                  <?php endif; ?></a>
                </li>
              
              </ul>
            </div>
          </nav>
    </div>
</header> 

<!---------------------fej-vége----------------->   
        </div>

        <div class="main">
            <div class="allatok-container">
                <div class="allatok-search">
                    <div class="search-wrapper">
                    <form action="">
    <input type="text" name="nev_search" id="nev_search" placeholder="pl.: Rómeó" autofocus>
    <input list="fajtak" name="faj_search" id="faj_search" placeholder="Saarloosi farkaskutya">
    <datalist id="fajtak">
        <?php
        $db = new mysqli("localhost", "root", "", "fknmenhely");
        $tipusok = $db->query("SELECT DISTINCT fajta FROM `allatok`");
        while ($tipus = $tipusok->fetch_row()) {
            echo "<option value=\"$tipus[0]\">";
        }
        ?>
    </datalist>
    <input type="submit" value="Szűrés" id="szures">
    <div class="ivar_search">
        <input value="kan" type="radio" name="ivar_search" id="kan_search">
        <label for="kan_search" id="gomb_szoveg">Kan</label>

        <input value="szuka" type="radio" name="ivar_search" id="szuka_search">
        <label for="szuka_search" id="gomb_szoveg">Szuka</label>
    </div>
</form>

                    </div>
                </div>
                <div class="allatok-grid">
                    <div class="allatokwrapper">
                        <?php
                        //
                       // Retrieve search parameters from $_GET or set them to empty strings
$nev_search = $_GET['nev_search'] ?? '';
$faj_search = $_GET['faj_search'] ?? '';
$ivar_search = $_GET['ivar_search'] ?? '';

// Build SQL query with search parameters
$query = "SELECT * FROM `allatok` WHERE allat_nev LIKE '%$nev_search%' AND fajta LIKE '%$faj_search%' AND neme LIKE '%$ivar_search%'";

// Connect to database and execute queries
$db = new mysqli("localhost", "root", "", "fknmenhely");
$db_amount = $db->query("SELECT COUNT(*) FROM ($query) as count_table");
$result = $db->query($query);

                            //

                            $html = '';
                            $totalItemPerLine = 3;
                            $totalItem = $db_amount->fetch_row()[0];
                            
                            if($totalItem > 0){
                                for($i = 0; $i < $totalItem; $i++)
                                {
                                    $row = $result -> fetch_row();

                                    $allat_id = $row[0];
                                    $allat_nev = $row[1];
                                    $szuletett = substr($row[2], 0, 10);
                                    $becsult_kor = $row[3];
                                    $neme = $row[4];
                                    $fajta = $row[5];
                                    $eu_allapot = $row[6];
                                    $IS_IVARTALAN = $row[7];
                                    $suly = $row[8];
                                    $fogazatt = $row[9];
                                    $testi_allapot = $row[10];
                                    $ismertetojegyek = $row[11];
                                    $megjegyzes = $row[12];
                                    $IS_CHIP = $row[13];
                                    $IS_OROKBEADAS = $row[14];
                                    $befogadas_datuma = substr($row[15], 0, 10);
                                    $img_src = $row[16];





                                    if($i % $totalItemPerLine == 0)
                                    {
                                        $html .= '<div class="row">'; 
                                    }
                                
                                    $html .= '<div class="card">'
                                    .'<div class="img-wrapper">'
                                    .'<a href="/allatok_sajatoldala.php?id='.$allat_id.'"></a>'
                                    .'<img class="thumbnail" src="'.$img_src.'"></div><br>'
                                    .'<h2 class="allat-nev">'.$allat_nev.'</h2>'
                                    
                                    ."<p> Állat azonositója adatbázisunkban : ".$allat_id."</p>"
                                    ."<p> Született : ".$szuletett."</p>"
                                    ."<p> Becsült kor: ".$becsult_kor."</p>"
                                    ."<p> Ivar: ".$neme."</p>"
                                    ."<p> Fajta: ".$fajta."</p>"
                                    ."<p> Súly: ".$suly." kg</p>"
                                    .'<a class="btn1" href="allatok_sajatoldala.php?id='.$allat_id.'">'
                                    .'További részletek <span class="nyil-ikon"> </span></a>'
                                    .'</div>';
                                    
                                    if($i % $totalItemPerLine == ($totalItemPerLine-1) || $i == ($totalItem-1))
                                    {
                                        $html .= '</div>'; 
                                    }
                                }   
                            } else {
                                $html .= "Nincs találat";
                            }
                            $db->close();
                            echo $html;
                        ?>
                    </div>        
                </div>
            </div>
            
        </div>

        

    </div>
</body>
</html>